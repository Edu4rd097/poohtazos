// Service worker de Borderline: guarda los archivos del juego para que se pueda instalar
// y jugar sin conexión. Estrategia: responde con lo guardado y actualiza en segundo plano.
//
// En la versión publicada (Angular), `npm run build` genera precache.js con la lista de todos
// los archivos y un número de versión (BUILD) que cambia en cada publicación: así los jugadores
// reciben la versión nueva sin tocar nada aquí. En desarrollo no existe y sólo se guarda lo básico.
try { importScripts('precache.js'); } catch (e) { /* desarrollo: sin lista */ }
const VERSION = 'borderline-' + (self.BUILD || 'dev');
const FILES = [...new Set(['./', 'index.html', 'style.css', 'manifest.webmanifest', ...(self.PRECACHE || [])])]; // sin repetidos (addAll falla con duplicados)

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const req = e.request;
  // sólo GET del mismo sitio; el audio se pide por rangos y no se guarda aquí
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin || req.headers.has('range')) return;
  e.respondWith(caches.open(VERSION).then(async cache => {
    // las páginas (navegación) siempre responden con el index guardado si no hay red
    const hit = await cache.match(req, { ignoreSearch: true }) || (req.mode === 'navigate' ? await cache.match('index.html') : null);
    const net = fetch(req).then(res => {
      if (res.ok && res.status === 200) cache.put(req, res.clone());
      return res;
    }).catch(() => hit);
    return hit || net;
  }));
});
