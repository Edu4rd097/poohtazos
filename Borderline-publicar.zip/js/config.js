// Constantes globales del motor. Todo lo "de sensación" (feel) se ajusta aquí.
export const FPS = 60;                 // la simulación corre a paso fijo, independiente del monitor
export const DT = 1 / FPS;

export const STAGE = {
  width: 1280,
  height: 720,
  floor: 640,   // y en pantalla donde está el piso
  wall: 24,     // margen de las paredes
};

export const CAMERA_ZOOM = 1.4;        // acercamiento de la cámara (1 = sin zoom)
export const GRAVITY = 3600;           // px/s²
export const ROUND_TIME = 60;          // segundos
export const ROUNDS_TO_WIN = 2;
export const METER_MAX = 100;

export const INPUT_BUFFER = 6;         // cuadros que un botón queda "guardado"
export const DASH_WINDOW = 12;         // cuadros para el doble toque (dash)
export const KNOCKDOWN_FRAMES = 35;
export const GETUP_FRAMES = 18;

// Pausa al impactar (hitstop), en cuadros, según la fuerza del golpe
export const HITSTOP = { light: 5, medium: 8, heavy: 11, super: 6, block: 4 };
export const SHAKE = { light: 0, medium: 2, heavy: 5, super: 4, block: 0 };

// Escalado de daño en combos: cada golpe extra hace 12% menos, mínimo 35%
export const COMBO_SCALING = 0.12;
export const MIN_SCALING = 0.35;
