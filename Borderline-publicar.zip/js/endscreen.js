// Pantalla final: "Gracias por jugar", resultado de la pelea, botones y créditos.
// Aparece un momento después de que termina la pelea (aviso 'borderline:fin' de game.js).
const app = document.getElementById('app');
let panel = null, timer = null;

const esc = s => String(s ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const press = code => window.dispatchEvent(new KeyboardEvent('keydown', { code }));

export function closeEnd() {
  clearTimeout(timer);
  panel?.remove(); panel = null;
  document.body.classList.remove('endscreen');
}

function show(d) {
  closeEnd();
  document.body.classList.add('endscreen');
  const result = d.ganador ? `${esc(d.ganador)} GANA ${d.marcador.join(' - ')}` : `EMPATE ${d.marcador.join(' - ')}`;
  panel = document.createElement('div');
  panel.className = 'end-screen';
  panel.innerHTML = `
    <div class="end-box">
      <h2>Gracias por jugar</h2>
      <p class="result">${result} &nbsp;·&nbsp; ${esc(d.escenario)}</p>
      <p class="vs-line">${esc(d.p1)} <span>vs</span> ${esc(d.p2)}</p>
      <div class="end-actions">
        <button type="button" data-act="Enter">REVANCHA</button>
        <button type="button" data-act="KeyM">MENU</button>
      </div>
      <p class="credits">Un juego de <b>RageCore Programación</b></p>
    </div>`;
  app.appendChild(panel);
  panel.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => { const code = b.dataset.act; closeEnd(); press(code); }));
}

window.addEventListener('borderline:fin', e => {
  clearTimeout(timer);
  timer = setTimeout(() => show(e.detail), 2600); // deja ver el "¡X GANA!" antes
});
