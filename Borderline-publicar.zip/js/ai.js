// IA sencilla basada en reglas. Escribe en un VirtualInput, igual que un jugador humano,
// así que no hace trampa: usa los mismos botones y los mismos tiempos.
const LEVELS = {
  easy: { react: 22, block: 0.25, antiAir: 0.15, aggro: 0.45, combo: 0.25 },
  normal: { react: 12, block: 0.55, antiAir: 0.45, aggro: 0.6, combo: 0.5 },
  hard: { react: 6, block: 0.85, antiAir: 0.8, aggro: 0.7, combo: 0.85 },
};

const idle = n => Array.from({ length: n }, () => ({ held: {} }));

export class AI {
  constructor(me, opp, match, vinput, level = 'normal') {
    Object.assign(this, { me, opp, match, v: vinput });
    this.cfg = LEVELS[level] || LEVELS.normal;
    this.timer = 30;
    this.held = {};
    this.plan = [];
    this.spCooldown = 60;
  }

  projectileIncoming() {
    const { me, opp } = this;
    return this.match.projectiles.some(p =>
      p.owner === opp && Math.abs(p.x - me.x) < 380 && Math.sign(me.x - p.x) === Math.sign(p.vx));
  }

  think() {
    if (this.me.locked) { this.plan = []; this.v.set({}); return; }
    if (this.plan.length) {
      const s = this.plan.shift();
      this.v.set(s.held || {}, s.taps || []);
      return;
    }
    if (this.spCooldown > 0) this.spCooldown--;
    // si viene un proyectil, reconsiderar pronto (no seguir caminando hacia él)
    if (this.timer > 3 && this.held[this.me.fwdKey] && this.projectileIncoming()) this.timer = 3;
    if (this.timer-- > 0) { this.v.set(this.held); return; }
    this.timer = this.cfg.react + Math.floor(Math.random() * 6);
    this.decide();
  }

  decide() {
    const { me, opp, cfg } = this;
    const R = Math.random;
    const fwd = me.fwdKey, back = me.backKey;
    const dist = Math.abs(opp.x - me.x);
    const held = {}, taps = [];
    const [spMin, spMax] = me.def.ai?.specialRange || [300, 800];

    const projectileIncoming = this.projectileIncoming();
    const threat = (opp.state === 'attack' && opp.phase() !== 'recovery' && dist < 280) || projectileIncoming;

    if (projectileIncoming && dist > 220 && R() < cfg.block * 0.5) {
      // saltar por encima del proyectil
      this.plan = [{ held: { up: true, [fwd]: true } }, ...Array.from({ length: 14 }, () => ({ held: { [fwd]: true } })), { taps: ['lk'] }];
    } else if (threat && R() < cfg.block) {
      held[back] = true;
      if (opp.move && opp.move.level === 'low') held.down = true;
    } else if (opp.airborne && opp.state !== 'airhit' && dist < 240 && R() < cfg.antiAir) {
      held.down = true; taps.push('hp');
      this.timer = 4;
    } else if (me.def.moves.super && me.meter >= 100 && dist < 380 && R() < 0.4) {
      taps.push('su');
    } else if (dist >= spMin && dist <= spMax && this.spCooldown <= 0 && R() < 0.3) {
      taps.push('sp');
      this.spCooldown = 70 + Math.floor(R() * 70);
    } else if (dist > 420) {
      if (R() < 0.15) this.plan = [{ held: { [fwd]: true } }, { held: {} }, { held: { [fwd]: true } }, ...idle(10)];
      else held[fwd] = true;
    } else if (dist > 170) {
      const r = R();
      if (r < (me.def.ai?.jumpIn ?? 0.12)) {
        this.plan = [{ held: { up: true, [fwd]: true } }, ...Array.from({ length: 16 }, () => ({ held: { [fwd]: true } })), { taps: ['lk'] }];
      } else if (r < Math.max(cfg.aggro, me.def.ai?.walkIn ?? 0)) held[fwd] = true;
      else if (r < cfg.aggro + 0.15) held[back] = true;
    } else {
      const r = R();
      if (r < cfg.combo * 0.5) {
        // combo: jab → patada → ráfaga o patada giratoria
        this.plan = [{ taps: ['lp'] }, ...idle(5), { taps: ['lk'] }, ...idle(7), { taps: ['sp'] }, ...idle(6)];
      } else if (r < 0.45) { held.down = true; taps.push('lk'); }
      else if (r < 0.52) taps.push('hp');
      else if (r < 0.6) { held[fwd] = true; taps.push(R() < 0.5 ? 'lk' : 'lp'); } // patada giratoria / ráfaga
      else if (r < 0.75) taps.push('lp');
      else held[back] = true;
    }
    this.held = held;
    this.v.set(held, taps);
  }
}
