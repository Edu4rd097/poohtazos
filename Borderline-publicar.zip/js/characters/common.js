// BORDERLINE: golpes, patadas, poderes y súper (los mismos sistemas que Arena).
//
//   J (lp)  Jab          K (lk)  Patada          L (hp)  Gancho
//   U (sp)  PODER        el especial de cada peleador (embestida, llave, proyectil...)
//   I (su)  SÚPER        necesita la barra POWER llena; se llena pegando y recibiendo golpes
//   adelante + J  Ráfaga (4 golpes que avanzan)   ·   adelante + K  Patada giratoria (tumba)
//   agachado + J  al cuerpo · agachado + K  barrida (baja) · agachado + L  uppercut (lanza)
//   en el aire J / K / L  jab, patada voladora y martillo
//
// Combos: Jab → Patada → Gancho → Poder / Súper  (cada golpe se cancela en los de la derecha si conectó)
// Campos de cada golpe: ver la documentación en arena/js/characters/common.js.
export function moveset(over = {}) {
  const base = {
    lp: {
      name: 'Jab', button: 'lp', startup: 4, active: 3, recovery: 7,
      damage: 30, hitstun: 15, blockstun: 11, knockback: 230,
      level: 'mid', strength: 'light', meter: 5,
      hitbox: { x: 30, y: 135, w: 62, h: 24 },
      windup: 'jabWind', strike: 'jab',
      cancels: ['lp', 'lk', 'c_lk', 'hp', 'f_lp', 'f_lk', 'special', 'super'],
    },
    lk: {
      name: 'Patada', button: 'lk', startup: 6, active: 4, recovery: 12,
      damage: 52, hitstun: 18, blockstun: 13, knockback: 300,
      level: 'mid', strength: 'medium', meter: 7,
      hitbox: { x: 30, y: 70, w: 80, h: 32 },
      windup: 'kickWind', strike: 'kick',
      cancels: ['hp', 'f_lp', 'f_lk', 'special', 'super'],
    },
    hp: {
      name: 'Gancho', button: 'hp', startup: 9, active: 4, recovery: 20,
      damage: 85, hitstun: 22, blockstun: 15, knockback: 440,
      level: 'mid', strength: 'heavy', meter: 10,
      hitbox: { x: 15, y: 128, w: 72, h: 40 },
      windup: 'hookWind', strike: 'hook',
      cancels: ['f_lp', 'f_lk', 'special', 'super'],
    },
    c_lp: {
      name: 'Al cuerpo', button: 'lp', crouch: true, startup: 4, active: 3, recovery: 7,
      damage: 26, hitstun: 14, blockstun: 10, knockback: 210,
      level: 'mid', strength: 'light', meter: 5,
      hitbox: { x: 30, y: 85, w: 62, h: 24 },
      windup: 'cJabWind', strike: 'cJab',
      cancels: ['c_lp', 'c_lk', 'f_lp', 'f_lk', 'special', 'super'],
    },
    c_lk: {
      name: 'Barrida', button: 'lk', crouch: true, startup: 7, active: 4, recovery: 16,
      damage: 42, hitstun: 17, blockstun: 12, knockback: 200, knockdown: true,
      level: 'low', strength: 'medium', meter: 7,
      hitbox: { x: 30, y: 10, w: 84, h: 30 },
      windup: 'sweepWind', strike: 'sweep',
      cancels: ['special'],
    },
    c_hp: {
      name: 'Uppercut', button: 'hp', crouch: true, startup: 7, active: 6, recovery: 24,
      damage: 80, hitstun: 20, blockstun: 14, knockback: 200, launch: 900,
      level: 'mid', strength: 'heavy', meter: 10,
      hitbox: { x: 5, y: 110, w: 60, h: 130 },
      windup: 'upperWind', strike: 'upper',
      cancels: ['special'],
    },
    j_lp: {
      name: 'Jab aéreo', button: 'lp', air: true, startup: 4, active: 8, recovery: 6,
      damage: 38, hitstun: 16, blockstun: 12, knockback: 200,
      level: 'overhead', strength: 'light', meter: 5,
      hitbox: { x: 30, y: 65, w: 58, h: 42 },
      windup: 'jPunchWind', strike: 'jPunch',
    },
    j_lk: {
      name: 'Patada voladora', button: 'lk', air: true, startup: 5, active: 10, recovery: 6,
      damage: 55, hitstun: 18, blockstun: 13, knockback: 240,
      level: 'overhead', strength: 'medium', meter: 7,
      hitbox: { x: 30, y: 0, w: 66, h: 48 },
      windup: 'jKickWind', strike: 'jKick',
    },
    j_hp: {
      name: 'Martillo', button: 'hp', air: true, startup: 8, active: 6, recovery: 8,
      damage: 72, hitstun: 22, blockstun: 15, knockback: 300,
      level: 'overhead', strength: 'heavy', meter: 10,
      hitbox: { x: 10, y: 15, w: 75, h: 65 },
      windup: 'jHeavyWind', strike: 'jHeavy',
    },
    // Ráfaga (adelante + J): 4 golpes alternando puños mientras avanza.
    f_lp: {
      name: 'Ráfaga', button: 'lp', forward: true, startup: 6, active: 16, recovery: 18,
      motion: [{ from: 5, to: 20, vx: 220 }],
      hits: 4, hitInterval: 4, alternate: true,
      damage: 22, hitstun: 16, blockstun: 9, knockback: 110,
      level: 'mid', strength: 'medium', meter: 3,
      hitbox: { x: 25, y: 120, w: 75, h: 40 },
      windup: 'jabWind', strike: 'jab', strikeAlt: 'heavy',
      cancels: ['special', 'super'],
    },
    // Patada giratoria (adelante + K): patada alta que tumba
    f_lk: {
      name: 'Patada giratoria', button: 'lk', forward: true, startup: 11, active: 5, recovery: 22,
      damage: 95, hitstun: 24, blockstun: 16, knockback: 420, knockdown: true,
      level: 'mid', strength: 'heavy', meter: 8,
      motion: [{ from: 4, to: 14, vx: 160 }],
      hitbox: { x: 20, y: 120, w: 86, h: 50 },
      windup: 'roundWind', strike: 'highKick',
      cancels: ['special', 'super'],
    },
  };
  for (const k in over) base[k] = { ...base[k], ...over[k] };
  return base;
}
// nombre anterior, por compatibilidad
export const punches = moveset;

// ---------- poderes (U) y súper (I), los mismos de Arena ----------
// embestida: se lanza hacia adelante y tumba
export const rush = (name, o = {}) => ({
  name, button: 'sp', startup: 7, active: 12, recovery: 12,
  motion: [{ from: 6, to: 19, vx: 900 }],
  damage: 90, chip: 9, hitstun: 20, blockstun: 20, knockback: 320, knockdown: true,
  level: 'mid', strength: 'heavy', meter: 9, special: true,
  hitbox: { x: 20, y: 45, w: 80, h: 50 },
  windup: 'rushWind', strike: 'rush', ...o,
});
// llave: agarre imbloqueable que lo avienta por encima
export const grab = (name, o = {}) => ({
  name, button: 'sp', startup: 5, active: 4, recovery: 26,
  unblockable: true, groundOnly: true, reverse: true,
  damage: 130, hitstun: 0, blockstun: 0, knockback: 260, launch: 1050,
  level: 'mid', strength: 'heavy', meter: 14, special: true,
  hitbox: { x: 20, y: 40, w: 72, h: 120 },
  windup: 'grabWind', strike: 'grab', ...o,
});
// proyectil
export const orb = (name, color, core, o = {}) => ({
  name, button: 'sp', startup: 12, active: 2, recovery: 22,
  windup: 'castWind', strike: 'cast',
  projectile: {
    speed: 630, y: 125, w: 50, h: 40, life: 140, kind: 'orb', color, core,
    damage: 80, chip: 10, hitstun: 20, blockstun: 16, knockback: 320,
    level: 'mid', strength: 'medium', meter: 8, special: true,
  }, ...o,
});
// súper giratoria: avanza girando con varios golpes
export const spinSuper = (name, o = {}) => ({
  name, button: 'su', super: true, cost: 100,
  startup: 8, active: 30, recovery: 30, invuln: 22,
  motion: [{ from: 8, to: 36, vx: 650 }],
  hits: 6, hitInterval: 5, finalLaunch: 950, spin: true,
  damage: 42, chip: 6, hitstun: 30, blockstun: 12, knockback: 60,
  level: 'mid', strength: 'super', meter: 0, special: true,
  hitbox: { x: -30, y: 40, w: 140, h: 70 },
  windup: 'rushWind', strike: 'spinKick', ...o,
});
// súper de zarpazos: arremete con golpes que lo levantan
export const clawSuper = (name, o = {}) => ({
  name, button: 'su', super: true, cost: 100,
  startup: 8, active: 28, recovery: 30, invuln: 20,
  motion: [{ from: 8, to: 34, vx: 620 }],
  hits: 5, hitInterval: 5, finalLaunch: 1000,
  damage: 52, chip: 8, hitstun: 30, blockstun: 12, knockback: 60,
  level: 'mid', strength: 'super', meter: 0, special: true,
  hitbox: { x: 10, y: 60, w: 110, h: 90 },
  windup: 'clawWind', strike: 'clawSwipe', ...o,
});
// súper de rayo: proyectil gigante de varios golpes
export const beamSuper = (name, color, core, ring, o = {}) => ({
  name, button: 'su', super: true, cost: 100,
  startup: 10, active: 2, recovery: 35, invuln: 14,
  windup: 'castWind', strike: 'cast',
  projectile: {
    speed: 900, y: 110, w: 130, h: 120, life: 100, kind: 'beam', color, core, ring,
    hits: 5, hitInterval: 4, finalLaunch: 800,
    damage: 50, chip: 8, hitstun: 26, blockstun: 14, knockback: 150,
    level: 'mid', strength: 'super', meter: 0, special: true, super: true,
  }, ...o,
});
