// TU PAPÁ: chaparro, macizo, calvo y bigotón: aguanta todo y pega seco.
import { moveset, grab, clawSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'tupapa',
  name: 'TU PAPÁ',
  title: 'El Patriarca', // apodo
  profile: { apodo: 'El Patriarca', edad: 45, estatura: '1.70 m', peso: '96 kg' },
  stats: {
    hp: 1260, width: 78, height: 182,
    walkF: 240, walkB: 190,
    jumpV: 1180, jumpVX: 270,
    dashSpeed: 680, dashFrames: 14,
    backdashSpeed: 580, backdashFrames: 16,
  },
  look: {
    thigh: 45, shin: 43, torso: 64, upperArm: 38, foreArm: 37,
    headR: 15, limbW: 17.5, torsoW: 46,
    build: { shoulder: 1.38, chest: 1.32, waist: 1.02, hip: 1.04 },
    top: 'none', bottom: 'trunks', feet: 'boots', gloves: 'fingerless',
    hair: 'bald', face: 'snarl', mustache: true, scar: true, wraps: true, sweat: true,
    colors: {
      skin: '#b8774a', top: '#b8774a', pants: '#f0efe8', accent: '#16161b', menu: '#f0efe8', trim: '#b3141a',
      shoe: '#1c1c20', hair: '#1c1410', glove: '#3a2418', wrap: '#e8e4da', eyes: '#2a1a10', aura: '#ffffff',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [60, 120], armB: [50, 110] },
    victory: { ...G, torso: 4, armF: [170, 178], armB: [165, 172] },
  },
  ai: { specialRange: [0, 110], jumpIn: 0.06, walkIn: 0.95 },
  moves: {
    ...moveset({
    lp: { damage: 33, startup: 5 },
    lk: { damage: 58 },
    hp: { damage: 102, startup: 10, knockback: 480 },
    f_lp: { damage: 25 },
  }),
    special: grab('Abrazo de Oso', { damage: 140 }),
    super: clawSuper('CASTIGO PATERNO'),
  },
};
