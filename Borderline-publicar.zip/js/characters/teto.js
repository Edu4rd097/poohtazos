// TETO: chaparro, gordo y macizo, de piel negra. Lento pero aguanta como tanque y aplasta.
import { moveset, grab, clawSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'teto',
  name: 'TETO',
  title: 'El Tanque', // apodo
  profile: { apodo: 'El Tanque', edad: 29, estatura: '1.58 m', peso: '112 kg' },
  stats: {
    hp: 1360, width: 84, height: 168,
    walkF: 215, walkB: 175,
    jumpV: 1100, jumpVX: 240,
    dashSpeed: 620, dashFrames: 15,
    backdashSpeed: 540, backdashFrames: 17,
  },
  look: {
    thigh: 39, shin: 36, torso: 60, upperArm: 34, foreArm: 33,
    headR: 16, limbW: 18.5, torsoW: 52,
    build: { shoulder: 1.22, chest: 1.36, waist: 1.36, hip: 1.24 },
    top: 'none', bottom: 'trunks', feet: 'sneakers', gloves: 'fingerless',
    hair: 'buzz', face: 'smile', stubble: true, wraps: true, sweat: true,
    colors: {
      skin: '#5c3a26', top: '#5c3a26', pants: '#f0efe8', accent: '#ffb000', menu: '#ffb000', trim: '#ffb000',
      shoe: '#f0f0f0', hair: '#0e0a08', glove: '#ffb000', wrap: '#e8e4da', eyes: '#1a0e08', aura: '#ffb000',
    },
  },
  poses: {
    intro: { ...G, torso: 6, armF: [40, 60], armB: [30, 50] },
    victory: { ...G, torso: 2, armF: [160, 175], armB: [155, 170] },
  },
  ai: { specialRange: [0, 110], jumpIn: 0.04, walkIn: 0.95 },
  moves: {
    ...moveset({
      lp: { damage: 33, startup: 5 },
      lk: { damage: 60, startup: 7 },
      hp: { damage: 104, startup: 11, knockback: 500 },
    }),
    special: grab('Apapacho', { damage: 145 }),
    super: clawSuper('APLASTADA'),
  },
};
