// LOKILLO: flaco, alto y desquiciado: rápido y con mucho alcance.
import { moveset, rush, spinSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'lokillo',
  name: 'LOKILLO',
  title: 'El Desquiciado', // apodo
  profile: { apodo: 'El Desquiciado', edad: 22, estatura: '1.85 m', peso: '72 kg' },
  stats: {
    hp: 960, width: 66, height: 198,
    walkF: 325, walkB: 245,
    jumpV: 1310, jumpVX: 345,
    dashSpeed: 860, dashFrames: 12,
    backdashSpeed: 710, backdashFrames: 14,
  },
  look: {
    thigh: 53, shin: 51, torso: 64, upperArm: 41, foreArm: 40,
    headR: 13.8, limbW: 13, torsoW: 34,
    build: { shoulder: 1.18, chest: 1.04, waist: 0.74, hip: 0.9 },
    top: 'none', bottom: 'trunks', feet: 'bare', gloves: 'fingerless',
    hair: 'spiky', face: 'smile', tattoos: true, wraps: true, sweat: true,
    colors: {
      skin: '#e2ad84', top: '#e2ad84', pants: '#ecebe4', accent: '#7bd23a', menu: '#9be05a', trim: '#7bd23a',
      shoe: '#e2ad84', hair: '#b8e04a', glove: '#7bd23a', wrap: '#e8e4da', ink: '#2a3a30', eyes: '#2a6a2a', aura: '#9be05a',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [90, 170], armB: [80, 160] },
    victory: { ...G, torso: 4, armF: [172, 178], armB: [100, 140] },
  },
  ai: { specialRange: [0, 170], jumpIn: 0.16, walkIn: 0.8 },
  moves: {
    ...moveset({
    lp: { damage: 26, startup: 3 },
    lk: { damage: 48, startup: 5 },
    hp: { damage: 78, startup: 8 },
    f_lp: { hits: 5, hitInterval: 3, damage: 19, motion: [{ from: 5, to: 22, vx: 290 }] },
  }),
    special: rush('Embestida Loca', { motion: [{ from: 6, to: 20, vx: 980 }] }),
    super: spinSuper('LOCURA TOTAL', { hits: 7, hitInterval: 4 }),
  },
};
