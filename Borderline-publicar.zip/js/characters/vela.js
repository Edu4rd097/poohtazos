// VELA — rápida, poca vida, especiales de embestida. Personaje original del motor.
import { moveset } from './common.js';

export default {
  id: 'vela',
  name: 'VELA',
  stats: {
    hp: 950, width: 64, height: 182,
    walkF: 320, walkB: 240,
    jumpV: 1300, jumpVX: 340,
    dashSpeed: 860, dashFrames: 12,
    backdashSpeed: 700, backdashFrames: 14,
  },
  look: {
    thigh: 47, shin: 48, torso: 58, upperArm: 35, foreArm: 35,
    headR: 14, limbW: 12, torsoW: 30,
    build: { shoulder: 1.05, chest: 1.1, waist: 0.75, hip: 1.05 },
    top: 'gi', bottom: 'gi', feet: 'sneakers', gloves: 'full',
    hair: 'ponytail', face: 'calm', headband: true,
    colors: {
      skin: '#f0c8a0', top: '#1d6f73', pants: '#223047', accent: '#7ef0d8', belt: '#101820',
      shoe: '#e9f7f5', hair: '#c9d6ff', glove: '#e9f7f5', eyes: '#1d6f73', aura: '#7ef0d8',
    },
  },
  ai: { specialRange: [0, 140], jumpIn: 0.12 },
  // Borderline: sólo golpes de puño (ver common.js)
  moves: moveset({
      lp: { startup: 3, damage: 25 },
      lk: { startup: 5, damage: 48 },
      hp: { startup: 8, damage: 75 },
      special: { hits: 5, hitInterval: 3, damage: 18, motion: [{ from: 5, to: 22, vx: 280 }] },
    }),
};
