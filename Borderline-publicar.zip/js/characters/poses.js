// Poses del esqueleto. Ángulos en grados, ABSOLUTOS:
//   brazos/piernas: 0 = hacia abajo, 90 = al frente (horizontal), 180 = arriba, negativo = hacia atrás
//   torso: inclinación desde la vertical, positivo = hacia el frente
// Cada extremidad es [segmento1, segmento2] = [brazo, antebrazo] o [muslo, espinilla].
// La altura de la cadera se calcula sola para que el pie más bajo toque el piso.
// Un personaje puede sobrescribir o añadir poses en su campo `poses`.

const GUARD = {
  torso: 6,
  armF: [45, 160], armB: [25, 150],
  legF: [22, -2], legB: [-18, -8],
};
const CROUCH = {
  torso: 28,
  armF: [55, 165], armB: [35, 155],
  legF: [85, -5], legB: [50, -70],
};
const JUMP = {
  torso: 10,
  armF: [60, 150], armB: [30, 140],
  legF: [70, -30], legB: [20, -60],
};
const p = (base, over) => ({ ...base, ...over });

export const BASE_POSES = {
  guard: GUARD,
  crouch: CROUCH,
  jump: JUMP,
  dash: p(GUARD, { torso: 25, armF: [40, 120], armB: [-30, 10], legF: [50, -20], legB: [-40, -10] }),
  backdash: p(GUARD, { torso: -15, legF: [30, 0], legB: [-30, -30] }),

  // golpes de pie
  jabWind: p(GUARD, { torso: 4, armF: [70, 140] }),
  jab: p(GUARD, { torso: 12, armF: [92, 92], armB: [20, 140] }),
  kickWind: p(GUARD, { torso: -4, legF: [60, -20] }),
  kick: p(GUARD, { torso: -18, legF: [95, 92], legB: [-10, -5], armF: [40, 150], armB: [-10, 120] }),
  heavyWind: p(GUARD, { torso: -8, armB: [-40, 70], armF: [50, 150] }),
  heavy: p(GUARD, { torso: 20, armB: [95, 95], armF: [30, 140], legF: [35, 0], legB: [-25, -10] }),

  // golpes de box (Borderline)
  hookWind: p(GUARD, { torso: -10, armF: [40, 70], armB: [30, 160] }),
  hook: p(GUARD, { torso: 26, armF: [88, 135], armB: [25, 150], legF: [35, 0], legB: [-25, -10] }),
  bodyWind: p(CROUCH, { armB: [-20, 60] }),
  bodyBlow: p(CROUCH, { torso: 38, armB: [95, 92], armF: [50, 165] }),
  jCross: p(JUMP, { armB: [70, 68], armF: [40, 150], torso: 20 }),
  // patada alta giratoria (Borderline)
  roundWind: p(GUARD, { torso: -14, legF: [40, -40], armF: [60, 120], armB: [-30, 80] }),
  highKick: p(GUARD, { torso: -34, legF: [128, 126], legB: [-14, -8], armF: [20, 150], armB: [-40, 60] }),

  // golpes agachado
  cJabWind: p(CROUCH, { armF: [70, 140] }),
  cJab: p(CROUCH, { torso: 32, armF: [92, 90] }),
  sweepWind: p(CROUCH, { legF: [70, 30] }),
  sweep: p(CROUCH, { torso: 38, legF: [92, 92], armF: [20, 120], armB: [-20, 60] }),
  upperWind: p(CROUCH, { armF: [20, 120], torso: 20 }),
  upper: p(GUARD, { torso: -5, armF: [172, 176], armB: [10, 100], legF: [12, 0], legB: [-14, -4] }),

  // golpes aéreos
  jPunchWind: p(JUMP, { armF: [100, 160] }),
  jPunch: p(JUMP, { armF: [65, 65], torso: 18 }),
  jKickWind: p(JUMP, { legF: [90, -40] }),
  jKick: p(JUMP, { legF: [60, 60], legB: [10, -60], torso: -5 }),
  jHeavyWind: p(JUMP, { torso: -10, armF: [170, 170], armB: [160, 160] }),
  jHeavy: p(JUMP, { torso: 25, armF: [40, 30], armB: [50, 40] }),

  // especiales
  castWind: p(GUARD, { torso: -10, armF: [-20, 60], armB: [-30, 50] }),
  cast: p(GUARD, { torso: 15, armF: [90, 90], armB: [85, 88], legF: [40, 0], legB: [-30, -10] }),
  rushWind: p(CROUCH, { torso: 35, armF: [-30, 20], armB: [-40, 10] }),
  rush: p(GUARD, { torso: -25, legF: [88, 90], legB: [20, -70], armF: [140, 170], armB: [-40, -20] }),
  spinKick: p(GUARD, { torso: -10, legF: [90, 92], legB: [-5, 0], armF: [90, 90], armB: [-90, -90] }),

  // reacciones
  hurt: p(GUARD, { torso: -22, armF: [20, 40], armB: [-20, 10], legF: [15, 5], legB: [-25, -10] }),
  block: p(GUARD, { torso: -4, armF: [60, 175], armB: [50, 170] }),
  crouchBlock: p(CROUCH, { torso: 10, armF: [60, 175], armB: [50, 170] }),
  hurtAir: p(JUMP, { torso: -45, armF: [140, 170], armB: [-60, -90], legF: [60, 30], legB: [30, 0] }),
  lying: { torso: -88, armF: [-80, -85], armB: [-95, -100], legF: [86, 88], legB: [80, 90] },
  victory: p(GUARD, { torso: 0, armF: [172, 178], armB: [20, 30], legF: [12, 0], legB: [-12, 0] }),
};
