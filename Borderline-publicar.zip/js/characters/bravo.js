﻿// BRAVO: boxeador musculoso de short blanco. Rápido, presiona con ráfagas.
import { moveset, rush, spinSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'bravo',
  name: 'JUANITO',
  title: 'El Toro de la Colonia', // apodo
  profile: { apodo: 'El Toro de la Colonia', edad: 27, estatura: '1.78 m', peso: '80 kg' },
  stats: {
    hp: 1100, width: 72, height: 192,
    walkF: 290, walkB: 220,
    jumpV: 1240, jumpVX: 300,
    dashSpeed: 760, dashFrames: 13,
    backdashSpeed: 640, backdashFrames: 15,
  },
  look: {
    thigh: 49, shin: 47, torso: 66, upperArm: 40, foreArm: 38,
    headR: 14.5, limbW: 16, torsoW: 41,
    build: { shoulder: 1.38, chest: 1.24, waist: 0.82, hip: 0.98 },
    top: 'none', bottom: 'trunks', feet: 'boots', gloves: 'fingerless',
    hair: 'spiky', face: 'snarl', wraps: true, sweat: true,
    colors: {
      skin: '#d48a58', top: '#d48a58', pants: '#eeede6', accent: '#16161b', menu: '#eeede6', trim: '#16161b',
      shoe: '#7a4a26', hair: '#6b3a1c', glove: '#5a3420', wrap: '#9c1d22', eyes: '#3a2414', aura: '#ffffff',
    },
  },
  poses: {
    intro: { ...G, torso: 8, armF: [70, 150], armB: [60, 140] },
    victory: { ...G, torso: 4, armF: [160, 175], armB: [150, 170] },
  },
  ai: { specialRange: [0, 160], jumpIn: 0.1, walkIn: 0.9 },
  moves: {
    ...moveset({
    lp: { damage: 30, startup: 4 },
    lk: { damage: 55 },
    hp: { damage: 92, startup: 9 },
    f_lp: { damage: 24 },
  }),
    special: rush('Ráfaga de Hierro'),
    super: spinSuper('K.O. JUANITO'),
  },
};
