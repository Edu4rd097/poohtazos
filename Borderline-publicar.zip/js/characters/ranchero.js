// RANCHERO: alto y correoso, de bigote y botas vaqueras: golpe largo.
import { moveset, grab, spinSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'ranchero',
  name: 'RANCHERO',
  title: 'El Vaquero', // apodo
  profile: { apodo: 'El Vaquero', edad: 41, estatura: '1.88 m', peso: '90 kg' },
  stats: {
    hp: 1150, width: 72, height: 200,
    walkF: 265, walkB: 205,
    jumpV: 1220, jumpVX: 295,
    dashSpeed: 730, dashFrames: 13,
    backdashSpeed: 620, backdashFrames: 15,
  },
  look: {
    thigh: 53, shin: 51, torso: 68, upperArm: 42, foreArm: 40,
    headR: 14.5, limbW: 15.5, torsoW: 40,
    build: { shoulder: 1.3, chest: 1.16, waist: 0.84, hip: 0.96 },
    top: 'none', bottom: 'trunks', feet: 'boots', gloves: 'fingerless',
    hair: 'buzz', face: 'snarl', mustache: true, stubble: true, wraps: true, sweat: true,
    colors: {
      skin: '#c88a5e', top: '#c88a5e', pants: '#efede4', accent: '#8a4a1e', menu: '#e0a060', trim: '#8a4a1e',
      shoe: '#6a3a18', hair: '#2a1a10', glove: '#8a4a1e', wrap: '#e8e4da', eyes: '#3a2414', aura: '#e0a060',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [70, 150], armB: [60, 140] },
    victory: { ...G, torso: 4, armF: [170, 178], armB: [60, 90] },
  },
  ai: { specialRange: [0, 120], jumpIn: 0.1, walkIn: 0.9 },
  moves: {
    ...moveset({
    lp: { damage: 30, startup: 4 },
    lk: { damage: 56 },
    hp: { damage: 94, startup: 9 },
    f_lp: { damage: 24 },
  }),
    special: grab('Lazo Ranchero'),
    super: spinSuper('ESTAMPIDA'),
  },
};
