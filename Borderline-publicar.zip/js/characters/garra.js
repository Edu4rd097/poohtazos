// GARRA: luchador rudo de melena negra, torso descubierto y mano en garra.
// Basado en la foto assets/portraits/garra.png. Estilo: luchador pesado con agarre.
// Cambia `name` para ponerle otro nombre.
import { moveset } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'garra',
  name: 'GARRA',
  title: 'El Rudo de la Melena',
  portrait: 'assets/portraits/garra.png',
  portraitFocus: 0.25, // altura (0 a 1) de la foto donde está la cara
  stats: {
    hp: 1250, width: 74, height: 196,
    walkF: 255, walkB: 200,
    jumpV: 1220, jumpVX: 290,
    dashSpeed: 700, dashFrames: 14,
    backdashSpeed: 600, backdashFrames: 16,
  },
  look: {
    thigh: 48, shin: 47, torso: 66, upperArm: 40, foreArm: 39,
    headR: 14.5, limbW: 15, torsoW: 40,
    build: { shoulder: 1.3, chest: 1.18, waist: 0.84, hip: 0.95 },
    top: 'none', bottom: 'trunks', feet: 'boots', gloves: 'fingerless',
    hair: 'long', face: 'snarl', necklace: true, wristbands: true, kneepads: true, stubble: true,
    colors: {
      skin: '#c99470', top: '#c99470', pants: '#141418', accent: '#9fb9da',
      shoe: '#1b1b22', hair: '#1a110d', glove: '#22222a', eyes: '#5a6f86', aura: '#8a5cff',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [88, 100], armB: [8, 18], legF: [18, -2], legB: [-14, -6] },
    victory: { ...G, torso: 6, armF: [150, 170], armB: [10, 20] },
    grabWind: { ...G, torso: 12, armF: [70, 120], armB: [55, 110] },
    grab: { ...G, torso: 26, armF: [96, 100], armB: [88, 96], legF: [40, 0], legB: [-28, -12] },
    clawWind: { ...G, torso: -6, armF: [-30, 40], armB: [30, 150] },
    clawSwipe: { ...G, torso: 30, armF: [105, 115], armB: [-20, 30], legF: [50, -10], legB: [-40, -15] },
  },
  ai: { specialRange: [0, 140], jumpIn: 0.12 },
  // Borderline: sólo golpes de puño (ver common.js)
  moves: moveset({
      lp: { damage: 34, startup: 5 },
      lk: { damage: 58 },
      hp: { damage: 100, startup: 10, windup: 'clawWind', strike: 'clawSwipe' },
      special: { damage: 26 },
    }),
};
