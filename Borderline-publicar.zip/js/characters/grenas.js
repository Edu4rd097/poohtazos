// GREÑAS: melena larga y barba, callejero de toda la vida: equilibrado.
import { moveset, orb, beamSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'grenas',
  name: 'GREÑAS',
  title: 'El Melenas', // apodo
  profile: { apodo: 'El Melenas', edad: 34, estatura: '1.76 m', peso: '81 kg' },
  stats: {
    hp: 1100, width: 72, height: 188,
    walkF: 275, walkB: 210,
    jumpV: 1230, jumpVX: 300,
    dashSpeed: 740, dashFrames: 13,
    backdashSpeed: 630, backdashFrames: 15,
  },
  look: {
    thigh: 48, shin: 46, torso: 64, upperArm: 39, foreArm: 38,
    headR: 14.5, limbW: 15.5, torsoW: 40,
    build: { shoulder: 1.3, chest: 1.18, waist: 0.84, hip: 0.98 },
    top: 'none', bottom: 'shorts', feet: 'sneakers', gloves: 'fingerless',
    hair: 'long', face: 'snarl', beard: true, tattoos: true, neckTattoo: true, wraps: true, sweat: true,
    colors: {
      skin: '#c98b5c', top: '#c98b5c', pants: '#121216', accent: '#d8a21e', menu: '#d8a21e', trim: '#d8a21e',
      shoe: '#e8e8e8', hair: '#2a1a12', glove: '#d8a21e', wrap: '#e8e4da', ink: '#26302c', eyes: '#3a2414', aura: '#d8a21e',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [80, 160], armB: [70, 150] },
    victory: { ...G, torso: 4, armF: [168, 176], armB: [40, 60] },
  },
  ai: { specialRange: [300, 800], jumpIn: 0.12, walkIn: 0.9 },
  moves: {
    ...moveset({
    lp: { damage: 31, startup: 4 },
    lk: { damage: 54 },
    hp: { damage: 90, startup: 9 },
    f_lp: { damage: 24 },
  }),
    special: orb('Grito Greñudo', '#22b36b', '#ffffff'),
    super: beamSuper('ALARIDO', '#1fae5f', '#ffffff', '#e23b33'),
  },
};
