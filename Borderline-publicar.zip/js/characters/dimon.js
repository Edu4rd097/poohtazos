// DIMON: el más grande: calvo, barbón y tatuado; lento pero cada golpe duele.
import { moveset, orb, beamSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'dimon',
  name: 'DIMON',
  title: 'El Demonio', // apodo
  profile: { apodo: 'El Demonio', edad: 33, estatura: '1.95 m', peso: '118 kg' },
  stats: {
    hp: 1380, width: 82, height: 208,
    walkF: 220, walkB: 175,
    jumpV: 1140, jumpVX: 255,
    dashSpeed: 630, dashFrames: 15,
    backdashSpeed: 550, backdashFrames: 17,
  },
  look: {
    thigh: 56, shin: 54, torso: 73, upperArm: 44, foreArm: 42,
    headR: 15.5, limbW: 19, torsoW: 49,
    build: { shoulder: 1.45, chest: 1.34, waist: 1.0, hip: 1.05 },
    top: 'none', bottom: 'shorts', feet: 'boots', gloves: 'fingerless',
    hair: 'bald', face: 'calm', beard: true, tattoos: true, neckTattoo: true, wraps: true,
    colors: {
      skin: '#8a5a3a', top: '#8a5a3a', pants: '#0e0e12', accent: '#b3141a', menu: '#d01e1e', trim: '#b3141a',
      shoe: '#141418', hair: '#141010', beard: '#2a1e18', glove: '#b3141a', wrap: '#2a2a2e', ink: '#1a1e1c', eyes: '#2a1a10', aura: '#ff4030',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [40, 70], armB: [30, 60] },
    victory: { ...G, torso: 4, armF: [150, 170], armB: [145, 165] },
  },
  ai: { specialRange: [300, 800], jumpIn: 0.05, walkIn: 0.95 },
  moves: {
    ...moveset({
    lp: { damage: 37, startup: 6 },
    lk: { damage: 66, startup: 7 },
    hp: { damage: 115, startup: 11, knockback: 520 },
    f_lp: { damage: 29, hits: 3 },
  }),
    special: orb('Fuego Infernal', '#ff5b2e', '#fff1c2'),
    super: beamSuper('LLAMARADA', '#ff3a1e', '#fff6d8'),
  },
};
