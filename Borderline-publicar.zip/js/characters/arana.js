// LA ARAÑA: pelea sentado en su patineta; no usa las piernas. Brazos de acero y ruedas rápidas:
// todos sus golpes son con los puños (y la tabla), y su poder es una rodada que embiste.
import { moveset, rush, spinSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

// sus "patadas" son golpes de brazo
const ARM = { windup: 'heavyWind', strike: 'heavy' };

export default {
  id: 'arana',
  name: 'LA ARAÑA',
  title: 'El Rey de la Banqueta', // apodo
  profile: { apodo: 'El Rey de la Banqueta', edad: 30, estatura: '1.70 m', peso: '68 kg' },
  stats: {
    hp: 1050, width: 92, height: 124,
    walkF: 330, walkB: 260,
    jumpV: 1150, jumpVX: 330,
    dashSpeed: 900, dashFrames: 13,
    backdashSpeed: 720, backdashFrames: 14,
  },
  look: {
    skate: true, seat: 30,
    thigh: 38, shin: 34, torso: 64, upperArm: 42, foreArm: 41,
    headR: 14.5, limbW: 16, torsoW: 42,
    build: { shoulder: 1.42, chest: 1.24, waist: 0.84, hip: 0.95 },
    top: 'none', bottom: 'pants', feet: 'sneakers', gloves: 'fingerless',
    hair: 'long', slick: true, face: 'snarl', goatee: true, tattoos: true, wraps: true, sweat: true,
    colors: {
      skin: '#c48a60', top: '#c48a60', pants: '#2a2a32', accent: '#b3141a', menu: '#d01e1e', trim: '#b3141a', belt: '#141416',
      shoe: '#141416', hair: '#141010', beard: '#1e1614', glove: '#141416', wrap: '#b3141a', ink: '#1a1e1c', eyes: '#2a1a10', aura: '#ff3a1e',
      board: '#b3141a', wheel: '#f0e6c8',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [100, 170], armB: [90, 160] },
    victory: { ...G, torso: 4, armF: [172, 178], armB: [160, 172] },
  },
  ai: { specialRange: [0, 200], jumpIn: 0.08, walkIn: 0.9 },
  moves: {
    ...moveset({
      lp: { damage: 28, startup: 4, hitbox: { x: 30, y: 85, w: 66, h: 26 } },
      lk: { name: 'Recto', damage: 50, ...ARM, hitbox: { x: 30, y: 78, w: 82, h: 30 } },
      hp: { damage: 84, hitbox: { x: 15, y: 80, w: 76, h: 40 } },
      c_lk: { name: 'Tablazo', windup: 'cJabWind', strike: 'cJab', hitbox: { x: 30, y: 8, w: 80, h: 30 } },
      j_lk: { name: 'Recto aéreo', windup: 'jPunchWind', strike: 'jCross', hitbox: { x: 25, y: 20, w: 66, h: 46 } },
      f_lp: { hitbox: { x: 25, y: 80, w: 75, h: 40 } },
      f_lk: { name: 'Golpe giratorio', windup: 'hookWind', strike: 'hook', hitbox: { x: 15, y: 75, w: 86, h: 46 } },
      c_hp: { hitbox: { x: 5, y: 60, w: 60, h: 110 } },
    }),
    special: rush('Rodada', { motion: [{ from: 5, to: 22, vx: 1000 }], hitbox: { x: 20, y: 10, w: 90, h: 60 } }),
    super: spinSuper('TORNADO SOBRE RUEDAS', { hitbox: { x: -30, y: 10, w: 140, h: 90 } }),
  },
};
