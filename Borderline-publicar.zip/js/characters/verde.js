// VERDE: melena clara ondulada, playera verde con cuello rojo y jeans.
// Basado en la foto assets/portraits/verde.webp. Estilo: peleador a distancia con proyectil.
// Cambia `name` para ponerle otro nombre.
import { moveset } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'verde',
  name: 'VERDE',
  title: 'Ponte la verde con furia',
  portrait: 'assets/portraits/verde.webp',
  portraitFocus: 0.2,
  stats: {
    hp: 1000, width: 70, height: 194,
    walkF: 280, walkB: 220,
    jumpV: 1270, jumpVX: 310,
    dashSpeed: 760, dashFrames: 13,
    backdashSpeed: 640, backdashFrames: 15,
  },
  look: {
    thigh: 48, shin: 47, torso: 64, upperArm: 39, foreArm: 38,
    headR: 14.5, limbW: 14, torsoW: 38,
    build: { shoulder: 1.25, chest: 1.12, waist: 0.84, hip: 0.95 },
    top: 'tshirt', bottom: 'pants', feet: 'sneakers', gloves: 'none',
    hair: 'long', face: 'smile', wristbands: false,
    colors: {
      skin: '#d6a37b', top: '#1e8c5a', pants: '#93b9d8', accent: '#e23b33', belt: '#5a4632',
      shoe: '#efe9dc', hair: '#a27a48', collar: '#e23b33', shirtText: '#f5f5f0', eyes: '#5a3a1c',
      glove: '#1a1a1a', aura: '#25d07a',
    },
  },
  poses: {
    // como en la foto: una mano agarrando la playera, la otra en la bolsa
    intro: { ...G, torso: 2, armF: [35, -165], armB: [6, -8], legF: [14, 0], legB: [-12, -4] },
    victory: { ...G, torso: 2, armF: [35, -165], armB: [170, 175], legF: [14, 0], legB: [-12, -4] },
  },
  ai: { specialRange: [0, 140], jumpIn: 0.12 },
  // Borderline: sólo golpes de puño (ver common.js)
  moves: moveset({}),
};
