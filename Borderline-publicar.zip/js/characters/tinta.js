// TINTA: peleador tatuado de short negro. Pesado, pega más fuerte pero más lento.
import { moveset, grab, clawSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'tinta',
  name: 'ROX',
  title: 'La Tinta', // apodo
  profile: { apodo: 'La Tinta', edad: 31, estatura: '1.82 m', peso: '88 kg' },
  stats: {
    hp: 1200, width: 74, height: 196,
    walkF: 255, walkB: 200,
    jumpV: 1200, jumpVX: 280,
    dashSpeed: 700, dashFrames: 14,
    backdashSpeed: 600, backdashFrames: 16,
  },
  look: {
    thigh: 50, shin: 49, torso: 67, upperArm: 40, foreArm: 39,
    headR: 14.5, limbW: 16.5, torsoW: 42,
    build: { shoulder: 1.36, chest: 1.22, waist: 0.86, hip: 1.0 },
    top: 'none', bottom: 'shorts', feet: 'bare', gloves: 'fingerless',
    hair: 'buzz', face: 'calm', tattoos: true, wraps: true,
    colors: {
      skin: '#d9a275', top: '#d9a275', pants: '#141418', accent: '#c8262c', trim: '#e8e8e8',
      shoe: '#d9a275', hair: '#ecd27a', glove: '#e8c228', wrap: '#c8262c', ink: '#2f3a36', eyes: '#4a5a6a', aura: '#e8c228',
    },
  },
  poses: {
    intro: { ...G, torso: 12, armF: [40, 60], armB: [30, 50] },
    victory: { ...G, torso: 6, armF: [165, 172], armB: [20, 30] },
  },
  ai: { specialRange: [0, 110], jumpIn: 0.12, walkIn: 0.85 },
  moves: {
    ...moveset({
    lp: { damage: 34, startup: 5 },
    lk: { damage: 60 },
    hp: { damage: 104, startup: 10 },
    f_lp: { damage: 27 },
  }),
    special: grab('Llave Mortal'),
    super: clawSuper('SUMISIÓN TOTAL'),
  },
};
