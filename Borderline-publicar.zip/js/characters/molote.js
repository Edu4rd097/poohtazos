// MOLOTE: delgado y moreno, 1.74 m. Ligero y rápido: entra, pega y se va.
import { moveset, rush, spinSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'molote',
  name: 'MOLOTE',
  title: 'El Flaco', // apodo
  profile: { apodo: 'El Flaco', edad: 24, estatura: '1.74 m', peso: '63 kg' },
  stats: {
    hp: 950, width: 64, height: 186,
    walkF: 315, walkB: 240,
    jumpV: 1300, jumpVX: 340,
    dashSpeed: 850, dashFrames: 12,
    backdashSpeed: 700, backdashFrames: 14,
  },
  look: {
    thigh: 48, shin: 47, torso: 61, upperArm: 39, foreArm: 38,
    headR: 13.8, limbW: 12.5, torsoW: 32,
    build: { shoulder: 1.12, chest: 1.0, waist: 0.72, hip: 0.88 },
    top: 'none', bottom: 'shorts', feet: 'bare', gloves: 'fingerless',
    hair: 'spiky', face: 'snarl', wraps: true, sweat: true,
    colors: {
      skin: '#a8683e', top: '#a8683e', pants: '#121216', accent: '#3ab0d1', menu: '#3ab0d1', trim: '#3ab0d1',
      shoe: '#a8683e', hair: '#120c08', glove: '#3ab0d1', wrap: '#e8e4da', eyes: '#2a1a10', aura: '#3ab0d1',
    },
  },
  poses: {
    intro: { ...G, torso: 8, armF: [90, 170], armB: [80, 160] },
    victory: { ...G, torso: 2, armF: [170, 178], armB: [110, 150] },
  },
  ai: { specialRange: [0, 170], jumpIn: 0.15, walkIn: 0.85 },
  moves: {
    ...moveset({
      lp: { damage: 25, startup: 3 },
      lk: { damage: 46, startup: 5 },
      hp: { damage: 76, startup: 8 },
      f_lp: { hits: 5, hitInterval: 3, damage: 18, motion: [{ from: 5, to: 22, vx: 300 }] },
    }),
    special: rush('Molotazo', { motion: [{ from: 6, to: 20, vx: 960 }] }),
    super: spinSuper('MOLOTE TOTAL', { hits: 7, hitInterval: 4 }),
  },
};
