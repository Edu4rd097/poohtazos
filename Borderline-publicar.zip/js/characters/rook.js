// ROOK — peleador balanceado, con proyectil. Personaje original del motor.
import { moveset } from './common.js';

export default {
  id: 'rook',
  name: 'ROOK',
  stats: {
    hp: 1000, width: 70, height: 190,
    walkF: 260, walkB: 200,
    jumpV: 1250, jumpVX: 300,
    dashSpeed: 720, dashFrames: 14,
    backdashSpeed: 620, backdashFrames: 16,
  },
  look: {
    thigh: 48, shin: 47, torso: 63, upperArm: 38, foreArm: 38,
    headR: 14.5, limbW: 14, torsoW: 36,
    build: { shoulder: 1.25, chest: 1.1, waist: 0.82, hip: 0.95 },
    top: 'jacket', bottom: 'pants', feet: 'boots', gloves: 'full', studs: true, chain: true,
    hair: 'spiky', face: 'calm',
    colors: {
      skin: '#d9a37a', top: '#6e1f22', top2: '#3a3f4a', pants: '#24242c', accent: '#b8b2a8',
      shoe: '#17171d', hair: '#4a3626', glove: '#ffb43a', belt: '#1a1a1f', eyes: '#3a2414', aura: '#ff8a3d',
    },
  },
  ai: { specialRange: [0, 140], jumpIn: 0.12 },
  // Borderline: sólo golpes de puño (ver common.js)
  moves: moveset({
      lk: { damage: 55 },
    }),
};
