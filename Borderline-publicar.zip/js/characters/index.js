// Registro de personajes. Para agregar uno: crea su archivo y añádelo aquí.
// Todos pelean a puño limpio, en short blanco o short negro, cada uno con su estatura y peso.
// rook.js, vela.js, garra.js y verde.js siguen en la carpeta por si quieres regresarlos.
import bravo from './bravo.js';
import tinta from './tinta.js';
import lokillo from './lokillo.js';
import grenas from './grenas.js';
import tupapa from './tupapa.js';
import pinguino from './pinguino.js';
import dimon from './dimon.js';
import ranchero from './ranchero.js';
import teto from './teto.js';
import molote from './molote.js';
import arana from './arana.js';

export const CHARACTERS = [bravo, tinta, lokillo, grenas, tupapa, pinguino, dimon, ranchero, teto, molote, arana];
