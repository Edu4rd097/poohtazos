// PINGÜINO: bajito y panzón, camina de lado: difícil de tumbar.
import { moveset, orb, beamSuper } from './common.js';
import { BASE_POSES } from './poses.js';

const G = BASE_POSES.guard;

export default {
  id: 'pinguino',
  name: 'PINGÜINO',
  title: 'El Panzas', // apodo
  profile: { apodo: 'El Panzas', edad: 38, estatura: '1.62 m', peso: '98 kg' },
  stats: {
    hp: 1300, width: 80, height: 172,
    walkF: 220, walkB: 180,
    jumpV: 1120, jumpVX: 250,
    dashSpeed: 640, dashFrames: 15,
    backdashSpeed: 560, backdashFrames: 17,
  },
  look: {
    thigh: 40, shin: 38, torso: 61, upperArm: 34, foreArm: 33,
    headR: 15.5, limbW: 17, torsoW: 47,
    build: { shoulder: 1.18, chest: 1.3, waist: 1.24, hip: 1.18 },
    top: 'none', bottom: 'shorts', feet: 'sneakers', gloves: 'fingerless',
    hair: 'buzz', face: 'calm', stubble: true, wraps: true, sweat: true,
    colors: {
      skin: '#d9a07a', top: '#d9a07a', pants: '#101014', accent: '#e8e8e8', menu: '#e8e8e8', trim: '#e8e8e8',
      shoe: '#1a1a1e', hair: '#141418', glove: '#e8e8e8', wrap: '#1a1a1e', eyes: '#2a1a10', aura: '#e8e8e8',
    },
  },
  poses: {
    intro: { ...G, torso: 10, armF: [40, 60], armB: [30, 50] },
    victory: { ...G, torso: 4, armF: [150, 170], armB: [145, 165] },
  },
  ai: { specialRange: [300, 800], jumpIn: 0.04, walkIn: 0.95 },
  moves: {
    ...moveset({
    lp: { damage: 30, startup: 5 },
    lk: { damage: 56 },
    hp: { damage: 96, startup: 10 },
    f_lp: { damage: 26 },
  }),
    special: orb('Bola de Hielo', '#5ac8ff', '#ffffff'),
    super: beamSuper('VENTISCA', '#3aa0ff', '#ffffff', '#e8f6ff'),
  },
};
