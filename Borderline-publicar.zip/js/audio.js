// Efectos de sonido sintetizados con WebAudio (sin archivos externos).
let ctx = null;

export function initAudio() {
  if (!ctx) {
    try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { return; }
  }
  if (ctx.state === 'suspended') ctx.resume();
}

function noise(dur, freq, gain, type = 'bandpass') {
  if (!ctx) return;
  const len = Math.floor(ctx.sampleRate * dur);
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const f = ctx.createBiquadFilter();
  f.type = type; f.frequency.value = freq;
  const g = ctx.createGain();
  g.gain.value = gain;
  src.connect(f).connect(g).connect(ctx.destination);
  src.start();
}

function tone(freq, dur, type, gain, slideTo) {
  if (!ctx) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, ctx.currentTime);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, ctx.currentTime + dur);
  g.gain.setValueAtTime(gain, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
  o.connect(g).connect(ctx.destination);
  o.start();
  o.stop(ctx.currentTime + dur);
}

export const sfx = {
  hit(strength = 'light') {
    const k = { light: 1, medium: 1.4, heavy: 1.9, super: 1.5 }[strength] || 1;
    noise(0.08 * k, 1800 / k, 0.35);
    tone(160 / k, 0.12 * k, 'square', 0.18, 50);
  },
  block() { noise(0.05, 4000, 0.25, 'highpass'); tone(900, 0.05, 'triangle', 0.08); },
  whoosh() { noise(0.09, 700, 0.12); },
  thud() { tone(90, 0.2, 'sine', 0.3, 40); noise(0.12, 300, 0.2, 'lowpass'); },
  projectile() { tone(300, 0.25, 'sawtooth', 0.08, 900); },
  super() { tone(200, 0.6, 'sawtooth', 0.12, 1200); noise(0.4, 2500, 0.15); },
  ko() { tone(400, 0.9, 'square', 0.15, 60); },
  announce() { tone(660, 0.12, 'triangle', 0.12); },
};
