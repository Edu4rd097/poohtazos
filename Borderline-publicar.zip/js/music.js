// Música: lista de canciones 8-bit (comprimidas a AAC mono ~80 kbps) que suena en orden
// aleatorio en el menú y en las peleas. Cada vez que cambias de pantalla (menú → pelea,
// revancha, regreso al menú) entra otra canción al azar; al terminar una, sigue otra.
const TRACKS = ['hammer', 'club', 'arise', 'eaten', 'raining', 'intheend', 'somewhere', 'whativedone', 'numb', 'loseyourself', 'wilddogs', 'zombieritual'].map(n => `assets/audio/${n}.m4a`);

const audio = new Audio();
audio.volume = 0.5;
audio.preload = 'auto';
let order = [], last = null, unlocked = false, wantPlay = false;

function nextTrack() {
  if (!order.length) {
    order = TRACKS.slice().sort(() => Math.random() - 0.5);
    if (order[0] === last && order.length > 1) order.push(order.shift()); // no repetir la misma seguida
  }
  last = order.shift();
  return last;
}

function play() { wantPlay = true; if (unlocked) audio.play().catch(() => {}); }

// cambia a otra canción al azar
export function shuffleMusic() {
  audio.src = nextTrack();
  play();
}
export function pauseMusic() { wantPlay = false; audio.pause(); }
export function resumeMusic() { play(); }

audio.addEventListener('ended', shuffleMusic);

// el navegador sólo deja sonar audio después de que el usuario toca algo
function unlock() {
  if (unlocked) return;
  unlocked = true;
  if (!audio.src) audio.src = nextTrack();
  if (wantPlay) audio.play().catch(() => {});
}
window.addEventListener('pointerdown', unlock, true);
window.addEventListener('keydown', unlock, true);

window.__music = audio; // para depurar
