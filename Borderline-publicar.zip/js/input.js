// Teclado → estado de botones por cuadro. Usa e.code (independiente del idioma del teclado).
export const BINDINGS = {
  p1: {
    up: ['KeyW'], down: ['KeyS'], left: ['KeyA'], right: ['KeyD'],
    lp: ['KeyJ'], lk: ['KeyK'], hp: ['KeyL'], sp: ['KeyU'], su: ['KeyI'],
  },
  p2: {
    up: ['ArrowUp'], down: ['ArrowDown'], left: ['ArrowLeft'], right: ['ArrowRight'],
    lp: ['Numpad1', 'Comma'], lk: ['Numpad2', 'Period'], hp: ['Numpad3', 'Slash'],
    sp: ['Numpad4', 'Semicolon'], su: ['Numpad5', 'Quote'],
  },
};

const BOUND = new Set(Object.values(BINDINGS).flatMap(b => Object.values(b).flat()));
const held = new Set();
// Teclas pulsadas desde el último cuadro: así un toque más corto que un cuadro no se pierde.
const pulse = new Set();

window.addEventListener('keydown', e => {
  if (e.target.closest?.('input, textarea')) return; // no robar teclas al escribir
  if (BOUND.has(e.code)) e.preventDefault();
  held.add(e.code);
  if (!e.repeat) pulse.add(e.code);
});
window.addEventListener('keyup', e => held.delete(e.code));
window.addEventListener('blur', () => { held.clear(); pulse.clear(); });

// Llamar una vez por cuadro, después de que todas las entradas hicieron poll().
export function endInputFrame() { pulse.clear(); }

const KEYS = ['up', 'down', 'left', 'right', 'lp', 'lk', 'hp', 'sp', 'su'];

class BaseInput {
  constructor() { this.state = {}; this.pressed = {}; this.prev = {}; }
  commit(next) {
    for (const k of KEYS) this.pressed[k] = !!next[k] && !this.prev[k];
    this.state = next;
    this.prev = next;
  }
}

// Entrada de un jugador humano
export class KeyboardInput extends BaseInput {
  constructor(binding) { super(); this.binding = binding; }
  poll() {
    const s = {};
    for (const k of KEYS) s[k] = this.binding[k].some(c => held.has(c) || pulse.has(c));
    this.commit(s);
  }
}

// Entrada controlada por código (IA, repeticiones, red...)
export class VirtualInput extends BaseInput {
  constructor() { super(); this.next = {}; }
  set(heldButtons, taps = []) {
    this.next = { ...heldButtons };
    for (const t of taps) this.next[t] = true;
  }
  poll() { this.commit(this.next); }
}

// Controles táctiles (celular): presionan/sueltan una tecla como si fuera el teclado.
export function virtualKey(code, down) {
  if (down) { if (!held.has(code)) pulse.add(code); held.add(code); }
  else held.delete(code);
}
