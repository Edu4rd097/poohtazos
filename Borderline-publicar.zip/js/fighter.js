// Luchador: máquina de estados + física. No sabe dibujarse (eso está en render/rig.js)
// y no resuelve golpes (eso lo hace Match). Todo lo específico vive en la definición
// del personaje (characters/*.js).
import {
  STAGE, GRAVITY, DT, METER_MAX, INPUT_BUFFER, DASH_WINDOW,
  KNOCKDOWN_FRAMES, GETUP_FRAMES,
} from './config.js';
import { BASE_POSES } from './characters/poses.js';

const BUFFERED = ['lp', 'lk', 'hp', 'sp', 'su'];
const ATTACK_ORDER = ['su', 'sp', 'hp', 'lk', 'lp'];
const FACE_STATES = new Set(['idle', 'walk', 'crouch', 'land', 'blockstun']);

export class Fighter {
  constructor(def, side, input) {
    this.def = def;
    this.side = side;          // 0 = izquierda, 1 = derecha
    this.input = input;
    this.poses = { ...BASE_POSES, ...(def.poses || {}) };
    this.meter = 0;            // se conserva entre rondas
    this.wins = 0;
    this.reset();
  }

  reset() {
    this.x = this.side === 0 ? STAGE.width * 0.3 : STAGE.width * 0.7;
    this.y = 0;                // altura sobre el piso (positivo = arriba)
    this.vx = 0; this.vy = 0;
    this.pushback = 0;         // empuje extra (p. ej. al pegarle a alguien en la esquina)
    this.facing = this.side === 0 ? 1 : -1;
    this.hp = this.def.stats.hp;
    this.hpShown = this.hp;
    this.state = 'idle'; this.stateFrame = 0;
    this.move = null; this.moveName = null; this.moveFrame = 0;
    this.hitsLanded = 0; this.lastHitFrame = -99; this.connected = false;
    this.stun = 0; this.invuln = 0; this.comboTaken = 0;
    this.dead = false; this.locked = true; this.atWall = 0;
    this.buffer = {}; this.lastTap = { dir: null, frame: -99 }; this.frame = 0;
    this.airActionUsed = false; this.flash = 0;
    this.projectile = null;
  }

  // ---------- consultas ----------
  get airborne() { return this.y > 0 || this.vy > 0; }
  get fwdKey() { return this.facing === 1 ? 'right' : 'left'; }
  get backKey() { return this.facing === 1 ? 'left' : 'right'; }
  holdingDown() { return !!this.input.state.down; }
  holdingForward() { return !!this.input.state[this.fwdKey]; }

  phase() {
    if (this.state !== 'attack') return null;
    const m = this.move, f = this.moveFrame;
    if (f <= m.startup) return 'startup';
    if (f <= m.startup + m.active) return 'active';
    return 'recovery';
  }

  canBlock() {
    return !this.locked && !this.airborne &&
      ['idle', 'walk', 'crouch', 'blockstun'].includes(this.state);
  }

  // ¿Está sosteniendo "atrás" respecto a una fuente de daño en sourceX?
  holdingAwayFrom(sourceX) {
    const away = sourceX < this.x ? 'right' : 'left';
    return !!this.input.state[away];
  }

  hurtbox() {
    if (this.dead || ['knockdown', 'getup', 'ko'].includes(this.state)) return null;
    const s = this.def.stats;
    let h = s.height, y = this.y;
    const crouching = this.state === 'crouch' ||
      (this.state === 'blockstun' && this.holdingDown()) ||
      (this.state === 'attack' && this.move.crouch && this.phase() !== 'recovery');
    if (crouching) h *= 0.68;
    else if (this.airborne) { h *= 0.8; y += 15; }
    return { x: this.x - s.width / 2, y, w: s.width, h };
  }

  worldRect(b) {
    const x = this.facing === 1 ? this.x + b.x : this.x - b.x - b.w;
    return { x, y: this.y + b.y, w: b.w, h: b.h };
  }

  activeHitbox() {
    if (this.phase() !== 'active' || !this.move.hitbox) return null;
    const m = this.move;
    if (this.hitsLanded >= (m.hits || 1)) return null;
    if (this.hitsLanded > 0 && this.moveFrame - this.lastHitFrame < (m.hitInterval || 1)) return null;
    return this.worldRect(m.hitbox);
  }

  // ---------- entrada ----------
  // Se llama TODOS los cuadros (incluso durante el hitstop) para no perder pulsaciones.
  readInput() {
    this.frame++;
    this.input.poll();
    const p = this.input.pressed;
    for (const b of BUFFERED) if (p[b]) this.buffer[b] = INPUT_BUFFER;
    for (const dir of ['left', 'right']) {
      if (!p[dir]) continue;
      if (this.lastTap.dir === dir && this.frame - this.lastTap.frame <= DASH_WINDOW) {
        this.buffer['dash_' + dir] = INPUT_BUFFER;
        this.lastTap = { dir: null, frame: -99 };
      } else {
        this.lastTap = { dir, frame: this.frame };
      }
    }
  }

  consume(b) {
    if (this.buffer[b] > 0) { this.buffer[b] = 0; return true; }
    return false;
  }

  go(state) { if (this.state !== state) { this.state = state; this.stateFrame = 0; } }
  setState(state) { this.state = state; this.stateFrame = 0; }

  // ---------- ataques ----------
  moveForButton(b) {
    const moves = this.def.moves;
    if (b === 'su') return this.airborne ? null : 'super';
    if (b === 'sp') return this.airborne ? null : 'special';
    if (this.airborne) return 'j_' + b;
    const crouched = 'c_' + b;
    if (this.holdingDown() && moves[crouched]) return crouched;
    if (this.holdingForward() && moves['f_' + b]) return 'f_' + b; // adelante + botón
    return b;
  }

  canUse(m) {
    if (!m) return false;
    if (m.cost && this.meter < m.cost) return false;
    if (m.projectile && this.projectile && this.projectile.alive) return false;
    return true;
  }

  tryAttack(match, allowed = null) {
    if (this.locked) return false;
    for (const b of ATTACK_ORDER) {
      if (!(this.buffer[b] > 0)) continue;
      const name = this.moveForButton(b);
      if (!name || (allowed && !allowed.includes(name))) continue;
      const m = this.def.moves[name];
      if (!this.canUse(m)) continue;
      this.buffer[b] = 0;
      this.doMove(name, match);
      return true;
    }
    return false;
  }

  doMove(name, match) {
    const m = this.def.moves[name];
    this.move = m; this.moveName = name; this.moveFrame = 0;
    this.hitsLanded = 0; this.lastHitFrame = -99; this.connected = false;
    this.setState('attack');
    if (!this.airborne) this.vx = 0;
    else this.airActionUsed = true;
    if (m.cost) this.meter -= m.cost;
    if (m.invuln) this.invuln = m.invuln;
    if (m.super) match.startSuper(this);
    else match.sfx('whoosh');
  }

  attackStep(match) {
    const m = this.move;
    const f = ++this.moveFrame;
    let moving = false;
    for (const seg of m.motion || []) {
      if (f >= seg.from && f <= seg.to) { this.vx = this.facing * seg.vx; moving = true; }
    }
    if (!this.airborne && !moving) this.vx = 0;
    if (m.projectile && f === m.startup) match.spawnProjectile(this, m.projectile);

    // Cancelar un golpe que conectó (o fue bloqueado) en otro: así salen los combos.
    if (this.connected && m.cancels && f > m.startup && this.tryAttack(match, m.cancels)) return;

    if (f >= m.startup + m.active + m.recovery) {
      this.move = null; this.moveName = null;
      if (this.airborne) { this.setState('air'); this.airActionUsed = true; }
      else this.setState(this.holdingDown() ? 'crouch' : 'idle');
    }
  }

  // ---------- control en el piso ----------
  groundControl(match) {
    const s = this.input.state, st = this.def.stats;
    if (this.locked) { this.vx = 0; this.go('idle'); return; }
    if (this.tryAttack(match)) return;

    if (s.up) {
      this.vy = st.jumpV;
      this.vx = s[this.fwdKey] ? this.facing * st.jumpVX
        : s[this.backKey] ? -this.facing * st.jumpVX : 0;
      this.airActionUsed = false;
      this.setState('air');
      return;
    }
    if (this.consume('dash_' + this.fwdKey)) {
      this.vx = this.facing * st.dashSpeed; this.setState('dash'); return;
    }
    if (this.consume('dash_' + this.backKey)) {
      this.vx = -this.facing * st.backdashSpeed; this.invuln = 6; this.setState('backdash'); return;
    }
    if (s.down) { this.vx = 0; this.go('crouch'); }
    else if (s[this.fwdKey]) { this.vx = this.facing * st.walkF; this.go('walk'); }
    else if (s[this.backKey]) { this.vx = -this.facing * st.walkB; this.go('walk'); }
    else { this.vx = 0; this.go('idle'); }
  }

  // ---------- actualización por cuadro ----------
  update(opp, match) {
    // Mientras un golpe está saliendo, los botones pulsados se conservan: así se puede
    // "teclear" el siguiente golpe del combo antes de que el primero conecte.
    const holdBuffer = this.state === 'attack' && this.phase() !== 'recovery';
    if (!holdBuffer) for (const k in this.buffer) if (this.buffer[k] > 0) this.buffer[k]--;
    if (this.invuln > 0) this.invuln--;
    if (this.flash > 0) this.flash--;
    this.stateFrame++;
    const st = this.def.stats;

    switch (this.state) {
      case 'idle': case 'walk': case 'crouch':
        this.groundControl(match);
        break;
      case 'dash':
        if (this.stateFrame > 4 && this.tryAttack(match)) break;
        if (this.stateFrame >= st.dashFrames) { this.vx = 0; this.setState('idle'); }
        break;
      case 'backdash':
        if (this.stateFrame >= st.backdashFrames) { this.vx = 0; this.setState('idle'); }
        break;
      case 'air':
        if (!this.airActionUsed) this.tryAttack(match);
        break;
      case 'land':
        this.vx = 0;
        if (this.stateFrame >= 4) this.setState('idle');
        break;
      case 'attack':
        this.attackStep(match);
        break;
      case 'hitstun': case 'blockstun':
        if (--this.stun <= 0) {
          if (this.state === 'hitstun') this.comboTaken = 0;
          this.setState(this.holdingDown() ? 'crouch' : 'idle');
        }
        break;
      case 'knockdown':
        if (this.stateFrame >= KNOCKDOWN_FRAMES) { this.setState('getup'); this.invuln = GETUP_FRAMES + 6; }
        break;
      case 'getup':
        if (this.stateFrame >= GETUP_FRAMES) { this.comboTaken = 0; this.setState('idle'); }
        break;
      default: break; // airhit / ko / win: sólo física
    }

    this.physics(match);

    if (FACE_STATES.has(this.state) && Math.abs(opp.x - this.x) > 4) {
      this.facing = opp.x > this.x ? 1 : -1;
    }
  }

  physics(match) {
    if (this.airborne) {
      this.vy -= GRAVITY * DT;
      this.y += this.vy * DT;
      this.x += this.vx * DT;
      if (this.y <= 0) { this.y = 0; this.vy = 0; this.onLand(match); }
    } else {
      this.x += this.vx * DT;
      if (['hitstun', 'blockstun', 'knockdown', 'getup', 'ko'].includes(this.state)) this.vx *= 0.86;
    }
    if (this.pushback) {
      this.x += this.pushback * DT;
      this.pushback *= 0.82;
      if (Math.abs(this.pushback) < 5) this.pushback = 0;
    }
    this.clampToStage();
  }

  clampToStage() {
    const half = this.def.stats.width / 2;
    const min = STAGE.wall + half, max = STAGE.width - STAGE.wall - half;
    this.atWall = 0;
    if (this.x <= min) { this.x = min; this.atWall = -1; }
    if (this.x >= max) { this.x = max; this.atWall = 1; }
  }

  onLand(match) {
    switch (this.state) {
      case 'air':
        this.vx = 0; this.setState('land');
        break;
      case 'attack':
        if (this.move.air) { this.move = null; this.vx = 0; this.setState('land'); }
        break;
      case 'airhit':
        this.vx *= 0.3;
        this.setState(this.dead ? 'ko' : 'knockdown');
        match.shake(4, 8);
        match.sfx('thud');
        break;
      default:
        break;
    }
  }
}
