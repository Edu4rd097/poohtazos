// Botón "Instalar": instala Borderline como app (PWA) desde el navegador.
//   - Chrome/Edge/Android: usa el aviso nativo (beforeinstallprompt, capturado en index.html)
//   - iPhone/iPad (Safari): no hay aviso nativo; se explica cómo agregarlo a la pantalla de inicio
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

export function canInstall() {
  if (standalone()) return false;           // ya está instalada
  return !!window.__installPrompt || isIOS;
}

// devuelve un mensaje para mostrar (iPhone) o null
export async function install() {
  const ev = window.__installPrompt;
  if (ev) {
    ev.prompt();
    try { await ev.userChoice; } catch (e) { /* cancelado */ }
    window.__installPrompt = null;
    return null;
  }
  if (isIOS) return 'En Safari toca Compartir y luego "Agregar a pantalla de inicio".';
  return null;
}

export function installHint(text) {
  const n = document.createElement('div');
  n.className = 'toast';
  n.textContent = text;
  document.getElementById('app').appendChild(n);
  setTimeout(() => n.remove(), 6000);
}

// service worker: permite instalarla y jugar sin conexión
// (en Angular el juego carga después del evento "load", por eso se revisa readyState)
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  const reg = () => navigator.serviceWorker.register('sw.js').catch(() => {});
  if (document.readyState === 'complete') reg(); else window.addEventListener('load', reg);
}
