// Controles táctiles para celular y tableta.
//   - cruz de dirección (joystick) a la izquierda: arrastra el dedo; 8 direcciones (W A S D)
//   - botones a la derecha: Jab, Patada, Gancho, Ráfaga, Giro (J K L U I)
//   - pausa arriba; en pausa o al terminar la pelea aparecen Revancha y Menú
// Sólo se muestran en pantallas táctiles y mientras hay una pelea.
import { virtualKey } from './input.js';

export const isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;

const root = document.getElementById('touch');

export function initTouch() {
  if (!isTouch) return;
  document.body.classList.add('touch');

  // ---- joystick ----
  const pad = root.querySelector('.pad'), knob = pad.querySelector('.knob');
  const DIRS = { up: 'KeyW', down: 'KeyS', left: 'KeyA', right: 'KeyD' };
  let padId = null;
  const setDirs = on => { for (const k in DIRS) virtualKey(DIRS[k], !!on[k]); };
  const movePad = e => {
    const r = pad.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    const R = r.width / 2, len = Math.hypot(dx, dy), k = Math.min(1, R * 0.6 / (len || 1));
    knob.style.transform = `translate(${dx * k}px, ${dy * k}px)`;
    const dead = R * 0.25, a = Math.atan2(dy, dx) * 180 / Math.PI;
    if (len < dead) return setDirs({});
    setDirs({
      right: a > -67.5 && a < 67.5, left: a > 112.5 || a < -112.5,
      down: a > 22.5 && a < 157.5, up: a < -22.5 && a > -157.5,
    });
  };
  pad.addEventListener('pointerdown', e => {
    padId = e.pointerId;
    try { pad.setPointerCapture(padId); } catch (err) { /* el dedo ya se soltó */ }
    movePad(e);
  });
  pad.addEventListener('pointermove', e => { if (e.pointerId === padId) movePad(e); });
  const endPad = e => { if (e.pointerId !== padId) return; padId = null; knob.style.transform = ''; setDirs({}); };
  pad.addEventListener('pointerup', endPad);
  pad.addEventListener('pointercancel', endPad);

  // ---- botones de golpe (se mantienen mientras el dedo esté encima) ----
  for (const b of root.querySelectorAll('[data-key]')) {
    const code = b.dataset.key;
    const down = e => { e.preventDefault(); b.classList.add('down'); virtualKey(code, true); navigator.vibrate?.(8); };
    const up = () => { b.classList.remove('down'); virtualKey(code, false); };
    b.addEventListener('pointerdown', down);
    b.addEventListener('pointerup', up);
    b.addEventListener('pointercancel', up);
    b.addEventListener('pointerleave', up);
  }
  // ---- pausa / revancha / menú: un toque = una tecla ----
  for (const b of root.querySelectorAll('[data-tap]')) {
    b.addEventListener('pointerdown', e => {
      e.preventDefault();
      window.dispatchEvent(new KeyboardEvent('keydown', { code: b.dataset.tap }));
    });
  }
  // sin menú contextual ni zoom por doble toque
  root.addEventListener('contextmenu', e => e.preventDefault());

  // mostrar Revancha/Menú cuando la pelea está en pausa o terminó
  const end = root.querySelector('.end');
  (function watch() {
    const m = window.__match;
    const on = !!(document.body.classList.contains('playing') && m && (m.paused || m.over));
    end.classList.toggle('show', on);
    if (on) end.classList.toggle('over', !!m.over); // en pausa: Continuar · al terminar: Revancha
    requestAnimationFrame(watch);
  })();
}

// Pantalla completa y horizontal al empezar a pelear (Android lo permite; iPhone lo ignora)
export function goFullscreen() {
  if (!isTouch || document.fullscreenElement) return;
  const el = document.documentElement;
  (el.requestFullscreen?.({ navigationUI: 'hide' }) || Promise.resolve())
    .then(() => screen.orientation?.lock?.('landscape'))
    .catch(() => {});
}
