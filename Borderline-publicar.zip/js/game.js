// Match: rondas, resolución de golpes, proyectiles, hitstop, efectos y dibujo de la escena.
import {
  STAGE, FPS, ROUND_TIME, ROUNDS_TO_WIN, METER_MAX, HITSTOP, SHAKE,
  COMBO_SCALING, MIN_SCALING, DT, CAMERA_ZOOM,
} from './config.js';
import { Fighter } from './fighter.js';
import { drawStage } from './render/stage.js';
import { drawFighter, drawShadow, poseFor } from './render/rig.js';
import { RetroScreen } from './render/retro.js';
import { sparkBurst, bloodSplash, flame, updateFx, drawFx, drawProjectile, projectileTrail } from './render/fx.js';
import { drawHUD } from './render/hud.js';
import { sfx } from './audio.js';
import { endInputFrame } from './input.js';

const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

export class Match {
  // defs: [defP1, defP2]; inputs: [inputP1, inputP2]; ais: [aiP1|null, aiP2|null] (fábricas)
  constructor({ defs, inputs, makeAI = [], cpuSide = -1, stageId = 'bodega', stageName = '', pixel = 0, touch = false }) {
    this.touch = touch; // en celular no se muestran las teclas del teclado
    this.pixel = pixel; // 0 = HD; 3 = 16-bit (cada píxel del juego mide 3×3)
    this.stageId = stageId;
    this.stageName = stageName;
    this.fighters = [new Fighter(defs[0], 0, inputs[0]), new Fighter(defs[1], 1, inputs[1])];
    this.ais = this.fighters.map((f, i) => (makeAI[i] ? makeAI[i](f, this.fighters[1 - i], this) : null));
    this.cpuSide = cpuSide;
    this.round = 1;
    this.frame = 0;
    this.debug = false;
    this.paused = false;
    this.over = false;
    this.startRound();
  }

  startRound() {
    for (const f of this.fighters) f.reset();
    this.projectiles = [];
    this.particles = [];
    this.combo = [{ count: 0, t: 0 }, { count: 0, t: 0 }];
    this.timer = ROUND_TIME * FPS;
    this.hitstop = 0; this.freeze = 0; this.freezeOwner = null;
    this.slowmo = 0; this.shakeT = 0; this.shakeMag = 0;
    this.announce = { text: '', t: 0, age: 0 };
    if (this.round === 1) {
      // presentación tipo VS con retratos y poses de entrada
      for (const f of this.fighters) f.setState('intro');
      this.setPhase('vs');
    } else {
      this.setPhase('intro');
    }
  }

  setPhase(p) { this.phase = p; this.phaseFrame = 0; }

  say(text, t = 60, extra = {}) {
    this.announce = { text, t, age: 0, ...extra };
    sfx.announce();
  }

  sfx(name, arg) { sfx[name]?.(arg); }

  shake(mag, t) { if (mag > 0) { this.shakeMag = Math.max(this.shakeMag, mag); this.shakeT = Math.max(this.shakeT, t); } }

  // ---------- bucle por cuadro ----------
  step() {
    if (this.paused) { endInputFrame(); return; }
    this.frame++;
    this.phaseFrame++;
    if (this.announce.t > 0) { this.announce.t--; this.announce.age++; }
    if (this.shakeT > 0) this.shakeT--; else this.shakeMag = 0;
    this.updateParticles();

    this.ais.forEach(ai => ai && ai.think());
    for (const f of this.fighters) f.readInput();
    endInputFrame();

    if (this.freeze > 0) { this.freeze--; return; }
    if (this.hitstop > 0) { this.hitstop--; return; }
    if (this.slowmo > 0 && this.slowmo-- % 3) return;

    this.updatePhase();

    const [a, b] = this.fighters;
    a.update(b, this);
    b.update(a, this);
    this.updateProjectiles();
    this.updateFighterFx();
    this.pushApart(a, b);
    this.detectHits();

    for (const f of this.fighters) {
      if (f.hpShown > f.hp) f.hpShown = Math.max(f.hp, f.hpShown - 5);
      if (f.meter > METER_MAX) f.meter = METER_MAX;
    }
    for (const c of this.combo) if (c.t > 0) c.t--;
  }

  updatePhase() {
    const [a, b] = this.fighters;
    switch (this.phase) {
      case 'vs':
        if (this.phaseFrame >= 170) {
          for (const f of this.fighters) f.setState('idle');
          this.setPhase('intro');
        }
        break;
      case 'intro':
        if (this.phaseFrame === 1) this.say(`RONDA ${this.round}`, 55);
        if (this.phaseFrame === 60) this.say('¡PELEA!', 40, { color: '#ff6b3d' });
        if (this.phaseFrame >= 70) { a.locked = b.locked = false; this.setPhase('fight'); }
        break;
      case 'fight':
        if (a.dead || b.dead) {
          a.locked = b.locked = true;
          this.slowmo = 45;
          this.say('K.O.', 90, { color: '#ff3d3d' });
          sfx.ko();
          this.setPhase('ko');
        } else if (--this.timer <= 0) {
          this.timer = 0;
          a.locked = b.locked = true;
          this.say('¡TIEMPO!', 80);
          this.setPhase('timeup');
        }
        break;
      case 'ko': {
        const settled = this.fighters.every(f => !f.dead || f.state === 'ko');
        if (settled && this.phaseFrame > 70) {
          const alive = this.fighters.filter(f => !f.dead);
          this.endRound(alive.length === 1 ? alive[0] : null);
        }
        break;
      }
      case 'timeup':
        if (this.phaseFrame > 70 && !this.fighters.some(f => f.state === 'attack' || f.airborne)) {
          const ra = a.hp / a.def.stats.hp, rb = b.hp / b.def.stats.hp;
          this.endRound(ra === rb ? null : ra > rb ? a : b);
        }
        break;
      case 'roundEnd':
        if (this.phaseFrame > 150) {
          const champ = this.fighters.find(f => f.wins >= ROUNDS_TO_WIN);
          if (champ || this.round >= 5) {
            this.setPhase('matchEnd');
            this.over = true;
            this.say(champ ? `¡${champ.def.name} GANA!` : 'EMPATE', 100000,
              { sub: this.touch ? '' : 'ENTER REVANCHA  ·  M MENU' });
            // la pantalla de "Gracias por jugar" (main.js) escucha este aviso
            const [p1, p2] = this.fighters;
            window.dispatchEvent(new CustomEvent('borderline:fin', { detail: {
              ganador: champ ? champ.def.name : null, perdedor: champ ? this.fighters.find(f => f !== champ).def.name : null,
              p1: p1.def.name, p2: p2.def.name, marcador: [p1.wins, p2.wins], rondas: this.round, escenario: this.stageName,
              cpu: this.cpuSide, ganadorLado: champ ? champ.side : -1,
            } }));
          } else {
            this.round++;
            this.startRound();
          }
        }
        break;
      default: break;
    }
  }

  endRound(winner) {
    if (winner) {
      winner.wins++;
      if (!winner.airborne) { winner.vx = 0; winner.move = null; winner.setState('win'); }
      this.say(`${winner.def.name} GANA LA RONDA`, 140, { color: '#ffd84a' });
    } else {
      this.say('EMPATE', 140);
    }
    this.setPhase('roundEnd');
  }

  // ---------- súper ----------
  startSuper(f) {
    this.freeze = 32;
    this.freezeOwner = f;
    this.say(f.move.name, 32, { color: f.def.look.colors.accent });
    sfx.super();
  }

  // ---------- colisiones de cuerpo ----------
  pushApart(a, b) {
    // no dejar que se separen más de lo que muestra la cámara
    const maxSpread = STAGE.width / CAMERA_ZOOM - 140;
    const spread = Math.abs(b.x - a.x);
    if (spread > maxSpread) {
      const fix = (spread - maxSpread) / 2, s = Math.sign(b.x - a.x);
      a.x += s * fix; b.x -= s * fix;
      a.clampToStage(); b.clampToStage();
    }
    const ha = a.def.stats.height, hb = b.def.stats.height;
    if (Math.abs(a.y - b.y) > Math.min(ha, hb) * 0.7) return; // uno pasa por encima del otro
    if (a.state === 'ko' || b.state === 'ko') return;
    // distancia mínima entre centros: cuerpos + espacio para brazos en guardia
    const minDist = (a.def.stats.width + b.def.stats.width) / 2 + 20;
    const dx = b.x - a.x;
    if (Math.abs(dx) >= minDist) return;
    const dir = dx !== 0 ? Math.sign(dx) : (a.side === 0 ? 1 : -1);
    const push = (minDist - Math.abs(dx)) / 2;
    a.x -= dir * push; b.x += dir * push;
    a.clampToStage(); b.clampToStage();
    // si uno quedó contra la pared, el otro absorbe el resto
    const gap = minDist - Math.abs(b.x - a.x);
    if (gap > 0.5) {
      if (a.atWall) b.x += dir * gap; else if (b.atWall) a.x -= dir * gap;
      a.clampToStage(); b.clampToStage();
    }
  }

  // ---------- golpes ----------
  detectHits() {
    const hits = [];
    for (let i = 0; i < 2; i++) {
      const att = this.fighters[i], def = this.fighters[1 - i];
      const hb = att.activeHitbox();
      if (!hb) continue;
      const hurt = def.hurtbox();
      if (!hurt || def.invuln > 0 || !overlap(hb, hurt)) continue;
      // agarres: sólo atrapan a un rival en el piso que no esté aturdido ni bloqueando
      if (att.move.groundOnly && (def.airborne || ['hitstun', 'blockstun'].includes(def.state))) continue;
      hits.push({ att, def, hb, hurt, m: att.move });
    }
    // Se guarda el golpe antes de resolver: en un intercambio (trade) el primer
    // impacto cancela el movimiento del otro, pero su golpe igual debe contar.
    for (const { att, def, hb, hurt, m } of hits) {
      att.hitsLanded++;
      att.lastHitFrame = att.moveFrame;
      const point = {
        x: (Math.max(hb.x, hurt.x) + Math.min(hb.x + hb.w, hurt.x + hurt.w)) / 2,
        y: (Math.max(hb.y, hurt.y) + Math.min(hb.y + hb.h, hurt.y + hurt.h)) / 2,
      };
      this.resolveHit(att, def, m, {
        point,
        sourceX: att.x,
        dir: att.facing,
        final: (m.hits || 1) > 1 && att.hitsLanded === m.hits,
      });
    }
  }

  // h = datos del golpe (de un movimiento o de un proyectil)
  resolveHit(att, def, h, { point, sourceX, dir, final = false, projectile = null }) {
    att.connected = true;
    const levelOk = h.level === 'low' ? def.holdingDown()
      : h.level === 'overhead' ? !def.holdingDown() : true;
    const blocked = !h.unblockable && def.canBlock() && def.holdingAwayFrom(sourceX) && levelOk;
    if (h.reverse) dir = -dir; // agarre: el rival sale volando por encima, hacia atrás

    if (blocked) {
      def.setState('blockstun');
      def.stun = h.blockstun;
      def.vx = dir * h.knockback * 0.8;
      if (h.chip) def.hp = Math.max(h.special ? 0 : 1, def.hp - h.chip);
      att.meter += 2; def.meter += 4;
      this.hitstop = HITSTOP.block;
      this.spawnSpark(point, '#6fc8ff', 'block');
      sfx.block();
      if (!projectile && def.atWall && !att.airborne) att.pushback = -dir * h.knockback * 0.9;
      if (def.hp <= 0) this.kill(def, dir);
      return;
    }

    const inCombo = ['hitstun', 'airhit'].includes(def.state);
    def.comboTaken = inCombo ? def.comboTaken + 1 : 1;
    const scale = Math.max(MIN_SCALING, 1 - COMBO_SCALING * (def.comboTaken - 1));
    def.hp = Math.max(0, def.hp - Math.max(1, Math.round(h.damage * scale)));
    def.flash = 4;
    def.move = null; def.moveName = null;
    if (def.projectile && def.state === 'attack') { /* el proyectil ya lanzado sigue vivo */ }

    const launch = (final && h.finalLaunch) || h.launch;
    if (def.hp <= 0) {
      this.kill(def, dir);
    } else if (launch || def.airborne || h.knockdown) {
      def.setState('airhit');
      def.vy = launch || (h.knockdown ? 450 : 380);
      def.vx = dir * Math.max(h.knockback * 0.6, 140);
    } else {
      def.setState('hitstun');
      def.stun = h.hitstun;
      def.vx = dir * h.knockback;
    }

    att.meter += h.meter ?? 6;
    def.meter += 3;
    const strength = h.strength || 'light';
    this.hitstop = HITSTOP[strength];
    this.shake(SHAKE[strength], 10);
    this.spawnSpark(point, '#e0241c', strength, '#ffb4a0');
    bloodSplash(this.particles, point, dir, strength); // salpicadura de sangre
    sfx.hit(strength);
    if (!projectile && def.atWall && !att.airborne) att.pushback = -dir * h.knockback * 0.7;
    this.combo[att.side] = { count: def.comboTaken, t: 80 };
  }

  kill(def, dir) {
    def.hp = 0;
    def.dead = true;
    def.move = null;
    def.setState('airhit');
    def.vy = 750;
    def.vx = dir * 380;
    this.shake(8, 20);
  }

  // ---------- proyectiles ----------
  spawnProjectile(owner, p) {
    const proj = {
      owner, def: p, alive: true,
      x: owner.x + owner.facing * 70, y: p.y,
      vx: owner.facing * p.speed,
      w: p.w, h: p.h, life: p.life,
      hitsLeft: p.hits || 1, cool: 0, frame: 0,
    };
    owner.projectile = proj;
    this.projectiles.push(proj);
    sfx.projectile();
  }

  projRect(p) { return { x: p.x - p.w / 2, y: p.y - p.h / 2, w: p.w, h: p.h }; }

  updateProjectiles() {
    for (const p of this.projectiles) {
      if (!p.alive) continue;
      p.x += p.vx * DT;
      p.frame++;
      if (p.cool > 0) p.cool--;
      if (--p.life <= 0 || p.x < -200 || p.x > STAGE.width + 200) { p.alive = false; continue; }

      // choque entre proyectiles: se anulan (el súper gana)
      for (const q of this.projectiles) {
        if (q === p || !q.alive || q.owner === p.owner) continue;
        if (overlap(this.projRect(p), this.projRect(q))) {
          if (!p.def.super) p.alive = false;
          if (!q.def.super) q.alive = false;
          this.spawnSpark({ x: (p.x + q.x) / 2, y: p.y }, '#ffffff', 'medium');
          sfx.block();
        }
      }
      if (!p.alive) continue;

      const target = this.fighters[1 - p.owner.side];
      const hurt = target.hurtbox();
      if (p.cool === 0 && hurt && target.invuln === 0 && overlap(this.projRect(p), hurt)) {
        p.hitsLeft--;
        p.cool = p.def.hitInterval || 0;
        this.resolveHit(p.owner, target, p.def, {
          point: { x: p.x + Math.sign(p.vx) * p.w * 0.3, y: p.y },
          sourceX: p.x - p.vx, dir: Math.sign(p.vx),
          final: (p.def.hits || 1) > 1 && p.hitsLeft === 0,
          projectile: p,
        });
        if (p.hitsLeft <= 0) p.alive = false;
      }
    }
    this.projectiles = this.projectiles.filter(p => p.alive);
  }

  // ---------- partículas ----------
  spawnSpark(point, color, strength = 'light', core) {
    sparkBurst(this.particles, point, color, strength, core);
  }

  updateParticles() {
    this.particles = updateFx(this.particles);
  }

  // Estelas (afterimages) y aura de energía de cada peleador
  updateFighterFx() {
    for (const f of this.fighters) {
      const m = f.move;
      const fast = f.state === 'dash' || f.state === 'backdash' ||
        (f.state === 'attack' && (m.super || m.motion) && f.phase() !== 'recovery');
      f.trail = f.trail || [];
      if (fast && this.frame % 2 === 0) {
        const snap = Object.assign(Object.create(Object.getPrototypeOf(f)), f);
        f.trail.push({ snap, pose: poseFor(f), life: 10 });
      }
      for (const t of f.trail) t.life--;
      f.trail = f.trail.filter(t => t.life > 0).slice(-5);

      const aura = f.def.look.colors.aura || f.def.look.colors.accent;
      if (f.handPos && f.state === 'attack' && (m.special || m.super || m.projectile) && f.phase() !== 'recovery') {
        for (let i = 0; i < 2; i++) flame(this.particles, f.handPos.x, f.handPos.y, aura, 14, 160);
      }
      if (f.meter >= METER_MAX && this.frame % 5 === 0 && !f.dead) {
        flame(this.particles, f.x + (Math.random() - 0.5) * 50, f.y + Math.random() * 150, aura, 10, 140);
      }
    }
    for (const p of this.projectiles) projectileTrail(this.particles, p);
  }

  // ---------- dibujo ----------
  // Cámara estilo KOF: acerca la escena y sigue el punto medio entre los dos peleadores.
  updateCamera() {
    const half = STAGE.width / CAMERA_ZOOM / 2;
    const [a, b] = this.fighters;
    const target = Math.max(half, Math.min(STAGE.width - half, (a.x + b.x) / 2));
    this.camX = this.camX == null ? target : this.camX + (target - this.camX) * 0.15;
  }

  render(screen) {
    this.updateCamera();
    // modo 16-bit: el mundo se dibuja en baja resolución y luego se pixela; el HUD queda nítido
    if (this.pixel && !this.retro) this.retro = new RetroScreen(this.pixel);
    const ctx = this.retro ? this.retro.begin() : screen;
    ctx.save();
    if (this.shakeT > 0) ctx.translate((Math.random() - 0.5) * this.shakeMag * 2, (Math.random() - 0.5) * this.shakeMag);
    // escala alrededor del punto (camX, borde inferior) → el piso queda abajo y se recorta el cielo
    ctx.translate(STAGE.width / 2, STAGE.height);
    ctx.scale(CAMERA_ZOOM, CAMERA_ZOOM);
    ctx.translate(-this.camX, -STAGE.height);
    drawStage(ctx, this.stageId);
    drawFx(ctx, this.particles, true); // manchas de sangre en el piso
    for (const f of this.fighters) drawShadow(ctx, f);

    if (this.freeze > 0) {
      ctx.fillStyle = 'rgba(5,0,20,0.6)';
      ctx.fillRect(-STAGE.width, -STAGE.height, STAGE.width * 3, STAGE.height * 3);
    }
    // estelas detrás de todo
    for (const f of this.fighters) {
      const aura = f.def.look.colors.aura || f.def.look.colors.accent;
      for (const t of f.trail || []) drawFighter(ctx, t.snap, t.pose, { ghost: aura, alpha: (t.life / 10) * 0.45 });
    }
    // quien ataca se dibuja encima
    const order = [...this.fighters].sort((p, q) => (p.state === 'attack') - (q.state === 'attack'));
    for (const f of order) {
      const parts = drawFighter(ctx, f, poseFor(f), { glow: this.freeze > 0 && f === this.freezeOwner });
      f.handPos = { x: parts.handF.x, y: STAGE.floor - parts.handF.y };
    }
    for (const p of this.projectiles) drawProjectile(ctx, p);
    drawFx(ctx, this.particles);

    if (this.debug) this.drawBoxes(ctx);
    ctx.restore();
    if (this.retro) this.retro.present(screen);
    drawHUD(screen, this);
  }

  drawBoxes(ctx) {
    const rect = (b, color) => {
      ctx.strokeStyle = color; ctx.lineWidth = 2;
      ctx.strokeRect(b.x, STAGE.floor - b.y - b.h, b.w, b.h);
    };
    for (const f of this.fighters) {
      const hurt = f.hurtbox();
      if (hurt) rect(hurt, '#3aa0ff');
      if (f.state === 'attack' && f.move.hitbox) {
        rect(f.worldRect(f.move.hitbox), f.phase() === 'active' ? '#ff3030' : 'rgba(255,80,80,0.35)');
      }
    }
    for (const p of this.projectiles) rect(this.projRect(p), '#ff3030');
  }
}
