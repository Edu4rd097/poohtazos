// Dibuja a un luchador con estilo de cómic/anime de los 90: contorno de tinta,
// sombreado "cel" de dos tonos, brillo y ropa por capas. Todo se genera a partir
// de la pose (ver poses.js) y del campo `look` del personaje:
//
//   build:   { shoulder, chest, waist, hip }  proporciones del torso (≈1)
//   top:     'none' | 'tshirt' | 'jacket' | 'vest' | 'gi'
//   bottom:  'pants' | 'trunks' | 'gi'
//   feet:    'boots' | 'sneakers'
//   gloves:  'none' | 'fingerless' | 'full'      claw: true → mano delantera en garra
//   hair:    'spiky' | 'long' | 'ponytail'       face: 'snarl' | 'smile' | 'calm'
//   headband, kneepads, chain (cadena colgando del cinturón), necklace, wristbands: true/false
//   colors:  skin, top, top2 (playera bajo la chamarra), pants, accent, shoe, hair, glove,
//            collar, belt, eyes, aura (color de su energía)
import { STAGE } from '../config.js';

const INK = '#17101c';
const OUT = 2.3;

function rgb(c) {
  const n = parseInt(c.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function shade(c, k) {
  if (!c || c[0] !== '#') return c;
  const f = v => Math.max(0, Math.min(255, Math.round(v * k)));
  const [r, g, b] = rgb(c);
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
export function tint(c, k) {
  if (!c || c[0] !== '#') return c;
  const f = v => Math.round(v + (255 - v) * k);
  const [r, g, b] = rgb(c);
  return `rgb(${f(r)},${f(g)},${f(b)})`;
}
const lerpPt = (a, b, t) => ({ x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t });

// ---------- primitivas ----------
function capsulePath(ctx, a, b, r1, r2, bulge = 0) {
  const ang = Math.atan2(b.y - a.y, b.x - a.x);
  const nx = -Math.sin(ang), ny = Math.cos(ang);
  ctx.beginPath();
  ctx.moveTo(a.x + nx * r1, a.y + ny * r1);
  if (bulge) {
    // curva que pasa por el "vientre" del músculo
    const m = lerpPt(a, b, 0.45), rm = Math.max(r1, r2) * (1 + bulge);
    const c = 2 * rm - (r1 + r2) / 2;
    ctx.quadraticCurveTo(m.x + nx * c, m.y + ny * c, b.x + nx * r2, b.y + ny * r2);
    ctx.arc(b.x, b.y, r2, ang + Math.PI / 2, ang - Math.PI / 2, true);
    ctx.quadraticCurveTo(m.x - nx * c, m.y - ny * c, a.x - nx * r1, a.y - ny * r1);
  } else {
    ctx.lineTo(b.x + nx * r2, b.y + ny * r2);
    ctx.arc(b.x, b.y, r2, ang + Math.PI / 2, ang - Math.PI / 2, true);
    ctx.lineTo(a.x - nx * r1, a.y - ny * r1);
  }
  ctx.arc(a.x, a.y, r1, ang - Math.PI / 2, ang + Math.PI / 2, true);
  ctx.closePath();
}

function curveStroke(ctx, a, b, ox, oy, bulge, width, color, alpha = 1) {
  const m = lerpPt(a, b, 0.45);
  ctx.globalAlpha *= alpha;
  ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(a.x + ox, a.y + oy);
  ctx.quadraticCurveTo(m.x + ox * (1 + bulge * 1.6), m.y + oy * (1 + bulge * 1.6), b.x + ox, b.y + oy);
  ctx.stroke();
  ctx.globalAlpha /= alpha;
}

// Segmento de cuerpo/ropa: contorno de tinta, sombra media, sombra núcleo, luz y brillo especular
function part(ctx, S, a, b, w1, w2, color, gloss = 0.35, bulge = 0) {
  const r1 = w1 / 2, r2 = w2 / 2;
  ctx.fillStyle = INK; capsulePath(ctx, a, b, r1 + OUT, r2 + OUT, bulge * 0.9); ctx.fill();
  ctx.fillStyle = color; capsulePath(ctx, a, b, r1, r2, bulge); ctx.fill();
  // en piezas cortas (manos, pies) la sombra se ve cuadrada: se omite
  if (Math.hypot(b.x - a.x, b.y - a.y) < (r1 + r2) * 0.9) return;
  const ang = Math.atan2(b.y - a.y, b.x - a.x);
  let nx = -Math.sin(ang), ny = Math.cos(ang);
  if (nx * S.sx + ny * S.sy < 0) { nx = -nx; ny = -ny; }
  const rm = ((r1 + r2) / 2) * (1 + bulge);
  ctx.save();
  ctx.clip();
  curveStroke(ctx, a, b, nx * rm * 0.95, ny * rm * 0.95, bulge, rm * 1.15, shade(color, 0.72));
  curveStroke(ctx, a, b, nx * rm * 0.38, ny * rm * 0.38, bulge, rm * 0.2, shade(color, 0.6), 0.55);
  if (gloss > 0) {
    curveStroke(ctx, a, b, -nx * rm * 0.5, -ny * rm * 0.5, bulge, rm * 0.4, tint(color, 0.28), Math.min(1, gloss * 1.6));
    curveStroke(ctx, lerpPt(a, b, 0.2), lerpPt(a, b, 0.7), -nx * rm * 0.55, -ny * rm * 0.55, bulge, Math.max(1, rm * 0.12), tint(color, 0.75), gloss);
  }
  ctx.restore();
}

// franja que cruza una extremidad (ribete de manga, puño, muñequera)
function band(ctx, a, b, t, width, thick, color) {
  const p = lerpPt(a, b, t);
  const ang = Math.atan2(b.y - a.y, b.x - a.x);
  const nx = -Math.sin(ang) * width / 2, ny = Math.cos(ang) * width / 2;
  ctx.save();
  ctx.lineCap = 'butt';
  ctx.strokeStyle = INK; ctx.lineWidth = thick + OUT * 2;
  ctx.beginPath(); ctx.moveTo(p.x + nx, p.y + ny); ctx.lineTo(p.x - nx, p.y - ny); ctx.stroke();
  ctx.strokeStyle = color; ctx.lineWidth = thick;
  ctx.beginPath(); ctx.moveTo(p.x + nx * 0.92, p.y + ny * 0.92); ctx.lineTo(p.x - nx * 0.92, p.y - ny * 0.92); ctx.stroke();
  ctx.restore();
}

function poly(ctx, pts, color, outline = true) {
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.closePath();
  if (outline) { ctx.lineJoin = 'round'; ctx.lineWidth = OUT * 2; ctx.strokeStyle = INK; ctx.stroke(); }
  ctx.fillStyle = color;
  ctx.fill();
}

function stroke(ctx, pts, color, w, alpha = 1) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.strokeStyle = color; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
  ctx.stroke();
  ctx.restore();
}

function ellipse(ctx, p, rx, ry, color, outline = true) {
  ctx.beginPath();
  ctx.ellipse(p.x, p.y, rx, ry, 0, 0, Math.PI * 2);
  if (outline) { ctx.lineWidth = OUT * 2; ctx.strokeStyle = INK; ctx.stroke(); }
  ctx.fillStyle = color; ctx.fill();
}

// ---------- anatomía ----------
// Hueso local: t = 0..1 a lo largo, v = px perpendicular (v > 0 = lado del frente)
function bone(a, b, fx) {
  const dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy) || 1;
  const ux = dx / len, uy = dy / len, nx = uy * fx, ny = -ux * fx;
  return { a, b, len, ux, uy, nx, ny, fx, at: (tt, v) => ({ x: a.x + dx * tt + nx * v, y: a.y + dy * tt + ny * v }) };
}
const sstep = x => x * x * (3 - 2 * x);
function prof(P, tt) {
  if (tt <= P[0][0]) return P[0][1];
  for (let i = 1; i < P.length; i++) {
    if (tt <= P[i][0]) { const [t0, v0] = P[i - 1], [t1, v1] = P[i]; return v0 + (v1 - v0) * sstep((tt - t0) / (t1 - t0)); }
  }
  return P[P.length - 1][1];
}
// Silueta de un músculo/prenda: perfil del frente (f) y de atrás (b), en múltiplos del grosor w
function segPath(B, P, w) {
  const p = new Path2D(), N = 12;
  for (let i = 0; i <= N; i++) { const q = B.at(i / N, prof(P.f, i / N) * w); i ? p.lineTo(q.x, q.y) : p.moveTo(q.x, q.y); }
  const an = Math.atan2(B.ny, B.nx), ccw = B.fx < 0;
  const f1 = prof(P.f, 1) * w, b1 = prof(P.b, 1) * w, c1 = B.at(1, (f1 - b1) / 2);
  p.arc(c1.x, c1.y, (f1 + b1) / 2, an, an + Math.PI * B.fx, ccw);
  for (let i = N; i >= 0; i--) { const q = B.at(i / N, -prof(P.b, i / N) * w); p.lineTo(q.x, q.y); }
  const f0 = prof(P.f, 0) * w, b0 = prof(P.b, 0) * w, c0 = B.at(0, (f0 - b0) / 2);
  p.arc(c0.x, c0.y, (f0 + b0) / 2, an + Math.PI * B.fx, an + 2 * Math.PI * B.fx, ccw);
  p.closePath();
  return p;
}
function warmShadow(c) {
  if (!c || c[0] !== '#') return c;
  const [r, g, b] = rgb(c);
  return `rgb(${Math.round(r * 0.74)},${Math.round(g * 0.58)},${Math.round(b * 0.6 + 12)})`;
}
// Sombreado cel: todo en sombra, y la figura desplazada hacia la luz se pinta en el color base
function cel(ctx, S, path, color, k, gloss = 0.35) {
  ctx.save();
  ctx.fillStyle = warmShadow(color); ctx.fill(path);
  ctx.clip(path);
  ctx.translate(-S.sx * k, -S.sy * k); ctx.fillStyle = color; ctx.fill(path);
  if (gloss) {
    ctx.translate(-S.sx * k * 0.9, -S.sy * k * 0.9);
    ctx.globalAlpha *= gloss; ctx.fillStyle = tint(color, 0.32); ctx.fill(path);
  }
  ctx.restore();
}
// Varias piezas como una sola: primero todo el contorno, luego los rellenos (sin líneas en las uniones)
let GLOW = null; // color del aura de súper: sólo se aplica al contorno (aplicarlo a cada capa es carísimo)
function body(ctx, S, segs) {
  ctx.save();
  if (GLOW) { ctx.shadowColor = GLOW; ctx.shadowBlur = 22; }
  ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.lineJoin = 'round';
  for (const s of segs) ctx.stroke(s.p);
  ctx.restore();
  for (const s of segs) {
    cel(ctx, S, s.p, s.c, s.k, s.gloss ?? 0.35);
    if (s.lines) for (const l of s.lines) muscleLine(ctx, s.B, s.w, l, s.lc || shade(s.c, 0.55));
  }
}
// línea curva de separación muscular en coordenadas del hueso: [[t,v],[t,v],[t,v], alpha, grosor]
function muscleLine(ctx, B, w, l, color) {
  const [p0, p1, p2] = l.slice(0, 3).map(([tt, v]) => B.at(tt, v * w));
  ctx.save();
  ctx.globalAlpha *= l[3] ?? 0.6;
  ctx.strokeStyle = color; ctx.lineWidth = l[4] ?? 1.6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.quadraticCurveTo(p1.x, p1.y, p2.x, p2.y); ctx.stroke();
  ctx.restore();
}
// Camino suave (Catmull-Rom) por una lista de puntos cerrada
function smoothPath(pts) {
  const p = new Path2D(), n = pts.length;
  p.moveTo(pts[0].x, pts[0].y);
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
    p.bezierCurveTo(p1.x + (p2.x - p0.x) / 6, p1.y + (p2.y - p0.y) / 6, p2.x - (p3.x - p1.x) / 6, p2.y - (p3.y - p1.y) / 6, p2.x, p2.y);
  }
  p.closePath();
  return p;
}

// Perfiles (frente / atrás) a lo largo del hueso, en múltiplos del grosor de extremidad
const PROF = {
  upperArm: { f: [[0, 0.7], [0.18, 0.74], [0.5, 0.64], [0.78, 0.5], [1, 0.42]], b: [[0, 0.68], [0.3, 0.66], [0.6, 0.56], [1, 0.43]] },
  foreArm: { f: [[0, 0.45], [0.25, 0.58], [0.6, 0.44], [1, 0.33]], b: [[0, 0.44], [0.3, 0.5], [1, 0.33]] },
  thigh: { f: [[0, 0.76], [0.35, 0.84], [0.75, 0.66], [1, 0.5]], b: [[0, 0.76], [0.5, 0.7], [0.85, 0.56], [1, 0.5]] },
  shin: { f: [[0, 0.5], [0.15, 0.46], [0.6, 0.4], [1, 0.31]], b: [[0, 0.5], [0.28, 0.68], [0.55, 0.56], [0.85, 0.36], [1, 0.32]] },
  pantThigh: { f: [[0, 0.82], [0.4, 0.84], [1, 0.66]], b: [[0, 0.82], [0.5, 0.78], [1, 0.66]] },
  pantShin: { f: [[0, 0.66], [0.5, 0.62], [1, 0.62]], b: [[0, 0.66], [0.5, 0.66], [1, 0.62]] },
  trunk: { f: [[0, 0.86], [1, 0.8]], b: [[0, 0.86], [1, 0.78]] },
  shorts: { f: [[0, 0.88], [1, 0.84]], b: [[0, 0.88], [1, 0.82]] },
  fist: { f: [[0, 0.4], [0.4, 0.62], [1, 0.56]], b: [[0, 0.4], [0.5, 0.54], [1, 0.5]] },
  thumb: { f: [[0, 0.22], [1, 0.18]], b: [[0, 0.22], [1, 0.18]] },
  foot: { f: [[0, 0.44], [0.55, 0.36], [1, 0.27]], b: [[0, 0.4], [1, 0.28]] },
  boot: { f: [[0, 0.56], [1, 0.6]], b: [[0, 0.56], [1, 0.6]] },
  neck: { f: [[0, 0.62], [1, 0.52]], b: [[0, 0.7], [1, 0.55]] },
};
// separaciones musculares
const MUS = {
  upperArm: [[[0.05, 0.62], [0.28, 0.45], [0.42, 0.62], 0.55], [[0.3, -0.1], [0.6, -0.18], [0.88, -0.05], 0.5], [[0.45, 0.4], [0.7, 0.45], [0.9, 0.3], 0.35, 1.2]],
  foreArm: [[[0.05, 0.28], [0.35, 0.18], [0.7, 0.02], 0.5], [[0.1, -0.3], [0.4, -0.2], [0.75, -0.25], 0.3, 1.2]],
  thigh: [[[0.12, 0.45], [0.5, 0.2], [0.82, 0.3], 0.55], [[0.62, 0.62], [0.8, 0.3], [0.94, 0.45], 0.5], [[0.2, -0.35], [0.55, -0.4], [0.85, -0.3], 0.35, 1.2]],
  shin: [[[0.08, -0.35], [0.3, -0.18], [0.58, -0.38], 0.5], [[0.15, 0.3], [0.5, 0.25], [0.85, 0.2], 0.3, 2.2]],
};

export function drawShadow(ctx, f) {
  const k = Math.max(0.35, 1 - f.y / 400);
  ctx.fillStyle = `rgba(0,0,0,${0.38 * k})`;
  ctx.beginPath();
  ctx.ellipse(f.x, STAGE.floor + 4, 58 * k, 12 * k, 0, 0, Math.PI * 2);
  ctx.fill();
}

const HURT = new Set(['hitstun', 'airhit', 'knockdown', 'ko']);

// ---------- luchador ----------
// opts.ghost: color sólido semitransparente (estelas). opts.glow: brillo de súper.
export function drawFighter(ctx, f, pose, { glow = false, ghost = null, alpha = 1 } = {}) {
  const L = f.def.look;
  const solid = ghost || (f.flash > 0 ? '#c4161c' : null);
  const C = solid ? new Proxy({}, { get: () => solid }) : L.colors;
  let fx = f.facing;
  if (f.state === 'attack' && f.move.spin && f.moveFrame > f.move.startup && f.phase() !== 'recovery') {
    if (Math.floor(f.moveFrame / 4) % 2) fx = -fx;
  }
  const S = (() => { const x = -fx * 0.55, y = 0.85, n = Math.hypot(x, y); return { sx: x / n, sy: y / n }; })();
  const B = { shoulder: 1.2, chest: 1.1, waist: 0.82, hip: 0.95, ...(L.build || {}) };
  const top = L.top || (L.shirtless ? 'none' : 'tshirt');
  const bottom = L.bottom || (L.legs === 'trunks' ? 'trunks' : 'pants');
  const R = Math.PI / 180;

  // esqueleto
  const ext = l => Math.cos(l[0] * R) * L.thigh + Math.cos(l[1] * R) * L.shin;
  const groundY = STAGE.floor - f.y;
  // L.skate: peleador sentado en patineta (no usa las piernas): piernas cruzadas fijas sobre la tabla
  const legPF = L.skate ? [82, -96] : pose.legF, legPB = L.skate ? [72, -104] : pose.legB;
  const hip = { x: f.x, y: L.skate ? groundY - (L.seat || 26) : groundY - Math.max(ext(legPF), ext(legPB)) - 7 };
  const t = pose.torso * R;
  const F = { x: Math.cos(t) * fx, y: Math.sin(t) };     // hacia el frente (perpendicular al torso)
  const U = { x: Math.sin(t) * fx, y: -Math.cos(t) };    // hacia arriba (a lo largo del torso)
  const P = (o, u, v) => ({ x: o.x + F.x * u + U.x * v, y: o.y + F.y * u + U.y * v });
  const T = L.torso, tw = L.torsoW / 2;
  const neck = P(hip, 0, T);
  const shoulder = P(hip, 0, T - 7);
  const head = P(neck, 0, L.headR + 6);
  const limb = (o, a, l1, l2) => {
    const m = { x: o.x + Math.sin(a[0] * R) * l1 * fx, y: o.y + Math.cos(a[0] * R) * l1 };
    const e = { x: m.x + Math.sin(a[1] * R) * l2 * fx, y: m.y + Math.cos(a[1] * R) * l2 };
    return [o, m, e];
  };
  const armF = limb(shoulder, pose.armF, L.upperArm, L.foreArm);
  const armB = limb(shoulder, pose.armB, L.upperArm, L.foreArm);
  const legF = limb(hip, legPF, L.thigh, L.shin);
  const legB = limb(hip, legPB, L.thigh, L.shin);
  const w = L.limbW;
  const sway = Math.sin(f.frame * 0.12) * 4 + (f.airborne ? -f.vy * 0.012 : 0) + (f.vx ? -Math.sign(f.vx) * fx * 3 : 0);

  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (f.invuln > 0 && f.state === 'getup' && Math.floor(f.frame / 3) % 2) ctx.globalAlpha *= 0.55;
  GLOW = glow && !ghost ? (C.aura || C.accent) : null;

  const dk = (c, back) => (back ? shade(c, 0.78) : c);

  // ---- brazo ----
  const tattooArm = (B, ww, back) => {
    if (!L.tattoos || solid) return;
    ctx.save();
    ctx.globalAlpha *= back ? 0.45 : 0.6;
    ctx.strokeStyle = C.ink || '#2f3a36'; ctx.fillStyle = C.ink || '#2f3a36'; ctx.lineCap = 'round';
    for (let i = 0; i < 5; i++) {
      const t0 = 0.08 + i * 0.18, side = i % 2 ? 0.3 : -0.25;
      ctx.lineWidth = 1.6;
      const p0 = B.at(t0, side * ww), p1 = B.at(t0 + 0.08, (side + 0.35) * ww), p2 = B.at(t0 + 0.14, side * ww);
      ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.quadraticCurveTo(p1.x, p1.y, p2.x, p2.y); ctx.stroke();
      const d = B.at(t0 + 0.06, (side - 0.15) * ww); ctx.beginPath(); ctx.arc(d.x, d.y, ww * 0.09, 0, 7); ctx.fill();
    }
    ctx.restore();
  };
  const drawArm = (a, back) => {
    const skin = dk(C.skin, back);
    const sleeveC = dk(C.top, back);
    const UA = bone(a[0], a[1], fx), FA = bone(a[1], a[2], fx);
    body(ctx, S, [
      { p: segPath(UA, PROF.upperArm, w), c: skin, k: w * 0.34, B: UA, w, lines: (top === 'none' || top === 'tactical') && !L.female ? MUS.upperArm : null },
      { p: segPath(FA, PROF.foreArm, w), c: skin, k: w * 0.3, B: FA, w, lines: MUS.foreArm },
    ]);
    if (top !== 'tshirt' && top !== 'jacket' && top !== 'gi') { tattooArm(UA, w, back); tattooArm(FA, w * 0.85, back); }
    if (L.armwarmers) body(ctx, S, [{ p: segPath(bone(lerpPt(a[1], a[2], 0.05), a[2], fx), { f: [[0, 0.55], [1, 0.42]], b: [[0, 0.52], [1, 0.42]] }, w), c: dk('#141416', back), k: w * 0.25, gloss: 0.3 }]);
    if (L.bracelets && !back) { band(ctx, a[0], a[1], 0.55, w * 1.25, 2, '#1a1a1e'); band(ctx, a[0], a[1], 0.68, w * 1.2, 2, '#1a1a1e'); }
    if (top === 'jacket') part(ctx, S, a[0], a[1], w * 1.35, w * 1.2, sleeveC, 0.45);
    if (top === 'tshirt') {
      part(ctx, S, a[0], lerpPt(a[0], a[1], 0.55), w * 1.45, w * 1.35, sleeveC, 0.3);
      if (C.collar) band(ctx, a[0], a[1], 0.6, w * 1.35, 4, dk(C.collar, back));
    }
    if (top === 'gi') part(ctx, S, a[0], lerpPt(a[0], a[1], 0.8), w * 1.5, w * 1.55, sleeveC, 0.3);
    if (top === 'jacket') {
      part(ctx, S, a[1], lerpPt(a[1], a[2], 0.55), w * 1.2, w * 1.15, sleeveC, 0.45);
      band(ctx, a[1], a[2], 0.55, w * 1.25, 5, dk(C.accent, back));
    }
    if (L.wristbands) part(ctx, S, lerpPt(a[1], a[2], 0.72), lerpPt(a[1], a[2], 0.92), w * 1.02, w * 0.95, dk(C.glove || INK, back), 0.3);
    if (L.wraps) {
      band(ctx, a[1], a[2], 0.82, w * 0.86, 5, dk(C.wrap || C.accent, back));
      band(ctx, a[1], a[2], 0.94, w * 0.8, 3, dk(C.wrap || C.accent, back));
    }
    // mano
    const ux = FA.ux, uy = FA.uy;
    if (L.claw && !back) {
      part(ctx, S, a[2], { x: a[2].x + ux * 5, y: a[2].y + uy * 5 }, w * 1.1, w * 1.05, skin, 0.2);
      const base = Math.atan2(uy, ux);
      for (let i = -1.5; i <= 1.5; i++) {
        const ang = base + i * 0.36;
        const p1 = { x: a[2].x + Math.cos(ang) * w * 1.05, y: a[2].y + Math.sin(ang) * w * 1.05 };
        const p2 = { x: p1.x + Math.cos(ang + 0.7 * fx) * w * 0.75, y: p1.y + Math.sin(ang + 0.7 * fx) * w * 0.75 };
        part(ctx, S, a[2], p1, 5, 4.5, skin, 0);
        part(ctx, S, p1, p2, 4.5, 3, skin, 0);
      }
      return;
    }
    // puño: palma, dedos, nudillos y pulgar
    const gc = L.gloves && L.gloves !== 'none' ? dk(C.glove, back) : skin;
    const HB = bone({ x: a[2].x - ux * 2, y: a[2].y - uy * 2 }, { x: a[2].x + ux * w * 1.25, y: a[2].y + uy * w * 1.25 }, fx);
    const fist = segPath(HB, PROF.fist, w);
    body(ctx, S, [{ p: fist, c: gc, k: w * 0.3, gloss: 0.45 }]);
    if (L.gloves === 'fingerless') {
      // dedos descubiertos
      ctx.save(); ctx.clip(fist);
      const q = [HB.at(0.62, -w), HB.at(1.5, -w), HB.at(1.5, w), HB.at(0.62, w)];
      ctx.beginPath(); q.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath();
      ctx.fillStyle = skin; ctx.fill();
      ctx.restore();
    }
    for (const v of [-0.22, 0.04, 0.3]) muscleLine(ctx, HB, w, [[0.66, v], [0.85, v + 0.02], [1.02, v], 0.7, 1.2], INK);
    muscleLine(ctx, HB, w, [[0.62, -0.48], [0.66, 0.05], [0.62, 0.55], 0.6, 1.3], INK);
    const TB = bone(HB.at(0.12, w * 0.42), HB.at(0.62, w * 0.6), fx);
    const thumb = segPath(TB, PROF.thumb, w);
    ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 1.6; ctx.stroke(thumb); ctx.restore();
    cel(ctx, S, thumb, L.gloves === 'full' ? gc : skin, w * 0.1, 0.3);
  };

  // ---- pierna ----
  const drawLeg = (l, back) => {
    const pantsC = dk(C.pants, back), skin = dk(C.skin, back), shoeC = dk(C.shoe, back);
    const TB = bone(l[0], l[1], fx), SB = bone(l[1], l[2], fx);
    if (bottom === 'trunks' || bottom === 'shorts') {
      body(ctx, S, [
        { p: segPath(TB, PROF.thigh, w), c: skin, k: w * 0.36, B: TB, w, lines: L.female ? null : MUS.thigh },
        { p: segPath(SB, PROF.shin, w), c: skin, k: w * 0.3, B: SB, w, lines: L.female ? null : MUS.shin },
      ]);
      if (L.fishnet && !solid) {
        // medias de red: rejilla diagonal recortada a la pierna
        const lp = new Path2D(); lp.addPath(segPath(TB, PROF.thigh, w)); lp.addPath(segPath(SB, PROF.shin, w));
        ctx.save(); ctx.clip(lp); ctx.strokeStyle = 'rgba(15,12,16,0.8)'; ctx.lineWidth = 1;
        const c0 = l[1], R0 = L.thigh + L.shin;
        for (let d = -R0; d <= R0; d += 5) {
          ctx.beginPath(); ctx.moveTo(c0.x + d - R0, c0.y - R0); ctx.lineTo(c0.x + d + R0, c0.y + R0); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(c0.x + d + R0, c0.y - R0); ctx.lineTo(c0.x + d - R0, c0.y + R0); ctx.stroke();
        }
        ctx.restore();
        band(ctx, l[0], l[1], 0.72, w * 1.35, 3, '#141416'); // liga
      }
      const len = bottom === 'shorts' ? 0.55 : L.female ? 0.22 : 0.32;
      const LB = bone(l[0], lerpPt(l[0], l[1], len), fx);
      body(ctx, S, [{ p: segPath(LB, bottom === 'shorts' ? PROF.shorts : PROF.trunk, w), c: pantsC, k: w * 0.3, gloss: 0.4 }]);
      if (C.trim && !solid) {
        // franja lateral y bastilla
        muscleLine(ctx, LB, w, [[0.02, -0.55], [0.5, -0.5], [0.97, -0.48], 0.95, 2.6], dk(C.trim, back));
      }
      if (bottom === 'shorts' && !solid && !back) {
        // parches del short de MMA
        const pc = LB.at(0.5, w * 0.35);
        ctx.save(); ctx.fillStyle = C.accent; ctx.strokeStyle = INK; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.ellipse(pc.x, pc.y, w * 0.3, w * 0.42, Math.atan2(LB.uy, LB.ux), 0, 7); ctx.fill(); ctx.stroke();
        ctx.fillStyle = C.trim; ctx.fillRect(pc.x - 2, pc.y - 2, 4, 4);
        ctx.restore();
      }
    } else {
      const k = bottom === 'gi' ? 1.18 : 1;
      const sc = P => ({ f: P.f.map(([a, v]) => [a, v * k]), b: P.b.map(([a, v]) => [a, v * k]) });
      body(ctx, S, [
        { p: segPath(TB, sc(PROF.pantThigh), w), c: pantsC, k: w * 0.32, gloss: 0.25 },
        { p: segPath(SB, sc(PROF.pantShin), w), c: pantsC, k: w * 0.28, gloss: 0.25 },
      ]);
      if (L.cargo && !solid) {
        const q = [TB.at(0.4, -w * 0.2), TB.at(0.4, w * 0.6), TB.at(0.75, w * 0.62), TB.at(0.75, -w * 0.2)];
        poly(ctx, q, shade(C.pants, 1.25));
        muscleLine(ctx, TB, w, [[0.4, -0.2], [0.45, 0.2], [0.4, 0.6], 0.8, 1.2], INK);
      }
      // pliegues de rodilla, costura y desgaste
      const fold = shade(C.pants, 0.55);
      muscleLine(ctx, TB, w, [[0.78, 0.6], [0.88, 0.2], [0.96, 0.55], 0.6, 1.6], fold);
      muscleLine(ctx, SB, w, [[0.05, -0.55], [0.12, -0.2], [0.08, 0.2], 0.55, 1.5], fold);
      muscleLine(ctx, TB, w, [[0.1, -0.1], [0.5, -0.15], [1, -0.1], 0.5, 1.1], fold);
      muscleLine(ctx, SB, w, [[0, -0.1], [0.5, -0.1], [0.95, -0.12], 0.5, 1.1], fold);
      muscleLine(ctx, TB, w, [[0.4, 0.35], [0.55, 0.4], [0.7, 0.35], 0.35, 4], tint(C.pants, 0.4));
      muscleLine(ctx, SB, w, [[0.7, 0.3], [0.8, -0.2], [0.9, 0.3], 0.45, 1.3], fold);
    }
    if (L.kneepads) part(ctx, S, lerpPt(l[0], l[1], 0.9), lerpPt(l[1], l[2], 0.12), w * 1.35, w * 1.3, dk(C.accent, back), 0.5);
    // pie: perpendicular a la espinilla, hacia el frente
    const foot = { x: l[2].x + SB.uy * fx * 20, y: l[2].y - SB.ux * fx * 20 + 3 };
    const FB = bone(l[2], foot, fx);
    if (L.feet === 'boots') {
      const BB = bone(lerpPt(l[1], l[2], 0.42), l[2], fx);
      body(ctx, S, [
        { p: segPath(BB, PROF.boot, w), c: shoeC, k: w * 0.3, gloss: 0.4 },
        { p: segPath(FB, { f: [[0, 0.62], [0.6, 0.5], [1, 0.4]], b: [[0, 0.5], [1, 0.4]] }, w), c: shoeC, k: w * 0.25, gloss: 0.4 },
      ]);
      if (!solid) for (let i = 0; i < 4; i++) muscleLine(ctx, BB, w, [[0.12 + i * 0.2, -0.4], [0.17 + i * 0.2, 0.1], [0.12 + i * 0.2, 0.5], 0.8, 1.3], tint(C.shoe, 0.45));
      muscleLine(ctx, FB, w, [[0, -0.45], [0.5, -0.42], [1.05, -0.32], 0.9, 2.5], shade(C.shoe, 0.5));
    } else if (L.feet === 'bare') {
      body(ctx, S, [{ p: segPath(FB, PROF.foot, w), c: skin, k: w * 0.2, gloss: 0.3 }]);
      for (const tt of [0.78, 0.88]) muscleLine(ctx, FB, w, [[tt, 0.05], [tt + 0.02, 0.2], [tt, 0.3], 0.5, 1], INK);
    } else {
      body(ctx, S, [{ p: segPath(FB, { f: [[0, 0.62], [0.6, 0.5], [1, 0.4]], b: [[0, 0.52], [1, 0.42]] }, w), c: shoeC, k: w * 0.25, gloss: 0.5 }]);
      stroke(ctx, [FB.at(0.05, -w * 0.4), FB.at(1.05, -w * 0.3)], tint(C.shoe, 0.5), 2.5, 0.9);
    }
  };

  // ---- torso ----
  const drawTorso = () => {
    const sw = tw * B.shoulder, cw = tw * B.chest, ww = tw * B.waist, hw = tw * B.hip;
    const outline = [
      P(hip, -hw, 0), P(hip, -ww, T * 0.3), P(hip, -cw * 0.95, T * 0.72), P(hip, -sw, T - 6), P(hip, -sw * 0.55, T + 2),
      P(hip, sw * 0.55, T + 2), P(hip, sw, T - 6), P(hip, cw * 1.05, T * 0.72), P(hip, ww, T * 0.3), P(hip, hw, 0),
    ];
    const backHalf = [
      P(hip, -hw, 0), P(hip, -ww, T * 0.3), P(hip, -cw * 0.95, T * 0.72), P(hip, -sw, T - 6), P(hip, -sw * 0.55, T + 2),
      P(hip, -sw * 0.05, T + 2), P(hip, -cw * 0.1, T * 0.72), P(hip, -ww * 0.05, T * 0.3), P(hip, -hw * 0.05, 0),
    ];
    const base = top === 'none' || top === 'tactical' || top === 'crop' ? C.skin : (top === 'jacket' || top === 'vest') ? (C.top2 || C.skin) : C.top;
    // silueta: espalda, dorsal, hombros, pectoral, oblicuos
    const tpath = smoothPath([
      P(hip, -hw, -2), P(hip, -ww, T * 0.3), P(hip, -cw * 1.0, T * 0.66), P(hip, -sw * 0.98, T - 10), P(hip, -sw * 0.6, T + 1),
      P(hip, sw * 0.5, T + 1), P(hip, sw * 1.02, T - 9), ...(L.female ? [P(hip, cw * 1.3, T * 0.7), P(hip, cw * 1.05, T * 0.56)] : [P(hip, cw * 1.12, T * 0.74), P(hip, cw * 1.02, T * 0.6)]), P(hip, ww * 1.04, T * 0.34), P(hip, hw, -2),
    ]);
    ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.lineJoin = 'round'; ctx.stroke(tpath); ctx.restore();
    cel(ctx, S, tpath, base, tw * 0.4, 0.3);
    ctx.save();
    ctx.clip(tpath);
    poly(ctx, backHalf, shade(base, 0.82), false);
    stroke(ctx, [P(hip, -hw * 0.95, 0), P(hip, -ww * 0.95, T * 0.3), P(hip, -cw * 0.9, T * 0.72), P(hip, -sw * 0.95, T - 6)], shade(base, 0.58), 6, 0.6);
    stroke(ctx, [P(hip, cw * 0.95, T * 0.72), P(hip, ww * 0.95, T * 0.35)], tint(base, 0.35), 5, 0.5); // luz de borde
    ctx.restore();

    if (!L.female && (top === 'none' || top === 'tactical' || ((top === 'jacket' || top === 'vest') && !C.top2))) {
      // pecho y abdomen marcados
      const mus = shade(C.skin, 0.62);
      // sombra bajo el pectoral
      stroke(ctx, [P(hip, -cw * 0.2, T * 0.62), P(hip, cw * 0.4, T * 0.56), P(hip, cw * 0.95, T * 0.66)], shade(C.skin, 0.75), 6, 0.6);
      // clavícula y trapecio
      stroke(ctx, [P(hip, -sw * 0.2, T - 4), P(hip, sw * 0.7, T - 7)], mus, 1.6, 0.7);
      stroke(ctx, [P(hip, -sw * 0.15, T + 6), P(hip, -sw * 0.8, T - 4)], shade(C.skin, 0.8), 4, 0.6);
      // abdomen en bloques
      for (const v of [0.46, 0.34, 0.22]) {
        for (const u of [0.18, 0.48]) {
          const c = P(hip, cw * u, T * v);
          ctx.save(); ctx.globalAlpha *= 0.45; ctx.fillStyle = tint(C.skin, 0.25);
          ctx.beginPath(); ctx.ellipse(c.x, c.y, cw * 0.13, T * 0.045, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
        }
      }
      // serrato y ombligo
      for (const v of [0.6, 0.53, 0.46]) stroke(ctx, [P(hip, cw * 0.75, T * v), P(hip, cw * 0.92, T * (v + 0.03))], mus, 1.4, 0.6);
      ellipse(ctx, P(hip, cw * 0.33, T * 0.12), 1.6, 2.2, shade(C.skin, 0.55), false);
      stroke(ctx, [P(hip, -cw * 0.25, T * 0.66), P(hip, cw * 0.35, T * 0.6), P(hip, cw * 0.9, T * 0.7)], mus, 2.2);
      for (const v of [0.47, 0.35, 0.23]) stroke(ctx, [P(hip, cw * 0.05, T * v), P(hip, cw * 0.6, T * (v + 0.01))], mus, 1.8, 0.8);
      stroke(ctx, [P(hip, cw * 0.32, T * 0.56), P(hip, cw * 0.32, T * 0.14)], mus, 1.6, 0.7);
      stroke(ctx, [P(hip, cw * 0.55, T * 0.85), P(hip, cw * 0.95, T * 0.8)], tint(C.skin, 0.5), 3, 0.5); // brillo pectoral
    }
    if (L.tattoos && !solid) {
      const ink = C.ink || '#2f3a36';
      ctx.save(); ctx.globalAlpha *= 0.62;
      // cabeza de lobo en el pecho
      poly(ctx, [P(hip, cw * 0.05, T * 0.8), P(hip, cw * 0.2, T * 0.9), P(hip, cw * 0.38, T * 0.78), P(hip, cw * 0.56, T * 0.9),
        P(hip, cw * 0.7, T * 0.8), P(hip, cw * 0.6, T * 0.6), P(hip, cw * 0.38, T * 0.48), P(hip, cw * 0.16, T * 0.6)], ink, false);
      ellipse(ctx, P(hip, cw * 0.27, T * 0.72), 1.6, 1.2, '#b8442c', false);
      ellipse(ctx, P(hip, cw * 0.5, T * 0.72), 1.6, 1.2, '#b8442c', false);
      // tribales en los hombros y letras en el abdomen
      stroke(ctx, [P(hip, -sw * 0.5, T - 2), P(hip, -sw * 0.1, T * 0.88), P(hip, sw * 0.3, T - 4), P(hip, sw * 0.8, T * 0.9)], ink, 2.2);
      stroke(ctx, [P(hip, -sw * 0.3, T * 0.9), P(hip, 0, T * 0.82), P(hip, sw * 0.1, T * 0.92)], ink, 1.6);
      for (let i = 0; i < 6; i++) stroke(ctx, [P(hip, cw * (-0.15 + i * 0.16), T * 0.1), P(hip, cw * (-0.1 + i * 0.16), T * 0.17)], ink, 1.8);
      ctx.restore();
    }
    if (L.female && !solid) {
      // ombligo con piercing y línea de la cintura
      ellipse(ctx, P(hip, cw * 0.4, T * 0.16), 1.4, 2, shade(C.skin, 0.55), false);
      ellipse(ctx, P(hip, cw * 0.42, T * 0.11), 1.3, 1.3, '#e8e8f0', false);
      stroke(ctx, [P(hip, cw * 0.95, T * 0.4), P(hip, cw * 0.75, T * 0.25)], shade(C.skin, 0.7), 1.4, 0.5);
    }
    if (top === 'crop') {
      // top plateado de cuello alto que deja el abdomen descubierto
      const cp = smoothPath([P(hip, -sw * 0.75, T - 6), P(hip, -sw * 0.35, T + 4), P(hip, sw * 0.4, T + 4), P(hip, sw * 0.95, T - 8),
        P(hip, cw * 1.3, T * 0.7), P(hip, cw * 1.1, T * 0.52), P(hip, -cw * 0.95, T * 0.55)]);
      ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.stroke(cp); ctx.restore();
      cel(ctx, S, cp, C.top, tw * 0.35, 0.7);
      stroke(ctx, [P(hip, cw * 0.4, T * 0.92), P(hip, cw * 1.0, T * 0.75)], '#ffffff', 3, 0.8); // brillo metálico
      stroke(ctx, [P(hip, -cw * 0.9, T * 0.47), P(hip, cw * 1.0, T * 0.45)], C.top, 3); // tira bajo el pecho
    }
    if (top === 'tactical') {
      // chaleco táctico negro con parche blanco y bolsas
      const lo = L.buckles ? 0.02 : 0.35;
      const vp = smoothPath([P(hip, -sw * 0.85, T - 4), P(hip, -sw * 0.4, T + 2), P(hip, sw * 0.1, T - 4), P(hip, sw * 0.55, T + 2),
        P(hip, cw * 1.12, T * 0.72), P(hip, cw * 1.08, T * (lo + 0.01)), P(hip, -cw * 1.0, T * lo), P(hip, -cw * 1.02, T * 0.7)]);
      ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.stroke(vp); ctx.restore();
      cel(ctx, S, vp, C.top, tw * 0.3, 0.25);
      for (const v of [0.62, 0.5]) stroke(ctx, [P(hip, -cw * 0.6, T * v), P(hip, cw * 0.95, T * v)], tint(C.top, 0.25), 1.5, 0.8);
      poly(ctx, [P(hip, -cw * 0.4, T * 0.46), P(hip, -cw * 0.4, T * 0.36), P(hip, cw * 0.05, T * 0.36), P(hip, cw * 0.05, T * 0.46)], tint(C.top, 0.12));
      if (L.molle && !solid) for (const v of [0.44, 0.39, 0.56, 0.68]) stroke(ctx, [P(hip, -cw * 0.8, T * v), P(hip, cw * 1.0, T * v)], '#050506', 2.2, 0.9);
      if (L.buckles && !solid) {
        // escote en V, tres correas con argollas y hombreras con estoperoles
        poly(ctx, [P(hip, sw * 0.1, T - 3), P(hip, cw * 0.55, T * 0.66), P(hip, cw * 0.95, T - 3)], C.skin);
        for (const v of [0.56, 0.4, 0.24]) {
          stroke(ctx, [P(hip, -cw * 0.1, T * v), P(hip, cw * 1.0, T * v)], '#050506', 4.2);
          for (const u of [-0.1, 1.0]) ellipse(ctx, P(hip, cw * u, T * v), 2.6, 2.6, '#9a9ca6', true);
          for (let i = 1; i < 5; i++) ellipse(ctx, P(hip, cw * (-0.1 + i * 0.22), T * v), 0.9, 0.9, '#c8cad4', false);
        }
        stroke(ctx, [P(hip, cw * 0.45, T * 0.66), P(hip, cw * 0.45, T * 0.04)], '#050506', 1.6, 0.8); // cierre
        for (const s of [-1, 1]) for (let i = 0; i < 4; i++) ellipse(ctx, P(hip, s * sw * (0.35 + i * 0.15), T - 2), 1.1, 1.1, '#c8cad4', false);
      } else if (L.patchText && !solid) {
        const a0 = P(hip, -cw * 0.35, T * 0.82), a1 = P(hip, cw * 0.95, T * 0.82);
        const mid = { x: (a0.x + a1.x) / 2, y: (a0.y + a1.y) / 2 }, len = Math.hypot(a1.x - a0.x, a1.y - a0.y);
        ctx.save(); ctx.translate(mid.x, mid.y); ctx.rotate(Math.atan2(a1.y - a0.y, a1.x - a0.x) * (fx > 0 ? 1 : 1) + (fx > 0 ? 0 : Math.PI));
        ctx.fillStyle = '#2a2a2e'; ctx.strokeStyle = '#6a6a72'; ctx.lineWidth = 1;
        ctx.fillRect(-len / 2, -5, len, 10); ctx.strokeRect(-len / 2, -5, len, 10);
        ctx.fillStyle = '#d8d8dc'; ctx.font = 'bold 5px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(L.patchText, 0, 0.5, len - 3);
        ctx.restore();
        const badge = P(hip, sw * 0.75, T - 4);
        ctx.fillStyle = '#d8d8dc'; ctx.fillRect(badge.x - 3, badge.y - 2, 6, 4);
      } else if (!solid) {
        const pc = P(hip, cw * 0.5, T * 0.56);
        ellipse(ctx, pc, tw * 0.3, tw * 0.3, '#f4f4f0');
        stroke(ctx, [{ x: pc.x - tw * 0.18, y: pc.y }, { x: pc.x + tw * 0.18, y: pc.y }], INK, 1.6, 0.8);
        stroke(ctx, [P(hip, -cw * 0.2, T * 0.84), P(hip, cw * 0.7, T * 0.84)], '#e0e0e0', 2, 0.8); // etiqueta
      }
    }
    if (L.chainNecklace && !solid) {
      ctx.save(); ctx.setLineDash([2, 1.5]);
      stroke(ctx, [P(hip, -sw * 0.3, T + 2), P(hip, cw * 0.35, T * 0.8), P(hip, sw * 0.5, T + 2)], C.chain || '#e4e4ea', C.chain ? 3.2 : 2.2);
      ctx.restore();
    }
    if (L.sweat && !solid) {
      ellipse(ctx, P(hip, cw * 0.7, T * 0.84), 1.4, 2, 'rgba(255,255,255,0.75)', false);
      ellipse(ctx, P(hip, cw * 0.2, T * 0.4), 1.2, 1.8, 'rgba(255,255,255,0.6)', false);
    }
    if (top === 'tshirt') {
      stroke(ctx, [P(hip, -sw * 0.45, T + 1), P(hip, 0, T - 5), P(hip, sw * 0.5, T + 1)], C.collar || shade(C.top, 0.7), 4);
      if (L.colors.shirtText && !solid) {
        for (const v of [0.68, 0.56, 0.44]) stroke(ctx, [P(hip, cw * 0.05, T * v), P(hip, cw * 0.85, T * v)], C.shirtText, 3.5);
      }
      // pliegues de la tela
      stroke(ctx, [P(hip, cw * 0.4, T * 0.25), P(hip, cw * 0.7, T * 0.1)], shade(C.top, 0.6), 1.6, 0.6);
      stroke(ctx, [P(hip, -cw * 0.3, T * 0.4), P(hip, cw * 0.1, T * 0.3), P(hip, cw * 0.3, T * 0.18)], shade(C.top, 0.65), 1.6, 0.55);
      stroke(ctx, [P(hip, -sw * 0.7, T - 8), P(hip, -cw * 0.5, T * 0.6)], shade(C.top, 0.6), 1.4, 0.5);
      stroke(ctx, [P(hip, cw * 0.6, T * 0.82), P(hip, cw * 0.95, T * 0.6)], tint(C.top, 0.35), 3, 0.4);
    }
    if (top === 'gi') {
      poly(ctx, [P(hip, -sw * 0.1, T + 1), P(hip, sw * 0.55, T + 1), P(hip, cw * 0.35, T * 0.5)], C.skin, false);
      stroke(ctx, [P(hip, -sw * 0.1, T + 1), P(hip, cw * 0.35, T * 0.5), P(hip, cw * 0.9, T * 0.35)], tint(C.top, 0.3), 5);
    }
    if (top === 'jacket' || top === 'vest') {
      const jc = C.top;
      poly(ctx, [P(hip, -hw * 1.02, -4), P(hip, -ww * 1.02, T * 0.3), P(hip, -cw, T * 0.72), P(hip, -sw * 1.02, T - 5),
        P(hip, -sw * 0.5, T + 3), P(hip, sw * 0.05, T + 2), P(hip, cw * 0.15, T * 0.5), P(hip, ww * 0.1, -4)], jc);
      poly(ctx, [P(hip, cw * 0.62, T * 0.62), P(hip, sw * 0.6, T + 2), P(hip, sw * 1.02, T - 5), P(hip, cw * 1.08, T * 0.72),
        P(hip, ww * 1.03, T * 0.3), P(hip, hw * 1.03, -4), P(hip, ww * 0.68, -4)], jc);
      poly(ctx, [P(hip, -sw * 0.5, T + 3), P(hip, -sw * 0.05, T + 8), P(hip, cw * 0.15, T * 0.55), P(hip, sw * 0.05, T + 2)], tint(jc, 0.25)); // solapa
      poly(ctx, [P(hip, sw * 0.6, T + 2), P(hip, sw * 0.3, T + 8), P(hip, cw * 0.62, T * 0.62)], tint(jc, 0.25));
      stroke(ctx, [P(hip, -cw * 0.6, T * 0.6), P(hip, -cw * 0.4, T * 0.15)], tint(jc, 0.5), 2.5, 0.5); // brillo de cuero
      if (L.studs) for (const v of [0.82, 0.7, 0.58]) ellipse(ctx, P(hip, cw * 0.9, T * v), 2, 2, '#d8d4c8', false);
    }
    // cintura
    if (bottom === 'trunks' || bottom === 'shorts') {
      const sp = smoothPath([P(hip, -hw * 1.06, -12), P(hip, -hw * 1.04, 12), P(hip, hw * 1.04, 12), P(hip, hw * 1.08, -12), P(hip, 0, -16)]);
      ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.stroke(sp); ctx.restore();
      cel(ctx, S, sp, C.pants, 5, 0.4);
      poly(ctx, [P(hip, -hw * 1.05, 6), P(hip, -hw * 1.04, 13), P(hip, hw * 1.04, 13), P(hip, hw * 1.05, 6)], C.trim || C.accent);
      if (bottom === 'shorts' && !solid) poly(ctx, [P(hip, hw * 0.1, -4), P(hip, hw * 0.1, 3), P(hip, hw * 0.75, 3), P(hip, hw * 0.75, -4)], C.trim || '#ddd', false);
    } else {
      const beltC = C.belt || INK;
      poly(ctx, [P(hip, -hw * 1.04, -2), P(hip, -hw * 1.03, 9), P(hip, hw * 1.03, 9), P(hip, hw * 1.04, -2)], beltC);
      if (bottom === 'gi') {
        stroke(ctx, [P(hip, hw * 0.6, 3), P(hip, hw * 0.9 + sway, -18), P(hip, hw * 0.7 + sway, -30)], beltC, 4);
      } else {
        if (L.waistText && !solid) {
          const b0 = P(hip, -hw * 0.9, 4), b1 = P(hip, hw * 0.95, 4);
          ctx.save(); ctx.translate((b0.x + b1.x) / 2, (b0.y + b1.y) / 2); ctx.rotate(Math.atan2(b1.y - b0.y, b1.x - b0.x) + (fx > 0 ? 0 : Math.PI));
          ctx.fillStyle = '#e8e8ea'; ctx.font = '8px "UnifrakturMaguntia", serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText(L.waistText, 0, 0.5, Math.hypot(b1.x - b0.x, b1.y - b0.y) - 2);
          ctx.restore();
        } else poly(ctx, [P(hip, hw * 0.45, -1), P(hip, hw * 0.45, 8), P(hip, hw * 0.8, 8), P(hip, hw * 0.8, -1)], '#e3b54a');
      }
    }
    if (L.chain && !solid) {
      const a = P(hip, hw * 0.7, 0), b = P(hip, -hw * 0.6, 0);
      const mid = { x: (a.x + b.x) / 2 + sway, y: Math.max(a.y, b.y) + 16 };
      ctx.save(); ctx.setLineDash([3, 3]);
      stroke(ctx, [a, mid, b], '#cfd2d8', 2.5);
      ctx.restore();
    }
    if (L.necklace && !solid) {
      ctx.save(); ctx.setLineDash([2, 2]);
      stroke(ctx, [P(hip, -sw * 0.35, T + 1), P(hip, cw * 0.2, T * 0.78), P(hip, sw * 0.45, T + 1)], '#dcdce4', 2);
      ctx.restore();
    }
  };

  // ---- cabeza ----
  const r = L.headR;
  const H = (u, v) => P(head, u, v);
  const drawHairBack = () => {
    if (L.hair === 'mullet') {
      const s = sway * 0.5;
      poly(ctx, [H(0.1 * r, 0.9 * r), H(-0.95 * r, 0.6 * r), H(-1.15 * r - s, -0.6 * r), H(-1.05 * r - s, -1.35 * r), H(-0.55 * r - s, -1.1 * r), H(-0.3 * r, -0.4 * r)], C.hair);
    }
    if (L.buns) {
      for (const u of [-0.55, 0.3]) {
        const b = H(u * r, 1.15 * r);
        ellipse(ctx, b, r * 0.38, r * 0.34, C.hair);
        stroke(ctx, [{ x: b.x - r * 0.2, y: b.y }, { x: b.x + r * 0.15, y: b.y - r * 0.15 }], tint(C.hair, 0.3), 1.5, 0.7);
      }
    }
    if (L.hair === 'long') {
      const s = sway * 0.8;
      const strands = () => {
        ctx.save(); ctx.clip();
        for (let i = 0; i < 5; i++) stroke(ctx, [H((-0.4 - i * 0.22) * r, 0.6 * r), H((-0.7 - i * 0.25) * r - s, -1.2 * r), H((-0.5 - i * 0.25) * r - s, -2.6 * r)], shade(C.hair, 0.55), 1.5, 0.8);
        ctx.restore();
      };
      poly(ctx, [H(0.2 * r, 1.1 * r), H(-1.1 * r, 0.6 * r), H(-1.35 * r - s, -0.9 * r), H(-1.6 * r - s, -2.6 * r),
        H(-1.0 * r - s, -2.1 * r), H(-0.9 * r - s, -3.0 * r), H(-0.4 * r - s, -2.0 * r), H(-0.1 * r - s * 0.5, -2.7 * r),
        H(0.15 * r, -1.2 * r), H(0.3 * r, 0)], C.hair);
      strands();
    } else if (L.hair === 'ponytail') {
      const s = sway * 1.5;
      part(ctx, S, H(-0.9 * r, 0.5 * r), H(-1.9 * r - s, -0.6 * r), r * 0.7, r * 0.6, C.hair, 0.3);
      part(ctx, S, H(-1.9 * r - s, -0.6 * r), H(-2.1 * r - s * 1.4, -2.2 * r), r * 0.6, r * 0.25, C.hair, 0.3);
    }
  };
  const drawHairTop = () => {
    if (L.hair === 'bald') { // rapado: sólo el brillo de la calva
      if (!solid) stroke(ctx, [H(-0.3 * r, 0.75 * r), H(0.2 * r, 0.92 * r)], tint(C.skin, 0.45), 3, 0.7);
      return;
    }
    if (L.hair === 'buzz') {
      // degradado en los lados
      ctx.save(); ctx.globalAlpha *= solid ? 1 : 0.35;
      poly(ctx, [H(-1.0 * r, 0.25 * r), H(-0.9 * r, 0.75 * r), H(0.2 * r, 1.05 * r), H(0.75 * r, 0.75 * r), H(0.6 * r, 0.45 * r), H(-0.3 * r, 0.3 * r), H(-0.95 * r, -0.1 * r)], shade(C.hair, 0.45), false);
      ctx.restore();
      // copete corto peinado hacia arriba y al frente
      const top = smoothPath([H(-0.9 * r, 0.42 * r), H(-0.62 * r, 0.98 * r), H(0.1 * r, 1.2 * r), H(0.78 * r, 1.08 * r), H(1.06 * r, 0.62 * r), H(0.72 * r, 0.6 * r), H(0.1 * r, 0.66 * r), H(-0.5 * r, 0.5 * r)]);
      ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.stroke(top); ctx.restore();
      cel(ctx, S, top, C.hair, r * 0.18, 0.5);
      for (let i = 0; i < 5; i++) stroke(ctx, [H((-0.5 + i * 0.3) * r, 0.72 * r), H((-0.38 + i * 0.3) * r, 1.05 * r)], shade(C.hair, 0.65), 1.2, 0.7);
      return;
    }
    const pts = [];
    const spikes = L.hair === 'spiky' ? 7 : L.hair === 'long' ? 5 : 4;
    const tipR = L.hair === 'spiky' ? 1.8 : L.hair === 'long' ? 1.3 : 1.15;
    const a0 = 205, a1 = 55;
    for (let i = 0; i <= spikes; i++) {
      const a = (a0 + (a1 - a0) * (i / spikes)) * R;
      pts.push(H(Math.cos(a) * r * 1.08, Math.sin(a) * r * 1.08));
      if (i < spikes) {
        const am = (a0 + (a1 - a0) * ((i + 0.5) / spikes) + 22) * R; // puntas peinadas hacia atrás
        pts.push(H(Math.cos(am) * r * tipR, Math.sin(am) * r * tipR));
      }
    }
    // fleco sobre la frente
    pts.push(H(1.02 * r, 0.12 * r), H(0.72 * r, 0.42 * r), H(0.62 * r, -0.05 * r), H(0.35 * r, 0.45 * r), H(-0.4 * r, 0.3 * r), H(-1.0 * r, -0.2 * r));
    poly(ctx, pts, C.hair);
    ctx.save();
    ctx.clip();
    for (let i = 0; i < 6; i++) {
      const u0 = -0.9 + i * 0.32;
      stroke(ctx, [H(u0 * r + 0.3 * r, 1.1 * r), H(u0 * r - 0.1 * r, 0.4 * r), H(u0 * r - 0.5 * r, -0.2 * r)], shade(C.hair, 0.6), 1.6, 0.8);
    }
    stroke(ctx, [H(-0.7 * r, 0.55 * r), H(-0.1 * r, 0.95 * r), H(0.5 * r, 0.75 * r)], tint(C.hair, 0.45), 4, 0.7); // brillo
    ctx.restore();
    if (L.hair === 'long' && !L.slick) {
      // mechón largo sobre un lado de la cara (slick: peinado hacia atrás, sin mechón)
      part(ctx, S, H(0.55 * r, 0.6 * r), H(1.0 * r, -0.4 * r), r * 0.42, r * 0.3, C.hair, 0.3);
      part(ctx, S, H(1.0 * r, -0.4 * r), H(0.85 * r + sway * 0.2, -1.3 * r), r * 0.3, r * 0.15, C.hair, 0.2);
    }
  };
  const drawHead = () => {
    const NB = bone(P(neck, 0, -8), H(0, -0.4 * r), fx);
    body(ctx, S, [{ p: segPath(NB, PROF.neck, r * 0.85), c: C.skin, k: r * 0.25, gloss: 0 }]);
    muscleLine(ctx, NB, r * 0.85, [[0.1, -0.2], [0.5, 0.1], [0.95, 0.4], 0.45, 1.4], shade(C.skin, 0.55)); // esternocleidomastoideo
    if (L.neckTattoo && !solid) {
      const ink = C.ink || '#2f3a36';
      for (const [t0, v0] of [[0.15, 0.3], [0.4, -0.3], [0.6, 0.35], [0.85, 0]]) {
        muscleLine(ctx, NB, r * 0.85, [[t0, v0 - 0.3], [t0 + 0.1, v0 + 0.1], [t0, v0 + 0.4], 0.75, 1.8], ink);
      }
      muscleLine(ctx, NB, r * 0.85, [[0.05, -0.5], [0.12, 0], [0.05, 0.5], 0.8, 2.4], ink);
    }
    drawHairBack();
    const pts = [];
    for (let d = -25; d <= 215; d += 15) pts.push(H(Math.cos(d * R) * r, Math.sin(d * R) * r));
    pts.push(H(-0.55 * r, -0.85 * r), H(0.4 * r, -1.15 * r), H(0.82 * r, -0.62 * r));
    const skull = smoothPath(pts);
    ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 2; ctx.stroke(skull); ctx.restore();
    cel(ctx, S, skull, C.skin, r * 0.32, 0.3);
    if (L.hair !== 'long') {
      const ear = smoothPath([H(-0.1 * r, 0.14 * r), H(-0.32 * r, 0.16 * r), H(-0.34 * r, -0.16 * r), H(-0.14 * r, -0.24 * r)]);
      ctx.save(); ctx.strokeStyle = INK; ctx.lineWidth = OUT * 1.6; ctx.stroke(ear); ctx.restore();
      cel(ctx, S, ear, C.skin, r * 0.1, 0);
      stroke(ctx, [H(-0.18 * r, 0.06 * r), H(-0.27 * r, 0), H(-0.2 * r, -0.12 * r)], shade(C.skin, 0.6), 1.1, 0.7);
    }

    if (!solid) {
      // volumen de la cara
      stroke(ctx, [H(0.3 * r, 0.3 * r), H(0.75 * r, 0.25 * r)], shade(C.skin, 0.8), 3, 0.5);        // cuenca del ojo
      stroke(ctx, [H(0.25 * r, -0.2 * r), H(0.6 * r, -0.32 * r)], shade(C.skin, 0.78), 3, 0.5);     // pómulo
      stroke(ctx, [H(0.95 * r, -0.05 * r), H(0.85 * r, -0.25 * r)], shade(C.skin, 0.75), 2.4, 0.6); // lado de la nariz
      stroke(ctx, [H(-0.2 * r, -0.75 * r), H(0.3 * r, -1.0 * r)], shade(C.skin, 0.72), 3, 0.5);     // quijada
      if (L.stubble) {
        ctx.save(); ctx.globalAlpha *= 0.28; ctx.fillStyle = INK;
        for (let i = 0; i < 26; i++) {
          const uu = -0.3 + ((i * 37) % 100) / 100 * 1.1, vv = -0.55 - ((i * 53) % 100) / 100 * 0.5;
          const q = H(uu * r, vv * r); ctx.fillRect(q.x, q.y, 1.2, 1.2);
        }
        ctx.restore();
      }
      // cara estilo anime
      const hurt = HURT.has(f.state);
      const eyeC = H(0.52 * r, 0.06 * r);
      if (hurt) {
        stroke(ctx, [H(0.3 * r, 0.14 * r), H(0.72 * r, 0.0)], INK, 2.4);
        stroke(ctx, [H(0.5 * r, -0.5 * r), H(0.78 * r, -0.62 * r)], INK, 3);
      } else {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.ellipse(eyeC.x, eyeC.y, r * 0.22, r * 0.12, 0, 0, Math.PI * 2); ctx.fill();
        const iris = H(0.6 * r, 0.05 * r);
        ctx.fillStyle = L.colors.eyes || '#3a2414';
        ctx.beginPath(); ctx.arc(iris.x, iris.y, r * 0.1, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.fillRect(iris.x - 1 + fx, iris.y - 2, 1.6, 1.6);
        stroke(ctx, [H(0.28 * r, 0.16 * r), H(0.55 * r, 0.22 * r), H(0.78 * r, 0.14 * r)], INK, L.female ? 3.2 : 2.6);
        if (L.female) stroke(ctx, [H(0.78 * r, 0.14 * r), H(0.9 * r, 0.24 * r)], INK, 1.6);
      }
      const brow = L.face === 'snarl'
        ? [H(0.22 * r, 0.46 * r), H(0.78 * r, 0.26 * r)]
        : [H(0.24 * r, 0.4 * r), H(0.5 * r, 0.46 * r), H(0.78 * r, 0.4 * r)];
      stroke(ctx, brow, shade(L.colors.hair, 0.6), 2.8);
      stroke(ctx, [H(0.92 * r, 0.02 * r), H(1.04 * r, -0.24 * r), H(0.9 * r, -0.3 * r)], INK, 1.6, 0.8);
      if (!hurt) {
        if (L.face === 'snarl') {
          poly(ctx, [H(0.45 * r, -0.52 * r), H(0.86 * r, -0.46 * r), H(0.84 * r, -0.62 * r), H(0.47 * r, -0.66 * r)], '#f6f2e8');
          stroke(ctx, [H(0.55 * r, -0.53 * r), H(0.56 * r, -0.65 * r)], INK, 1, 0.6);
          stroke(ctx, [H(0.68 * r, -0.51 * r), H(0.69 * r, -0.64 * r)], INK, 1, 0.6);
        } else if (L.face === 'smile') {
          poly(ctx, [H(0.42 * r, -0.5 * r), H(0.86 * r, -0.46 * r), H(0.66 * r, -0.7 * r)], '#f8f6f0');
          stroke(ctx, [H(0.5 * r, -0.74 * r), H(0.72 * r, -0.76 * r)], shade(C.skin, 0.7), 2, 0.6); // labio inferior
        } else {
          stroke(ctx, [H(0.5 * r, -0.55 * r), H(0.8 * r, -0.52 * r)], INK, 1.8);
        }
      }
    }
    drawHairTop();
    if (L.hoops && !solid) {
      const e = H(-0.25 * r, -0.35 * r);
      ctx.save(); ctx.strokeStyle = '#d8dae2'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(e.x, e.y, r * 0.24, 0, 7); ctx.stroke(); ctx.restore();
    }
    if (L.goatee && !solid) { // chivo: sólo en la barbilla
      poly(ctx, [H(0.9 * r, -0.62 * r), H(0.72 * r, -1.12 * r), H(0.42 * r, -1.14 * r), H(0.38 * r, -0.74 * r), H(0.62 * r, -0.72 * r)], C.beard || C.hair);
    } else if (L.beard && !solid) { // barba cerrada en la quijada
      poly(ctx, [H(0.95 * r, -0.58 * r), H(0.78 * r, -1.08 * r), H(0.2 * r, -1.18 * r), H(-0.35 * r, -0.8 * r), H(-0.32 * r, -0.3 * r), H(0.05 * r, -0.5 * r), H(0.45 * r, -0.72 * r), H(0.86 * r, -0.7 * r)], C.beard || C.hair);
    }
    if ((L.mustache || L.beard || L.goatee) && !solid) poly(ctx, [H(0.42 * r, -0.4 * r), H(0.95 * r, -0.36 * r), H(0.96 * r, -0.5 * r), H(0.4 * r, -0.62 * r), H(0.32 * r, -0.72 * r), H(0.34 * r, -0.48 * r)], C.beard || C.hair);
    if (L.scar && !solid) stroke(ctx, [H(0.35 * r, 0.62 * r), H(0.62 * r, 0.12 * r)], '#e8a090', 1.6, 0.9);
    if (L.lips && !solid) stroke(ctx, [H(0.48 * r, -0.62 * r), H(0.82 * r, -0.58 * r)], L.lips, 2.4, 0.9);
    if (L.shades || L.glasses) {
      const lens = [H(0.2 * r, 0.28 * r), H(1.08 * r, 0.26 * r), H(1.04 * r, -0.08 * r), H(0.3 * r, -0.06 * r)];
      if (L.shades) {
        poly(ctx, lens, '#141416');
        stroke(ctx, [H(0.45 * r, 0.18 * r), H(0.95 * r, 0.16 * r)], '#e8a838', 2.2, 0.85); // reflejo dorado
      } else {
        ctx.save(); ctx.globalAlpha *= 0.25; poly(ctx, lens, '#cfe4ff', false); ctx.restore();
        ctx.save(); ctx.strokeStyle = L.frame || '#c8ccd6'; ctx.lineWidth = L.frame ? 2.2 : 1.6; ctx.beginPath();
        lens.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath(); ctx.stroke(); ctx.restore();
      }
      stroke(ctx, [H(0.2 * r, 0.2 * r), H(-0.3 * r, 0.12 * r)], '#2a2a2e', 1.6); // patilla
    }
    if (L.headband) {
      poly(ctx, [H(-1.05 * r, 0.25 * r), H(1.0 * r, 0.3 * r), H(1.0 * r, 0.52 * r), H(-1.05 * r, 0.5 * r)], C.accent);
      const tail = H(-1.0 * r, 0.38 * r), s = sway * 1.6;
      part(ctx, S, tail, H(-2.1 * r - s, 0.05 * r), 5, 3, C.accent, 0.2);
      part(ctx, S, tail, H(-1.9 * r - s, -0.5 * r), 5, 3, shade(C.accent, 0.85), 0.2);
    }
  };

  if (L.skate) {
    // patineta: tabla con colas levantadas, ejes y ruedas que giran con el movimiento
    const by = groundY - 13, half = 50, spin = (f.x * 0.2) % (Math.PI * 2);
    ctx.save();
    ctx.lineWidth = OUT * 2; ctx.strokeStyle = INK;
    for (const s of [-1, 1]) {
      const wx = f.x + s * 32;
      ctx.fillStyle = solid || '#9a9ca6'; ctx.fillRect(wx - 7, by + 4, 14, 4);                 // eje
      ctx.beginPath(); ctx.arc(wx, groundY - 6, 6, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = solid || C.wheel || '#e8e2c8'; ctx.fill();
      ctx.strokeStyle = solid || '#7a7466'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(wx, groundY - 6); ctx.lineTo(wx + Math.cos(spin) * 5, groundY - 6 + Math.sin(spin) * 5); ctx.stroke();
      ctx.lineWidth = OUT * 2; ctx.strokeStyle = INK;
    }
    ctx.beginPath();
    ctx.moveTo(f.x - half - 6, by - 8); ctx.quadraticCurveTo(f.x - half, by, f.x - half + 12, by);
    ctx.lineTo(f.x + half - 12, by); ctx.quadraticCurveTo(f.x + half, by, f.x + half + 6, by - 8);
    ctx.lineTo(f.x + half + 4, by - 3); ctx.quadraticCurveTo(f.x + half - 2, by + 6, f.x + half - 12, by + 6);
    ctx.lineTo(f.x - half + 12, by + 6); ctx.quadraticCurveTo(f.x - half + 2, by + 6, f.x - half - 4, by - 3);
    ctx.closePath();
    ctx.stroke();
    ctx.fillStyle = solid || C.board || '#b3141a'; ctx.fill();
    if (!solid) { ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(f.x - half + 10, by + 3, half * 2 - 20, 3); } // lija
    ctx.restore();
  }
  drawArm(armB, true);
  drawLeg(legB, true);
  drawTorso();
  drawLeg(legF, false);
  drawHead();
  drawArm(armF, false);
  GLOW = null;
  ctx.restore();

  return { handF: armF[2], handB: armB[2], head };
}
