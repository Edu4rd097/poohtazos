// Dibuja a un luchador como un esqueleto articulado a partir de una pose.
// Para usar sprites en lugar del esqueleto, reemplaza drawFighter() conservando su firma.
export { drawFighter, drawShadow } from './figure.js';

const RAD = Math.PI / 180;
const ease = t => (t <= 0 ? 0 : t >= 1 ? 1 : t * t * (3 - 2 * t));

export function lerpPose(a, b, t) {
  const o = {};
  for (const k in a) {
    const va = a[k], vb = b[k] ?? va;
    o[k] = Array.isArray(va) ? va.map((v, i) => v + ((vb[i] ?? v) - v) * t) : va + (vb - va) * t;
  }
  return o;
}

// Pose actual de un luchador según su estado
export function poseFor(f) {
  const P = f.poses;
  switch (f.state) {
    case 'idle': {
      const b = Math.sin(f.frame * 0.08);
      const g = P.guard;
      return { ...g, torso: g.torso + b * 1.5, armF: [g.armF[0] + b * 3, g.armF[1]], armB: [g.armB[0] - b * 3, g.armB[1]] };
    }
    case 'walk': {
      const ph = f.x * 0.045, s = Math.sin(ph), c = Math.cos(ph);
      return {
        ...P.guard,
        legF: [12 + 22 * s, -4 - 22 * Math.max(0, c)],
        legB: [-12 - 22 * s, -4 - 22 * Math.max(0, -c)],
      };
    }
    case 'crouch':
      return f.input.state[f.backKey] ? P.crouchBlock : P.crouch;
    case 'air':
      return lerpPose(P.jump, P.guard, f.vy > 600 ? 0.4 : 0);
    case 'land':
      return lerpPose(P.crouch, P.guard, ease(f.stateFrame / 4));
    case 'dash': return P.dash;
    case 'backdash': return P.backdash;
    case 'attack': {
      const m = f.move, t = f.moveFrame;
      const from = m.air ? P.jump : m.crouch ? P.crouch : P.guard;
      const wind = P[m.windup] || from;
      // ráfaga: alterna entre dos golpes cada pocos cuadros mientras está activa
      const alt = m.alternate && t > m.startup && Math.floor((t - m.startup) / (m.hitInterval || 4)) % 2;
      const strike = P[alt ? m.strikeAlt : m.strike] || from;
      if (t <= m.startup) return lerpPose(from, wind, ease(t / m.startup));
      if (t <= m.startup + m.active) return lerpPose(wind, strike, Math.min(1, (t - m.startup) / 2));
      return lerpPose(strike, from, ease((t - m.startup - m.active) / m.recovery));
    }
    case 'hitstun': return lerpPose(P.hurt, P.guard, f.stun < 6 ? 1 - f.stun / 6 : 0);
    case 'blockstun': return f.holdingDown() ? P.crouchBlock : P.block;
    case 'airhit': return P.hurtAir;
    case 'knockdown': case 'ko': return P.lying;
    case 'getup': return lerpPose(P.lying, P.crouch, ease(f.stateFrame / 14));
    case 'win': return lerpPose(P.guard, P.victory, ease(f.stateFrame / 20));
    case 'intro': return lerpPose(P.guard, P.intro || P.victory, ease(f.stateFrame / 25));
    default: return P.guard;
  }
}

