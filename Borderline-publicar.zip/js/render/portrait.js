// Retratos 16-bit generados por código a partir del `look` de cada peleador.
// Se dibuja la cara en una cuadrícula chica (40×48), se reduce a una paleta corta
// (como los sprites de arcade), se le pone contorno negro y se amplía con píxeles nítidos.
const GW = 40, GH = 48, SCALE = 6;

const hex = c => { const n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const css = ([r, g, b]) => `rgb(${r | 0},${g | 0},${b | 0})`;
const mul = (c, k) => hex(c).map(v => Math.max(0, Math.min(255, v * k)));
const lit = (c, k) => hex(c).map(v => v + (255 - v) * k);
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
const INK = [20, 8, 10];

function hash(s) { let h = 7; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; }

export function makePortrait(def) {
  const L = def.look, C = L.colors;
  const c = document.createElement('canvas'); c.width = GW; c.height = GH;
  const g = c.getContext('2d');
  const pal = [];
  const col = rgb => { pal.push(rgb); return css(rgb); };
  const skin = col(hex(C.skin)), skinS = col(mul(C.skin, 0.72)), skinD = col(mul(C.skin, 0.5)), skinL = col(lit(C.skin, 0.28));
  const hair = col(hex(C.hair)), hairS = col(mul(C.hair, 0.6)), hairL = col(lit(C.hair, 0.3));
  const beard = C.beard ? col(hex(C.beard)) : hair;
  const white = col([238, 232, 220]), iris = col(hex(C.eyes || '#3a2414'));
  const blood = col([186, 20, 26]), bloodD = col([110, 8, 12]);
  const ink = col(hex(C.ink || '#2f3a36'));
  const lip = col(mul(C.skin, 0.62));
  const wrap = col(hex(C.wrap || '#e8e4da'));
  const shorts = col(hex(C.pants)), shortsS = col(mul(C.pants, 0.7).map((v, i) => Math.max(v, 18)));
  pal.push(INK);

  const ell = (x, y, rx, ry, f) => { g.fillStyle = f; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); g.fill(); };
  const poly = (pts, f) => { g.fillStyle = f; g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath(); g.fill(); };
  const rect = (x, y, w, h, f) => { g.fillStyle = f; g.fillRect(x, y, w, h); };

  const hairStyle = L.hair, snarl = L.face === 'snarl', smile = L.face === 'smile';
  const hw = L.limbW > 17 ? 1 : 0; // los grandotes: cuello y hombros más anchos

  // pelo largo por detrás (melena, mullet)
  if (hairStyle === 'mullet' || hairStyle === 'long') poly([[10, 14], [9, 30], [8, 37], [13, 34], [27, 34], [32, 37], [31, 30], [30, 14]], hair);
  if (hairStyle === 'ponytail') { ell(31, 10, 3, 3, hair); poly([[31, 9], [36, 12], [37, 22], [34, 28], [33, 18]], hair); }

  // hombros y trapecios (luchador musculoso)
  poly([[0, 48], [0, 40], [5 - hw, 36], [12 - hw, 32], [15 - hw, 29], [25 + hw, 29], [28 + hw, 32], [35 + hw, 36], [40, 40], [40, 48]], skin);
  poly([[0, 44], [5, 40], [10, 41], [14, 48], [0, 48]], skinS);              // sombra del pectoral
  poly([[26, 48], [30, 41], [35, 40], [40, 43], [40, 48]], skinD);
  rect(19.5, 40, 1, 8, skinS);                                                // línea del esternón
  poly([[8, 37], [15, 35], [19, 36], [15, 37]], skinL);                       // clavícula iluminada
  poly([[21, 36], [25, 35], [32, 37], [25, 37]], skinS);
  // cuello
  poly([[14 - hw, 24], [26 + hw, 24], [27 + hw, 33], [20, 35], [13 - hw, 33]], skin);
  poly([[22, 27], [27 + hw, 25], [27 + hw, 33], [22, 34]], skinS);
  rect(14, 27, 12, 2, skinD);                                                 // sombra de la quijada
  if (L.neckTattoo || L.tattoos) {
    rect(15, 30, 2, 3, ink); rect(17, 29, 1, 1, ink); rect(23, 30, 2, 2, ink); rect(24, 32, 2, 1, ink);
    if (L.tattoos) { rect(3, 41, 3, 1, ink); rect(4, 42, 1, 3, ink); rect(34, 41, 3, 1, ink); rect(35, 42, 1, 2, ink); }
  }
  // cabeza: cráneo + quijada cuadrada de boxeador
  ell(20, 15, 9.6, 10.5, skin);
  poly([[10.6, 16], [11.5, 24], [15.5, 28.5], [24.5, 28.5], [28.5, 24], [29.4, 16]], skin);
  ell(10.5, 18, 1.7, 2.8, skinS); ell(29.5, 18, 1.7, 2.8, skinD);               // orejas
  // sombreado: luz desde la izquierda, sombra a la derecha
  g.save(); g.beginPath(); g.ellipse(20, 15, 9.6, 10.5, 0, 0, Math.PI * 2);
  g.moveTo(10.6, 16); [[11.5, 24], [15.5, 28.5], [24.5, 28.5], [28.5, 24], [29.4, 16]].forEach(([x, y]) => g.lineTo(x, y)); g.clip();
  ell(29, 18, 5.4, 13, skinS);
  ell(30.5, 20, 3, 12, skinD);
  ell(14.5, 9, 3.2, 2.6, skinL);                                              // frente
  rect(12, 21, 4, 1, skinS); rect(24, 21, 4, 1, skinD);                       // pómulos
  rect(16, 28, 8, 1, skinS);                                                  // barbilla
  g.restore();

  // cejas y ojos
  const by = 15;
  if (snarl) { poly([[12, by - 1], [18, by + 1], [18, by + 2.4], [12, by + 0.6]], hairS); poly([[22, by + 1], [28, by - 1], [28, by + 0.6], [22, by + 2.4]], hairS); }
  else { rect(12, by, 6, 1.6, hairS); rect(22, by, 6, 1.6, hairS); }
  rect(13, by + 2, 4, 1, skinS); rect(23, by + 2, 4, 1, skinD);              // cuenca
  rect(13.5, 18, 3.5, 1.6, white); rect(23, 18, 3.5, 1.6, white);
  rect(15, 18, 1.5, 1.6, iris); rect(23.5, 18, 1.5, 1.6, iris);
  // nariz
  rect(20.5, 18, 1.2, 5, skinS); rect(19, 21, 1, 1.5, skinL);
  rect(17.5, 23, 2, 1, skinD); rect(21, 23, 2, 1, skinD);
  // boca
  if (snarl) { rect(16.5, 25, 7, 2.2, INK.map(v => v) && css(INK)); rect(17, 25.3, 6, 0.9, white); }
  else if (smile) { poly([[16, 25], [24, 25], [22.5, 27], [17.5, 27]], css(INK)); rect(17, 25.2, 6, 0.8, white); }
  else { rect(17, 25.5, 6, 1, lip); rect(17.5, 26.5, 5, 0.8, skinL); }

  // bigote / barba
  if (L.beard) {
    poly([[11.5, 22], [12, 26], [15.5, 30.5], [24.5, 30.5], [28, 26], [28.5, 22], [26, 24.5], [24, 28], [16, 28], [14, 24.5]], beard);
    rect(18, 28.5, 4, 1, hairL);
  }
  if (L.goatee) { poly([[17, 27.5], [23, 27.5], [22.5, 31.5], [20, 32.5], [17.5, 31.5]], beard); }
  if (L.mustache || L.beard || L.goatee) poly([[15.5, 24.8], [20, 23.6], [24.5, 24.8], [25.5, 27], [23.5, 25.6], [16.5, 25.6], [14.5, 27]], beard);
  if (L.stubble) for (let i = 0; i < 18; i++) rect(14 + (i * 7) % 12, 25 + (i * 5) % 4, 1, 1, skinS);

  // pelo arriba
  if (hairStyle === 'spiky') {
    poly([[9.6, 15], [8, 6], [11.5, 7], [11, 1], [15.5, 4.5], [17, -1], [20.5, 3.5], [24, -1], [25.5, 4], [30, 1], [29, 7], [32, 6], [30.4, 15], [28, 10], [24, 9], [20, 11], [16, 9], [12, 10]], hair);
    poly([[13, 6], [16, 3], [19, 6], [16, 7]], hairL); poly([[23, 5], [26, 4], [27, 8]], hairS);
  } else if (hairStyle === 'buzz') {
    poly([[10, 14], [10.5, 8], [14, 4], [20, 3], [26, 4], [29.5, 8], [30, 14], [28, 9.5], [20, 8.5], [12, 9.5]], hair);
    for (let i = 0; i < 6; i++) rect(12 + i * 3, 6 + (i % 2), 1, 1, hairL);
    rect(10, 10, 1, 5, hairS); rect(29, 10, 1, 5, hairS);
  } else if (hairStyle === 'mullet' || hairStyle === 'long') {
    poly([[10, 16], [9.5, 8], [14, 3.5], [20, 2.5], [26, 3.5], [30.5, 8], [30, 16], [28, 10], [23, 8], [18, 9.5], [13, 10]], hair);
    poly([[14, 5], [19, 4], [16, 7]], hairL); rect(26, 8, 2, 4, hairS);
  } else if (hairStyle === 'ponytail') {
    poly([[10, 14], [10, 8], [14, 4], [20, 3], [26, 4], [30, 8], [30, 14], [27, 9], [20, 7.5], [13, 9]], hair);
    rect(14, 5, 5, 1, hairL); rect(29, 9, 2, 3, wrap);
  } else if (hairStyle === 'bald') {
    ell(15, 7.5, 3, 1.6, skinL); rect(14, 7, 2, 1, css([255, 245, 230]));
  }

  // ceja abierta y sangre escurriendo (a puño limpio)
  const side = hash(def.id) % 2 ? 1 : -1, bx = side > 0 ? 25 : 13;
  rect(bx, by - 0.5, 2.5, 1.2, blood);
  rect(bx + (side > 0 ? 1.5 : 0), by + 0.5, 1, 4, blood);
  rect(bx + (side > 0 ? 1.5 : 0), by + 4.5, 1, 3, bloodD);
  rect(side > 0 ? 22 : 17, 23.5, 1, 2.5, blood);                               // nariz sangrando
  if (L.scar) rect(13, 11, 1, 4, skinL);

  // ---- paleta reducida + contorno ----
  const img = g.getImageData(0, 0, GW, GH), d = img.data;
  const solid = new Uint8Array(GW * GH);
  for (let i = 0; i < GW * GH; i++) {
    const o = i * 4;
    if (d[o + 3] < 110) { d[o + 3] = 0; continue; }
    let best = pal[0], bd = 1e9;
    for (const p of pal) { const e = (p[0] - d[o]) ** 2 + (p[1] - d[o + 1]) ** 2 + (p[2] - d[o + 2]) ** 2; if (e < bd) { bd = e; best = p; } }
    d[o] = best[0]; d[o + 1] = best[1]; d[o + 2] = best[2]; d[o + 3] = 255; solid[i] = 1;
  }
  for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
    const i = y * GW + x;
    if (solid[i]) continue;
    const n = (x > 0 && solid[i - 1]) || (x < GW - 1 && solid[i + 1]) || (y > 0 && solid[i - GW]) || (y < GH - 1 && solid[i + GW]);
    if (n) { const o = i * 4; d[o] = INK[0]; d[o + 1] = INK[1]; d[o + 2] = INK[2]; d[o + 3] = 255; }
  }
  // fondo: rojo oscuro con tramado y gotas de sangre
  const tone = hash(def.id + 'bg') % 3;
  for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
    const o = (y * GW + x) * 4;
    if (d[o + 3]) continue;
    const t = y / GH + (BAYER[(y % 4) * 4 + (x % 4)] / 16 - 0.5) * 0.25;
    const lv = t < 0.33 ? 0 : t < 0.66 ? 1 : 2;
    const base = [[58, 8, 12], [34, 5, 8], [14, 3, 5]][lv];
    const drip = (x * 7 + tone * 5) % 11 === 0 && y < 6 + ((x * 13) % 9);
    const c2 = drip ? [150, 14, 20] : base;
    d[o] = c2[0]; d[o + 1] = c2[1]; d[o + 2] = c2[2]; d[o + 3] = 255;
  }
  g.putImageData(img, 0, 0);

  const big = document.createElement('canvas'); big.width = GW * SCALE; big.height = GH * SCALE;
  const bg = big.getContext('2d'); bg.imageSmoothingEnabled = false;
  bg.drawImage(c, 0, 0, big.width, big.height);
  return big.toDataURL('image/png');
}

// Asigna el retrato a cada personaje que no tenga foto propia.
export function assignPortraits(list) {
  for (const ch of list) {
    if (ch.portrait && !ch.portrait.startsWith('data:')) continue;
    try { ch.portrait = makePortrait(ch); ch.portraitFocus = 0.42; ch.pixelPortrait = true; } catch (e) { console.warn('retrato', ch.id, e); }
  }
}
