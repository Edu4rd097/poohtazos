// Ambiente nocturno para escenarios hechos con foto (como el Mural Duendes):
// cielo oscuro con estrellas, toda la escena a luz de luna (azulada) y luces cálidas encima.
import { STAGE } from '../config.js';

// opts.skyTo: hasta qué altura se oscurece el cielo · opts.lights: [x, y, radio, 'rgba(...)']
// opts.moon: [x, y] · opts.stars: altura máxima de las estrellas
export function nightGrade(g, { skyTo = 200, lights = [], moon = null, stars = 0, tint = '#3d4a78', focusY = 0.72 } = {}) {
  const W = STAGE.width, H = STAGE.height;
  g.save();
  // cielo: lo claro de arriba se vuelve azul noche
  const sky = g.createLinearGradient(0, 0, 0, skyTo);
  sky.addColorStop(0, '#04050c'); sky.addColorStop(0.75, '#0d1430'); sky.addColorStop(1, 'rgba(13,20,48,0)');
  g.globalCompositeOperation = 'darken';
  g.fillStyle = sky; g.fillRect(0, 0, W, skyTo);
  // luz de luna: más oscuro y azulado, con viñeta
  g.globalCompositeOperation = 'multiply';
  g.fillStyle = tint; g.fillRect(0, 0, W, H);
  const vig = g.createRadialGradient(W / 2, H * focusY, 120, W / 2, H * focusY, 820);
  vig.addColorStop(0, '#ffffff'); vig.addColorStop(1, '#40404c');
  g.fillStyle = vig; g.fillRect(0, 0, W, H);
  // luces cálidas
  g.globalCompositeOperation = 'screen';
  for (const [x, y, r, col] of lights) {
    const lg = g.createRadialGradient(x, y, 0, x, y, r);
    lg.addColorStop(0, col); lg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = lg; g.fillRect(x - r, y - r, r * 2, r * 2);
  }
  g.globalCompositeOperation = 'source-over';
  if (stars) {
    let sd = 9; const r = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 90; i++) { g.fillStyle = r() > 0.75 ? 'rgba(220,226,255,0.9)' : 'rgba(150,160,210,0.6)'; g.fillRect(r() * W, r() * stars, 2, 2); }
  }
  if (moon) {
    g.fillStyle = '#e8e4cc'; g.beginPath(); g.arc(moon[0], moon[1], 26, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#060814'; g.beginPath(); g.arc(moon[0] + 12, moon[1] - 8, 24, 0, Math.PI * 2); g.fill();
  }
  g.restore();
}

// farol de calle: poste, brazo y foco (la luz se agrega con nightGrade)
export function streetLamp(g, x, groundY, h = 220, dir = 1) {
  g.fillStyle = '#0c0c10';
  g.fillRect(x - 3, groundY - h, 6, h);
  g.fillRect(x, groundY - h, dir * 40, 6);
  g.fillStyle = '#1a1a20'; g.fillRect(x + dir * 28 - 10, groundY - h + 4, 22, 7);
  g.fillStyle = '#ffd890'; g.fillRect(x + dir * 28 - 8, groundY - h + 10, 18, 4);
}

// La Indepe: escalinata de la colonia Independencia con la barda "La Indepe no se vende".
// Foto 1024×682: se ajusta al ancho y se acomoda para que los peleadores pisen el pie de la escalera.
export function buildIndepe(img) {
  const c = document.createElement('canvas'); c.width = STAGE.width; c.height = STAGE.height;
  const g = c.getContext('2d');
  const W = STAGE.width, H = STAGE.height;
  const s = W / img.width, dh = img.height * s;
  const top = -60; // más abajo: así el letrero "La Indepe no se vende" alcanza a verse en la pelea
  g.drawImage(img, 0, top, W, dh);
  if (top + dh < H) g.drawImage(img, 0, img.height - 3, img.width, 3, 0, top + dh - 1, W, H - top - dh + 1);
  const P = (x, y) => [x * s, y * s + top];
  nightGrade(g, {
    skyTo: P(0, 260)[1], stars: P(0, 150)[1], moon: [300, 40], focusY: 0.75, tint: '#56648f',
    lights: [
      [...P(250, 330), 360, 'rgba(255,150,60,0.40)'],   // farol junto a la escalera
      [...P(680, 300), 380, 'rgba(255,150,70,0.45)'],   // barda "La Indepe" (letrero)
      [...P(700, 420), 300, 'rgba(255,150,70,0.30)'],   // mural de abajo
      [...P(532, 232), 34, 'rgba(255,190,90,0.6)'],     // ventana casa azul
      [...P(470, 170), 26, 'rgba(255,190,90,0.5)'],     // casa verde
      [...P(880, 270), 60, 'rgba(255,190,90,0.35)'],    // ventana del fondo
    ],
  });
  const [lx, ly] = P(250, 330);
  streetLamp(g, lx - 30, ly + 230, 230, 1);
  return c;
}

// La Fraustro: barda pintada con el grafiti "La Fraustro", poste de luz y ciprés.
// Foto 1024×768: los peleadores pisan el pasto frente a la barda y se ve el grafiti completo.
export function buildFraustro(img) {
  const c = document.createElement('canvas'); c.width = STAGE.width; c.height = STAGE.height;
  const g = c.getContext('2d');
  const W = STAGE.width;
  const s = W / img.width, dh = img.height * s;
  const top = -35;
  g.drawImage(img, 0, top, W, dh);
  const P = (x, y) => [x * s, y * s + top];
  nightGrade(g, {
    skyTo: P(0, 230)[1], stars: P(0, 120)[1], moon: [180, 60], focusY: 0.7, tint: '#56648f',
    lights: [
      [...P(700, 150), 420, 'rgba(255,150,60,0.45)'],   // foco del poste sobre la barda
      [...P(470, 360), 360, 'rgba(255,150,70,0.28)'],   // grafiti
      [...P(930, 270), 50, 'rgba(255,190,90,0.5)'],     // ventana
    ],
  });
  return c;
}
