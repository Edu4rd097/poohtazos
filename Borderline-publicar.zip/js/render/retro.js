// Modo 16-bit: la escena se dibuja en un lienzo de baja resolución, se le aplica un
// tramado ordenado (patrón Bayer 4×4) y se reduce la paleta a pocos niveles por canal
// con un filtro SVG (como las consolas de 16 bits). Luego se amplía con píxeles nítidos.
// Todo ocurre en la GPU: no se leen píxeles con getImageData (eso frenaba cada cuadro).
import { STAGE } from '../config.js';

const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

function ensureFilter(levels) {
  const id = 'retro16-' + levels;
  if (document.getElementById(id)) return id;
  const vals = Array.from({ length: levels }, (_, i) => (i / (levels - 1)).toFixed(3)).join(' ');
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('width', '0'); svg.setAttribute('height', '0');
  svg.style.position = 'absolute';
  svg.innerHTML = `<filter id="${id}" color-interpolation-filters="sRGB"><feComponentTransfer>
    <feFuncR type="discrete" tableValues="${vals}"/><feFuncG type="discrete" tableValues="${vals}"/>
    <feFuncB type="discrete" tableValues="${vals}"/></feComponentTransfer></filter>`;
  document.body.appendChild(svg);
  return id;
}

export class RetroScreen {
  constructor(pixel = 3, levels = 14, dither = 0.08) {
    this.pixel = pixel;
    const w = Math.round(STAGE.width / pixel), h = Math.round(STAGE.height / pixel);
    const mk = () => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
    this.canvas = mk(); this.ctx = this.canvas.getContext('2d');
    this.out = mk(); this.outCtx = this.out.getContext('2d');
    this.filter = `url(#${ensureFilter(levels)})`;
    this.dither = dither;
    // patrón Bayer en gris: 128 = sin cambio; el modo "overlay" desplaza cada píxel un poco
    const tile = document.createElement('canvas'); tile.width = tile.height = 4;
    const tg = tile.getContext('2d'), img = tg.createImageData(4, 4);
    BAYER.forEach((v, i) => { const g = Math.round(128 + (v / 15 - 0.5) * 255); img.data.set([g, g, g, 255], i * 4); });
    tg.putImageData(img, 0, 0);
    this.pattern = this.ctx.createPattern(tile, 'repeat');
  }

  // Contexto para dibujar en coordenadas de pantalla normales (1280×720)
  begin() {
    const g = this.ctx;
    g.setTransform(1 / this.pixel, 0, 0, 1 / this.pixel, 0, 0);
    return g;
  }

  present(screen) {
    const g = this.ctx, w = this.canvas.width, h = this.canvas.height;
    g.save();
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.globalCompositeOperation = 'overlay';
    g.globalAlpha = this.dither;
    g.fillStyle = this.pattern;
    g.fillRect(0, 0, w, h);
    g.restore();
    const o = this.outCtx;
    o.clearRect(0, 0, w, h);
    o.filter = this.filter;
    o.drawImage(this.canvas, 0, 0);
    o.filter = 'none';
    screen.save();
    screen.setTransform(1, 0, 0, 1, 0, 0);
    screen.imageSmoothingEnabled = false;
    screen.drawImage(this.out, 0, 0, STAGE.width, STAGE.height);
    screen.restore();
  }
}
