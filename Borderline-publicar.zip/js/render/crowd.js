// Público de la bodega: gente emocionada, saltando y levantando bates, tubos y manoplas,
// con playeras de bandas de metal. En medio, el hombre del chaleco táctico con su bate,
// y dos modelos sosteniendo el letrero BORDERLINE. Se dibuja cada cuadro (animado).
import { drawFighter } from './figure.js';
import { BASE_POSES } from '../characters/poses.js';
import { STAGE } from '../config.js';

export const GOTHIC = '"UnifrakturMaguntia", "Old English Text MT", "Times New Roman", serif';
const INK = '#0b090d';
const G = BASE_POSES.guard;

// generador pseudoaleatorio fijo (el público siempre es el mismo)
function rng(seed) { let s = seed; return () => ((s = (s * 16807) % 2147483647) / 2147483647); }

const SKINS = ['#c98a5e', '#a86a44', '#e0b08a', '#8a5434', '#d49a6e', '#7a4a2e'];
const HAIRS = ['#120d0b', '#2a1a12', '#3a2a1a', '#0d0d10', '#5a3a22'];
const SHIRTS = ['#121214', '#121214', '#121214', '#1a1a1d', '#2a0e10', '#16161a', '#3a3a40'];
const LOGOS = ['#f2f2f2', '#d8d8d8', '#c8262c', '#e8c228', '#f2f2f2'];
const WEAPONS = ['bat', 'pipe', 'knuckles', 'bat', 'none', 'phone', 'pipe', 'bottle', 'knuckles', 'none'];

function makeCrowd() {
  const r = rng(7);
  const people = [];
  const add = (x, row) => people.push({
    x, row,
    skin: SKINS[(r() * SKINS.length) | 0], hairC: HAIRS[(r() * HAIRS.length) | 0],
    hair: ['long', 'bald', 'cap', 'short', 'long', 'mohawk', 'short'][(r() * 7) | 0],
    shirt: SHIRTS[(r() * SHIRTS.length) | 0], logo: LOGOS[(r() * LOGOS.length) | 0], logoKind: (r() * 3) | 0,
    weapon: WEAPONS[(r() * WEAPONS.length) | 0], both: r() < 0.35, beard: r() < 0.4,
    ph: r() * Math.PI * 2, speed: 5 + r() * 4, size: 0.92 + r() * 0.16, lean: (r() - 0.5) * 0.15,
  });
  // fila de atrás (detrás del hombre y las modelos)
  for (let x = -10; x < STAGE.width + 30; x += 44 + r() * 14) add(x, 0);
  // fila de enfrente: deja libre el centro y los lados donde están los invitados
  for (let x = 10; x < STAGE.width; x += 58 + r() * 18) {
    if (Math.abs(x - 640) < 70 || Math.abs(x - 330) < 75 || Math.abs(x - 950) < 75) continue;
    add(x, 1);
  }
  return people;
}
let CROWD = null;

// trazo grueso con contorno de tinta (extremidad sencilla del público)
function limb(g, a, b, w, color) {
  g.lineCap = 'round';
  g.strokeStyle = INK; g.lineWidth = w + 3.5;
  g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
  g.strokeStyle = color; g.lineWidth = w;
  g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(b.x, b.y); g.stroke();
}
const shadeC = (c, k) => {
  const n = parseInt(c.slice(1), 16), f = v => Math.max(0, Math.min(255, Math.round(v * k)));
  return `rgb(${f((n >> 16) & 255)},${f((n >> 8) & 255)},${f(n & 255)})`;
};

function weapon(g, hand, dir, kind) {
  const ux = Math.cos(dir), uy = Math.sin(dir);
  const at = d => ({ x: hand.x + ux * d, y: hand.y + uy * d });
  if (kind === 'bat') {
    // bate de madera: delgado en el mango, grueso en la punta
    g.fillStyle = INK; g.strokeStyle = INK;
    const nx = -uy, ny = ux;
    const pts = [[-6, 2.2], [46, 5.5], [50, 4], [50, -4], [46, -5.5], [-6, -2.2]].map(([d, w]) => ({ x: hand.x + ux * d + nx * w, y: hand.y + uy * d + ny * w }));
    g.lineWidth = 3; g.lineJoin = 'round';
    g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y))); g.closePath(); g.stroke();
    g.fillStyle = '#b07a42'; g.fill();
    g.strokeStyle = '#e0b07a'; g.lineWidth = 1.5; const h1 = at(8), h2 = at(44); g.beginPath(); g.moveTo(h1.x + nx, h1.y + ny); g.lineTo(h2.x + nx * 3, h2.y + ny * 3); g.stroke();
  } else if (kind === 'pipe') {
    limb(g, at(-8), at(44), 4.5, '#8d939e');
    g.strokeStyle = '#d6dbe3'; g.lineWidth = 1.2; const a = at(0), b = at(40); g.beginPath(); g.moveTo(a.x - uy, a.y + ux); g.lineTo(b.x - uy, b.y + ux); g.stroke();
  } else if (kind === 'knuckles') {
    g.fillStyle = '#c9ced8'; g.strokeStyle = INK; g.lineWidth = 1.5;
    g.beginPath(); g.ellipse(hand.x + ux * 3, hand.y + uy * 3, 6, 3.5, dir + Math.PI / 2, 0, 7); g.fill(); g.stroke();
  } else if (kind === 'phone') {
    g.fillStyle = '#cfe8ff'; g.fillRect(hand.x - 3, hand.y - 9, 6, 10);
    g.fillStyle = 'rgba(190,225,255,0.18)'; g.beginPath(); g.arc(hand.x, hand.y - 4, 14, 0, 7); g.fill();
  } else if (kind === 'bottle') {
    limb(g, at(-2), at(16), 5, '#3d6b2a');
    limb(g, at(16), at(22), 2.5, '#3d6b2a');
  }
}

function person(g, p, t, ground, s) {
  const k = p.size * s;
  const cheer = Math.sin(t * p.speed + p.ph);
  const jump = Math.max(0, cheer) * 7 * k;
  const x = p.x, y = ground - jump;
  const torsoH = 66 * k, sh = 25 * k, headR = 12.5 * k;
  const neck = { x: x + p.lean * 20, y: y - torsoH };
  // torso (playera)
  const shirt = p.shirt;
  g.lineJoin = 'round';
  g.fillStyle = INK;
  g.beginPath();
  g.moveTo(x - sh * 0.8, y + 4); g.lineTo(x - sh - 2, neck.y + 6); g.quadraticCurveTo(neck.x, neck.y - 6, x + sh + 2, neck.y + 6); g.lineTo(x + sh * 0.8, y + 4);
  g.closePath(); g.fill();
  g.fillStyle = shirt;
  g.beginPath();
  g.moveTo(x - sh * 0.8 + 2, y + 4); g.lineTo(x - sh, neck.y + 7); g.quadraticCurveTo(neck.x, neck.y - 3, x + sh, neck.y + 7); g.lineTo(x + sh * 0.8 - 2, y + 4);
  g.closePath(); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.06)'; g.fillRect(x - sh * 0.7, neck.y + 8, sh * 0.5, torsoH - 12); // luz lateral
  // logo de banda (letras puntiagudas ilegibles, estilo metal)
  if (shirt !== '#3a3a40') {
    g.strokeStyle = p.logo; g.lineWidth = 1.6 * k; g.lineCap = 'butt';
    const ly = neck.y + 20 * k, lw = sh * 0.75;
    g.beginPath();
    for (let i = 0; i <= 8; i++) {
      const lx = x - lw + (i / 8) * lw * 2;
      g.lineTo(lx, ly + (i % 2 ? -5 : 4) * k * (p.logoKind === 1 ? 1.3 : 1));
    }
    g.stroke();
    if (p.logoKind === 0) { g.beginPath(); g.moveTo(x - lw * 0.9, ly - 7 * k); g.lineTo(x + lw * 0.9, ly - 7 * k); g.stroke(); }
    if (p.logoKind === 2) { g.beginPath(); g.arc(x, ly + 14 * k, 7 * k, 0, 7); g.stroke(); }
  }
  // brazos: levantados al ritmo, con arma
  const shL = { x: x - sh + 3, y: neck.y + 9 }, shR = { x: x + sh - 3, y: neck.y + 9 };
  const ua = 30 * k, fa = 28 * k;
  const arm = (sh0, side, up) => {
    const a1 = up ? -Math.PI / 2 + side * (0.35 + 0.3 * cheer) : Math.PI / 2 - side * 0.3;
    const a2 = up ? -Math.PI / 2 + side * (0.05 + 0.25 * cheer) : Math.PI / 2 + side * 0.4;
    const el = { x: sh0.x + Math.cos(a1) * ua, y: sh0.y + Math.sin(a1) * ua };
    const hand = { x: el.x + Math.cos(a2) * fa, y: el.y + Math.sin(a2) * fa };
    limb(g, sh0, el, 10 * k, shadeC(p.skin, 0.85));
    limb(g, sh0, { x: sh0.x + Math.cos(a1) * ua * 0.4, y: sh0.y + Math.sin(a1) * ua * 0.4 }, 12 * k, shirt); // manga
    limb(g, el, hand, 8.5 * k, p.skin);
    g.fillStyle = INK; g.beginPath(); g.arc(hand.x, hand.y, 6 * k, 0, 7); g.fill();
    g.fillStyle = p.skin; g.beginPath(); g.arc(hand.x, hand.y, 4.3 * k, 0, 7); g.fill();
    return { hand, dir: a2 };
  };
  const right = arm(shR, 1, true);
  const left = arm(shL, -1, p.both);
  if (p.weapon !== 'none') {
    const h = p.weapon === 'phone' ? left : right;
    weapon(g, h.hand, h.dir - Math.PI * 0.08, p.weapon);
  }
  // cabeza
  const hc = { x: neck.x, y: neck.y - headR - 2 };
  g.fillStyle = INK; g.beginPath(); g.arc(hc.x, hc.y, headR + 2, 0, 7); g.fill();
  g.fillStyle = p.skin; g.beginPath(); g.arc(hc.x, hc.y, headR, 0, 7); g.fill();
  g.fillStyle = 'rgba(0,0,0,0.22)'; g.beginPath(); g.arc(hc.x + headR * 0.35, hc.y + 1, headR * 0.85, -1.2, 1.9); g.fill();
  // pelo
  g.fillStyle = p.hairC;
  if (p.hair === 'long') {
    g.beginPath(); g.ellipse(hc.x, hc.y + headR * 0.4, headR * 1.15, headR * 1.6, 0, Math.PI * 1.05, Math.PI * 1.95, false); g.fill();
    g.fillRect(hc.x - headR * 1.15, hc.y - headR * 0.2, headR * 0.5, headR * 2.4 + cheer * 2);
    g.fillRect(hc.x + headR * 0.65, hc.y - headR * 0.2, headR * 0.5, headR * 2.4 - cheer * 2);
    g.beginPath(); g.arc(hc.x, hc.y - headR * 0.2, headR * 1.08, Math.PI, 0); g.fill();
  } else if (p.hair === 'cap') {
    g.fillStyle = '#18181c'; g.beginPath(); g.arc(hc.x, hc.y - headR * 0.15, headR * 1.05, Math.PI, 0); g.fill();
    g.fillRect(hc.x - headR * 0.2, hc.y - headR * 0.35, headR * 1.5, headR * 0.3);
  } else if (p.hair === 'short') {
    g.beginPath(); g.arc(hc.x, hc.y - headR * 0.2, headR * 1.04, Math.PI * 1.02, Math.PI * 1.98); g.fill();
  } else if (p.hair === 'mohawk') {
    g.beginPath(); g.moveTo(hc.x - headR * 0.25, hc.y - headR * 0.6);
    for (let i = 0; i < 5; i++) g.lineTo(hc.x - headR * 0.3 + i * headR * 0.15, hc.y - headR * (i % 2 ? 1.9 : 1.2));
    g.lineTo(hc.x + headR * 0.4, hc.y - headR * 0.6); g.fill();
  }
  if (p.beard) { g.fillStyle = shadeC(p.hairC, 1.2); g.beginPath(); g.arc(hc.x, hc.y + headR * 0.35, headR * 0.75, 0.15, Math.PI - 0.15); g.fill(); }
  // ojos y boca abierta gritando
  g.fillStyle = INK;
  g.fillRect(hc.x - headR * 0.45, hc.y - headR * 0.15, 2.2 * k, 2.2 * k);
  g.fillRect(hc.x + headR * 0.25, hc.y - headR * 0.15, 2.2 * k, 2.2 * k);
  const open = 0.25 + Math.max(0, cheer) * 0.55;
  g.fillStyle = '#3a0c10'; g.beginPath(); g.ellipse(hc.x - headR * 0.05, hc.y + headR * 0.45, headR * 0.3, headR * open, 0, 0, 7); g.fill();
}

// --- invitados dibujados con el mismo motor que los peleadores ---
// El jefe de la bodega: un grandote gótico, pálido, de melena negra larga y chivo, chaleco negro
// de hebillas con hombreras, brazos tatuados, coderas y guantes negros, pantalón negro. Frente al fuego.
const MAN = {
  name: 'Jefe', look: {
    thigh: 56, shin: 54, torso: 76, upperArm: 45, foreArm: 43, headR: 15, limbW: 17.5, torsoW: 47,
    build: { shoulder: 1.42, chest: 1.26, waist: 1.02, hip: 1.05 },
    top: 'tactical', buckles: true, bottom: 'pants', feet: 'boots', gloves: 'fingerless',
    hair: 'long', slick: true, face: 'snarl', goatee: true, tattoos: true, wristbands: true,
    colors: { skin: '#d9b8a2', top: '#141418', pants: '#16161a', belt: '#0a0a0c', accent: '#2a2a30', shoe: '#0e0e10', hair: '#140e0e', beard: '#1e1614', glove: '#121214', ink: '#3a3434', eyes: '#c8d2dc', aura: '#ff6a2a' },
  },
};
const GIRL = {
  name: 'Modelo', look: {
    thigh: 47, shin: 46, torso: 60, upperArm: 33, foreArm: 32, headR: 13.5, limbW: 10.5, torsoW: 30,
    build: { shoulder: 0.95, chest: 1.0, waist: 0.66, hip: 1.18 },
    female: true, top: 'crop', bottom: 'trunks', feet: 'boots', gloves: 'none',
    hair: 'long', buns: true, face: 'smile', glasses: true, hoops: true, lips: '#8a2a3a',
    fishnet: true, armwarmers: true, bracelets: true,
    colors: { skin: '#d8a07a', top: '#c9ccd4', pants: '#18181c', accent: '#18181c', shoe: '#141416', hair: '#4a2a1c', eyes: '#3a2414' },
  },
};
function guest(def, facing, pose, frame) {
  return { def, facing, state: 'idle', frame, flash: 0, invuln: 0, x: 0, y: 0, vx: 0, vy: 0, airborne: false, stateFrame: 0, poses: {}, input: { state: {} } };
}

function drawGirl(g, x, ground, s, facing, t, ph) {
  const bob = Math.sin(t * 3 + ph);
  const pose = { ...G, torso: 4 + bob * 2, armF: [196 + bob * 3, 186], armB: [200 + bob * 3, 190], legF: [8, -2], legB: [-6, -2] };
  g.save(); g.translate(x, ground - Math.abs(bob) * 3); g.scale(s, s); g.translate(0, -STAGE.floor);
  const parts = drawFighter(g, guest(GIRL, facing, pose, t * 60), pose);
  // letrero BORDERLINE sobre las manos
  const cx = (parts.handF.x + parts.handB.x) / 2, top = Math.min(parts.handF.y, parts.handB.y);
  g.fillStyle = '#1c1820'; g.strokeStyle = '#c8ccd6'; g.lineWidth = 3;
  g.beginPath(); g.rect(cx - 62, top - 74, 124, 74); g.fill(); g.stroke();
  g.strokeStyle = '#6a6e78'; g.lineWidth = 1; g.strokeRect(cx - 57, top - 69, 114, 64);
  g.fillStyle = '#ece8f2'; g.font = `24px ${GOTHIC}`; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('Borderline', cx, top - 36);
  // dedos sobre el letrero
  g.fillStyle = GIRL.look.colors.skin;
  for (const h of [parts.handF, parts.handB]) { g.beginPath(); g.arc(h.x, h.y - 2, 5, 0, 7); g.fill(); }
  g.restore();
}

function flames(g, x, ground, s, t) {
  g.save();
  const glow = g.createRadialGradient(x, ground - 150 * s, 10, x, ground - 150 * s, 190 * s);
  glow.addColorStop(0, 'rgba(255,120,30,0.45)'); glow.addColorStop(1, 'rgba(255,60,10,0)');
  g.fillStyle = glow; g.fillRect(x - 200 * s, ground - 360 * s, 400 * s, 360 * s);
  for (const [col, k] of [['#b3160e', 1], ['#ff5a14', 0.78], ['#ffb43a', 0.5]]) {
    g.fillStyle = col;
    for (let i = -5; i <= 5; i++) {
      const fx0 = x + i * 17 * s, h = (150 + 70 * Math.sin(i * 1.7 + t * 6) + 40 * Math.sin(t * 9 + i)) * s * k * (1 - Math.abs(i) * 0.06);
      const sway = Math.sin(t * 5 + i) * 10 * s;
      g.beginPath();
      g.moveTo(fx0 - 16 * s * k, ground);
      g.quadraticCurveTo(fx0 - 20 * s * k + sway * 0.5, ground - h * 0.55, fx0 + sway, ground - h);
      g.quadraticCurveTo(fx0 + 20 * s * k + sway * 0.5, ground - h * 0.5, fx0 + 16 * s * k, ground);
      g.fill();
    }
  }
  g.restore();
}

function drawMan(g, x, ground, s, t) {
  const sw = Math.sin(t * 1.6);
  // de pie, brazos abajo y puños cerrados, respirando lento: amenazante
  const pose = { ...G, torso: 1 + sw * 1.2, armF: [14 + sw * 2, 20 + sw * 3], armB: [-12 - sw * 2, -4], legF: [12, -2], legB: [-12, -2] };
  g.save(); g.translate(x, ground); g.scale(s, s); g.translate(0, -STAGE.floor);
  drawFighter(g, guest(MAN, 1, pose, t * 60), pose);
  g.restore();
}

function spotlight(g, x, y, r) {
  const l = g.createRadialGradient(x, y, 10, x, y, r);
  l.addColorStop(0, 'rgba(255,236,190,0.32)'); l.addColorStop(1, 'rgba(255,236,190,0)');
  g.fillStyle = l; g.fillRect(x - r, y - r, r * 2, r * 2);
}

export function drawCrowd(g, t, ground) {
  if (!CROWD) CROWD = makeCrowd();
  g.save();
  for (const p of CROWD) if (p.row === 0) person(g, p, t, ground - 30, 0.82);
  for (const p of CROWD) if (p.row === 1) person(g, p, t, ground + 4, 0.95);
  // el público queda en penumbra para que destaquen el jefe y las modelos
  g.fillStyle = 'rgba(6,4,10,0.5)'; g.fillRect(-50, 200, 1380, ground - 200 + 10);
  spotlight(g, 330, ground - 120, 150); spotlight(g, 950, ground - 120, 150);
  flames(g, 640, ground + 6, 1.15, t);
  drawGirl(g, 330, ground + 52, 1.12, 1, t, 0);
  drawGirl(g, 950, ground + 52, 1.12, -1, t, 1.7);
  drawMan(g, 640, ground + 62, 1.18, t);
  g.restore();
}
