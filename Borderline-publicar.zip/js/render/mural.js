// Escenario "Mural Duendes": la foto del mural, de noche.
// La foto es panorámica (1024×445): se ajusta al ancho de la pantalla y se coloca abajo,
// de modo que los peleadores pisen la banqueta frente al mural. Encima va un cielo nocturno
// y a la foto se le baja la luz (tono azul de noche) con un farol que ilumina el mural.
import { STAGE } from '../config.js';

export function buildMuralPhoto(img) {
  const c = document.createElement('canvas'); c.width = STAGE.width; c.height = STAGE.height;
  const g = c.getContext('2d');
  const W = STAGE.width, H = STAGE.height;
  const s = W / img.width, dh = img.height * s;
  const top = H - dh - 34; // los pies quedan sobre la banqueta, no sobre la barda
  g.drawImage(img, 0, top, W, dh);
  // debajo de la foto queda una franja: se rellena estirando la última fila (asfalto)
  g.drawImage(img, 0, img.height - 3, img.width, 3, 0, top + dh - 1, W, H - top - dh + 1);

  // ---- noche ----
  // 1) el cielo blanco de la foto se vuelve cielo nocturno (sólo donde la foto es muy clara y arriba)
  const sky = g.createLinearGradient(0, 0, 0, top + 150);
  sky.addColorStop(0, '#04050c'); sky.addColorStop(0.75, '#0d1430'); sky.addColorStop(1, 'rgba(13,20,48,0)');
  g.globalCompositeOperation = 'darken';
  g.fillStyle = sky; g.fillRect(0, 0, W, top + 150);
  // 2) toda la escena a luz de luna: más oscura y azulada
  g.globalCompositeOperation = 'multiply';
  g.fillStyle = '#3d4a78'; g.fillRect(0, 0, W, H);
  const vig = g.createRadialGradient(W / 2, H * 0.72, 120, W / 2, H * 0.72, 820);
  vig.addColorStop(0, '#ffffff'); vig.addColorStop(1, '#40404c');
  g.fillStyle = vig; g.fillRect(0, 0, W, H);
  // 3) luces: farol de sodio sobre el mural y ventanas encendidas
  g.globalCompositeOperation = 'screen';
  const glow = (x, y, r, col) => {
    const lg = g.createRadialGradient(x, y, 0, x, y, r);
    lg.addColorStop(0, col); lg.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = lg; g.fillRect(x - r, y - r, r * 2, r * 2);
  };
  glow(560, top + 240, 430, 'rgba(255,150,60,0.42)');      // farol sobre la barda del mural
  glow(1060, top + 150, 260, 'rgba(255,140,60,0.22)');     // portón
  glow(1050, top + 125, 40, 'rgba(255,190,90,0.6)');       // ventana de la casa azul
  glow(780, top + 70, 30, 'rgba(255,190,90,0.45)');        // casa verde
  g.globalCompositeOperation = 'source-over';
  // estrellas y luna en el cielo
  let sd = 9; const r = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 90; i++) { g.fillStyle = r() > 0.75 ? 'rgba(220,226,255,0.9)' : 'rgba(150,160,210,0.6)'; g.fillRect(r() * W, r() * (top + 60), 2, 2); }
  g.fillStyle = '#e8e4cc'; g.beginPath(); g.arc(1110, 60, 26, 0, Math.PI * 2); g.fill();
  g.fillStyle = '#060814'; g.beginPath(); g.arc(1122, 52, 24, 0, Math.PI * 2); g.fill();
  // el farol, montado sobre la barda del mural
  g.fillStyle = '#0c0c10'; g.fillRect(557, top + 196, 5, 34); g.fillRect(541, top + 192, 38, 7);
  g.fillStyle = '#ffd890'; g.fillRect(547, top + 199, 26, 5);
  return c;
}
