﻿// Escenarios. Cada uno se pinta una vez en un canvas fuera de pantalla y se reutiliza.
//   - 'monterrey': foto de fondo + malecón dibujado al frente donde pelean
import { STAGE } from '../config.js';
import { drawCrowd, GOTHIC } from './crowd.js';
import { buildMuralPhoto } from './mural.js';
import { nightGrade, streetLamp, buildIndepe, buildFraustro } from './night.js';

export const STAGES = [
  { id: 'bodega', name: 'LA BODEGA' },
  { id: 'mural', name: 'MURAL DUENDES', image: 'assets/stages/mural.webp', build: buildMuralPhoto },
  { id: 'indepe', name: 'LA INDEPE', image: 'assets/stages/indepe.webp', build: buildIndepe },
  { id: 'monterrey', name: 'PASEO SANTA LUCÍA', image: 'assets/stages/monterrey.webp' },
  { id: 'fraustro', name: 'LA FRAUSTRO', image: 'assets/stages/fraustro.webp', build: buildFraustro },
];

// Bodega abandonada en dos capas (el público animado va en medio, ver crowd.js):
//   fondo: muro de block y grafiti · frente: malla, piso, círculo blanco con letras góticas, focos y viñeta
function buildWarehouseBack() {
  const c = canvas(), g = c.getContext('2d');
  const W = STAGE.width, H = STAGE.height, floorTop = 540;
  // muro
  const wall = g.createLinearGradient(0, 0, 0, floorTop);
  wall.addColorStop(0, '#0d0c10'); wall.addColorStop(1, '#2a2629');
  g.fillStyle = wall; g.fillRect(0, 0, W, floorTop);
  g.strokeStyle = 'rgba(0,0,0,0.45)'; g.lineWidth = 2;
  for (let y = 60; y < floorTop; y += 34) {
    g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke();
    for (let x = ((y / 34) % 2) * 45; x < W; x += 90) { g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + 34); g.stroke(); }
  }
  // grafiti abstracto y manchas de humedad
  const blob = (x, y, rx, ry, color, a) => { g.globalAlpha = a; g.fillStyle = color; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); g.fill(); g.globalAlpha = 1; };
  blob(210, 260, 140, 60, '#7a1f2b', 0.35); blob(1040, 230, 170, 55, '#1f5a7a', 0.3); blob(640, 180, 90, 40, '#c9a227', 0.18);
  g.lineWidth = 9; g.lineCap = 'round';
  for (const [x, col] of [[150, '#d13a4a'], [980, '#3ab0d1']]) {
    g.strokeStyle = col; g.globalAlpha = 0.5; g.beginPath();
    g.moveTo(x, 280); g.bezierCurveTo(x + 40, 200, x + 90, 320, x + 140, 230); g.bezierCurveTo(x + 170, 190, x + 200, 300, x + 240, 250);
    g.stroke(); g.globalAlpha = 1;
  }
  for (let i = 0; i < 12; i++) blob(80 + i * 105, 470 + (i % 3) * 8, 50, 90, '#000', 0.12);
  return c;
}

function buildWarehouseFront() {
  const c = canvas(), g = c.getContext('2d');
  const W = STAGE.width, H = STAGE.height, floorTop = 540;
  const blob = (x, y, rx, ry, color, a) => { g.globalAlpha = a; g.fillStyle = color; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); g.fill(); g.globalAlpha = 1; };
  // malla ciclónica
  const fenceTop = 330, fenceBot = floorTop + 6;
  g.strokeStyle = 'rgba(170,175,185,0.35)'; g.lineWidth = 1.5;
  for (let x = -400; x < W + 400; x += 22) {
    g.beginPath(); g.moveTo(x, fenceTop); g.lineTo(x + (fenceBot - fenceTop), fenceBot); g.stroke();
    g.beginPath(); g.moveTo(x, fenceTop); g.lineTo(x - (fenceBot - fenceTop), fenceBot); g.stroke();
  }
  g.strokeStyle = '#6d727c'; g.lineWidth = 6;
  g.beginPath(); g.moveTo(0, fenceTop); g.lineTo(W, fenceTop); g.stroke();
  for (const x of [40, 190, 470, 810, 1090, 1240]) { g.beginPath(); g.moveTo(x, fenceTop - 8); g.lineTo(x, fenceBot); g.stroke(); }
  // piso de concreto con manchas de aceite y círculo pintado
  const floor = g.createLinearGradient(0, floorTop, 0, H);
  floor.addColorStop(0, '#3a3639'); floor.addColorStop(1, '#1b191b');
  g.fillStyle = floor; g.fillRect(0, floorTop, W, H - floorTop);
  for (let i = 0; i < 9; i++) blob(100 + i * 140 + (i % 2) * 40, 600 + (i % 3) * 30, 60 + (i % 4) * 15, 12 + (i % 3) * 4, '#000', 0.25);
  // círculo blanco pintado (relleno) con letras góticas negras BORDERLINE en el centro
  g.fillStyle = 'rgba(244,242,234,0.95)';
  g.beginPath(); g.ellipse(W / 2, STAGE.floor + 8, 410, 60, 0, 0, Math.PI * 2); g.fill();
  g.strokeStyle = 'rgba(20,18,20,0.6)'; g.lineWidth = 3; g.stroke(); // borde de la pintura
  g.save();
  g.translate(W / 2, STAGE.floor + 14); g.scale(1, 0.36);
  g.font = '118px ' + GOTHIC; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillStyle = '#121014'; g.fillText('Borderline', 0, 0);
  g.restore();
  // desgaste de la pintura
  g.fillStyle = 'rgba(40,36,38,0.55)';
  for (let i = 0; i < 260; i++) { const x = W / 2 + Math.sin(i * 12.9898) * 420, y = STAGE.floor + 8 + Math.sin(i * 78.233) * 62; g.fillRect(x, y, 2 + (i % 3), 1); }
  g.strokeStyle = 'rgba(0,0,0,0.35)'; g.lineWidth = 1;
  for (let k = 0; k < 7; k++) { const y = floorTop + 8 + k * k * 4; g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
  // focos colgando con conos de luz
  for (const x of [330, 640, 950]) {
    g.strokeStyle = '#111'; g.lineWidth = 2;
    g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 120); g.stroke();
    g.fillStyle = '#2b2b2b'; g.beginPath(); g.moveTo(x - 30, 140); g.lineTo(x + 30, 140); g.lineTo(x + 12, 118); g.lineTo(x - 12, 118); g.closePath(); g.fill();
    g.fillStyle = '#fff3c4'; g.beginPath(); g.arc(x, 142, 9, 0, Math.PI * 2); g.fill();
    const cone = g.createLinearGradient(0, 140, 0, H);
    cone.addColorStop(0, 'rgba(255,225,150,0.28)'); cone.addColorStop(1, 'rgba(255,225,150,0.03)');
    g.fillStyle = cone;
    g.beginPath(); g.moveTo(x - 26, 142); g.lineTo(x + 26, 142); g.lineTo(x + 330, H); g.lineTo(x - 330, H); g.closePath(); g.fill();
  }
  // viñeta
  const vg = g.createRadialGradient(W / 2, 470, 200, W / 2, 470, 900);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.65)');
  g.fillStyle = vg; g.fillRect(0, 0, W, H);
  return c;
}

const cache = new Map();
const images = new Map();

function loadImage(src) {
  if (!images.has(src)) {
    const img = new Image();
    img.src = src;
    images.set(src, img);
  }
  return images.get(src);
}

// Precarga (para que el escenario ya esté listo cuando empiece la pelea)
export function preloadStage(id) {
  const s = STAGES.find(x => x.id === id);
  if (s?.image) loadImage(s.image);
}

function canvas() {
  const c = document.createElement('canvas');
  c.width = STAGE.width; c.height = STAGE.height;
  return c;
}

// Foto a pantalla completa + malecón de cantera al frente (donde están los pies).
function buildPhoto(img) {
  const c = canvas(), g = c.getContext('2d');
  const W = STAGE.width, H = STAGE.height;
  const s = Math.max(W / img.width, H / img.height);
  const dw = img.width * s, dh = img.height * s;
  // alinear un poco hacia arriba para que el agua quede detrás del malecón
  g.drawImage(img, (W - dw) / 2, Math.min(0, (H - dh) / 2 - 30), dw, dh);

  // tono cálido de atardecer para integrar a los personajes
  const tint = g.createLinearGradient(0, 0, 0, H);
  tint.addColorStop(0, 'rgba(40,20,60,0.10)'); tint.addColorStop(1, 'rgba(20,10,30,0.25)');
  g.fillStyle = tint; g.fillRect(0, 0, W, H);

  // malecón: borde superior con barandal y piso de cantera en perspectiva
  const top = STAGE.floor - 34;
  const stone = g.createLinearGradient(0, top, 0, H);
  stone.addColorStop(0, '#b9a58c'); stone.addColorStop(0.25, '#9a8670'); stone.addColorStop(1, '#5e5040');
  g.fillStyle = stone; g.fillRect(0, top, W, H - top);
  // bordillo
  g.fillStyle = '#d8c7ad'; g.fillRect(0, top - 6, W, 8);
  g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(0, top + 2, W, 3);
  // losas
  g.strokeStyle = 'rgba(60,45,30,0.35)'; g.lineWidth = 2;
  for (let i = -14; i <= 14; i++) { g.beginPath(); g.moveTo(W / 2 + i * 70, top); g.lineTo(W / 2 + i * 150, H); g.stroke(); }
  for (const y of [top + 22, top + 52, top + 95]) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
  // barandal metálico al fondo del malecón
  g.strokeStyle = 'rgba(70,70,80,0.85)'; g.lineWidth = 3;
  g.beginPath(); g.moveTo(0, top - 38); g.lineTo(W, top - 38); g.stroke();
  for (let x = 20; x < W; x += 80) { g.beginPath(); g.moveTo(x, top - 38); g.lineTo(x, top - 4); g.stroke(); }
  // de noche: faroles a lo largo del malecón
  const lamps = [170, 640, 1110];
  nightGrade(g, { skyTo: 300, stars: 160, moon: [1060, 70], focusY: 0.8,
    lights: [...lamps.map(x => [x + 28, top - 200, 330, 'rgba(255,150,60,0.42)']), ...lamps.map(x => [x + 28, top + 40, 220, 'rgba(255,150,60,0.22)'])] });
  for (const x of lamps) streetLamp(g, x, top - 4, 210, 1);
  return c;
}

export function drawStage(ctx, id = 'bodega') {
  const def = STAGES.find(s => s.id === id) || STAGES[0];
  if (!cache.has(def.id)) {
    if (def.image) {
      const img = loadImage(def.image);
      if (!img.complete || !img.naturalWidth) {
        ctx.fillStyle = '#1a1424'; ctx.fillRect(0, 0, STAGE.width, STAGE.height);
        return;
      }
      cache.set(def.id, (def.build || buildPhoto)(img));
    } else {
      cache.set(def.id, { back: buildWarehouseBack(), front: buildWarehouseFront() });
    }
  }
  const layer = cache.get(def.id);
  if (layer.back) {
    ctx.drawImage(layer.back, 0, 0);
    drawCrowd(ctx, performance.now() / 1000, 545);
    ctx.drawImage(layer.front, 0, 0);
  } else ctx.drawImage(layer, 0, 0);
}

// Miniatura del escenario para el menú (null si su foto aún no carga)
export function stageThumb(id, w = 192, h = 108) {
  const big = canvas(), g = big.getContext('2d');
  drawStage(g, id);
  if (!cache.has(id)) return null;
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const t = c.getContext('2d');
  // encuadre como en la pelea: la parte de abajo, donde pisan los peleadores
  t.drawImage(big, 0, 180, STAGE.width, STAGE.height - 180, 0, 0, w, h);
  return c.toDataURL('image/jpeg', 0.8);
}

// La fuente gótica llega de Google Fonts: cuando carga, se vuelve a pintar el piso con ella.
if (typeof document !== 'undefined' && document.fonts) {
  const refresh = () => { if (document.fonts.check('40px "UnifrakturMaguntia"')) cache.delete('bodega'); };
  document.fonts.addEventListener('loadingdone', refresh);
  setTimeout(() => document.fonts.load('40px "UnifrakturMaguntia"').then(refresh).catch(() => {}), 300);
}
