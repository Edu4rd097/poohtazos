// HUD: vida, barra de súper, tiempo, rondas, combos y anuncios.
import { METER_MAX, ROUNDS_TO_WIN, STAGE } from '../config.js';

const W = STAGE.width;
const GOTHIC = '"UnifrakturMaguntia", serif';
const PIXEL = '"Press Start 2P", monospace';
// La letra gótica se lee mejor en minúsculas con la inicial en mayúscula
function gothicCase(text, names = []) {
  if (/\./.test(text)) return text; // K.O.
  let s = text.toLowerCase();
  for (const n of names) s = s.split(n.toLowerCase()).join(n.toLowerCase().replace(/(^|\s)(\S)/g, (m, a, b) => a + b.toUpperCase()));
  return s.replace(/^([¡¿]?)(\S)/, (m, a, b) => a + b.toUpperCase());
}
// gotas de sangre que escurren debajo de un texto o barra
function drips(ctx, x0, x1, y, seed, grow, color = '#9a0610') {
  let s = seed;
  const r = () => (s = (s * 16807 + 11) % 2147483647) / 2147483647;
  ctx.fillStyle = color;
  for (let x = x0; x < x1; x += 10 + r() * 26) {
    const w = 2 + r() * 4, len = (4 + r() * r() * 46) * grow;
    ctx.fillRect(x, y - 2, w, len);
    ctx.beginPath(); ctx.arc(x + w / 2, y - 2 + len, w * 0.75, 0, Math.PI * 2); ctx.fill();
  }
}
function hashStr(s) { let h = 7; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 2147483647; return h || 1; }

function bar(ctx, x, y, w, h, frac, shownFrac, mirror, colors) {
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(x - 3, y - 3, w + 6, h + 6);
  ctx.fillStyle = '#3a1020';
  ctx.fillRect(x, y, w, h);
  const draw = (f, c) => {
    const fw = w * Math.max(0, Math.min(1, f));
    ctx.fillStyle = c;
    ctx.fillRect(mirror ? x + w - fw : x, y, fw, h);
  };
  draw(shownFrac, colors[0]);
  draw(frac, colors[1]);
}


// ---------- presentación VS ----------
const portraits = new Map();
function portrait(src) {
  if (!src) return null;
  if (!portraits.has(src)) { const img = new Image(); img.src = src; portraits.set(src, img); }
  const img = portraits.get(src);
  return img.complete && img.naturalWidth ? img : null;
}
export function preloadPortrait(src) { portrait(src); }

function drawPanel(ctx, f, left, k) {
  const H = STAGE.height, pw = 560, slant = 90;
  const off = (1 - k) * (pw + slant) * (left ? -1 : 1);
  const x0 = left ? off : W - pw + off;
  ctx.save();
  ctx.beginPath();
  if (left) { ctx.moveTo(x0, 0); ctx.lineTo(x0 + pw + slant, 0); ctx.lineTo(x0 + pw - slant, H); ctx.lineTo(x0, H); }
  else { ctx.moveTo(x0 + slant, 0); ctx.lineTo(x0 + pw, 0); ctx.lineTo(x0 + pw, H); ctx.lineTo(x0 - slant, H); }
  ctx.closePath();
  ctx.fillStyle = f.def.look.colors.accent;
  ctx.fill();
  ctx.clip();
  const img = portrait(f.def.portrait);
  if (img) {
    const bw = pw + slant, s = Math.max(bw / img.width, H / img.height) * 1.05;
    const dw = img.width * s, dh = img.height * s;
    const focusY = (f.def.portraitFocus ?? 0.3) * dh;
    const dy = Math.max(H - dh, Math.min(0, H * 0.32 - focusY));
    const dx = (left ? x0 : x0 - slant) + (bw - dw) / 2;
    ctx.save();
    if (!left) { ctx.translate(dx * 2 + dw, 0); ctx.scale(-1, 1); } // espejo para que se miren de frente
    ctx.imageSmoothingEnabled = !f.def.pixelPortrait; // retratos 16-bit: píxeles nítidos
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.imageSmoothingEnabled = true;
    ctx.restore();
  } else {
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.font = '900 260px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(f.def.name[0], x0 + pw / 2, H / 2 + 40);
  }
  const g = ctx.createLinearGradient(0, H * 0.55, 0, H);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.85)');
  ctx.fillStyle = g; ctx.fillRect(x0 - slant, 0, pw + slant * 2, H);
  ctx.restore();

  ctx.textAlign = left ? 'left' : 'right';
  const tx = left ? 40 + off : W - 40 + off;
  const nm = gothicCase(f.def.name, [f.def.name]);
  ctx.font = '96px ' + GOTHIC;
  ctx.lineWidth = 10; ctx.strokeStyle = '#0a0204'; ctx.lineJoin = 'round';
  ctx.strokeText(nm, tx, H - 120);
  ctx.fillStyle = '#efe6d2';
  ctx.fillText(nm, tx, H - 120);
  if (f.def.title) {
    ctx.font = '18px ' + PIXEL;
    ctx.fillStyle = '#d01e1e';
    ctx.fillText(f.def.title.toUpperCase(), tx, H - 56);
  }
}

function drawVS(ctx, m) {
  const t = m.phaseFrame;
  const k = Math.min(1, t / 18), kk = 1 - Math.pow(1 - k, 3);
  const fade = t > 95 ? 1 - (t - 95) / 20 : 1;
  if (fade <= 0) return; // después del VS se ven las poses de entrada
  ctx.save();
  ctx.textBaseline = 'middle';
  ctx.globalAlpha = Math.max(0, fade);
  ctx.fillStyle = 'rgba(8,4,18,0.55)';
  ctx.fillRect(0, 0, W, STAGE.height);
  drawPanel(ctx, m.fighters[0], true, kk);
  drawPanel(ctx, m.fighters[1], false, kk);
  if (t > 16) {
    const p = Math.min(1, (t - 16) / 10);
    ctx.textAlign = 'center';
    ctx.font = Math.round(190 * (2 - p)) + 'px ' + GOTHIC;
    ctx.lineWidth = 14; ctx.strokeStyle = '#0a0204'; ctx.lineJoin = 'round';
    ctx.strokeText('vs', W / 2, STAGE.height / 2);
    ctx.fillStyle = '#d01e1e';
    ctx.fillText('vs', W / 2, STAGE.height / 2);
  }
  if (m.stageName && t > 30) {
    ctx.textAlign = 'center';
    ctx.font = '16px ' + PIXEL;
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(W / 2 - 260, 34, 520, 40);
    ctx.fillStyle = '#fff';
    ctx.fillText(m.stageName, W / 2, 55);
  }
  ctx.restore();
}

// ---------- piezas del HUD estilo arcade ----------
function gold(ctx, y0, y1) {
  const g = ctx.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, '#fff7c2'); g.addColorStop(0.45, '#ffd23a'); g.addColorStop(0.55, '#ff9a1c'); g.addColorStop(1, '#ffdf6a');
  return g;
}

function outlined(ctx, text, x, y, size, fill, align = 'left', weight = '', family = PIXEL) {
  ctx.save();
  ctx.font = (weight ? weight + ' ' : '') + size + 'px ' + family;
  ctx.textAlign = align; ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.lineWidth = Math.max(4, size * 0.14); ctx.strokeStyle = '#120a1c';
  ctx.strokeText(text, x, y);
  ctx.fillStyle = fill; ctx.fillText(text, x, y);
  ctx.restore();
}

// paralelogramo; si mirror, se refleja respecto al centro de la pantalla
function para(ctx, x, y, w, h, s, mirror) {
  const X = v => (mirror ? W - v : v);
  ctx.beginPath();
  ctx.moveTo(X(x + s), y); ctx.lineTo(X(x + w + s), y); ctx.lineTo(X(x + w), y + h); ctx.lineTo(X(x), y + h);
  ctx.closePath();
}

function shadeHex(c, k) {
  if (!c || c[0] !== '#') return c;
  const n = parseInt(c.slice(1), 16);
  const f = v => Math.round(v * k);
  return 'rgb(' + f((n >> 16) & 255) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
}

function drawPortraitBox(ctx, f, x, y, size, mirror) {
  ctx.save();
  para(ctx, x, y, size, size, 10, mirror);
  ctx.fillStyle = shadeHex(f.def.look.colors.aura || f.def.look.colors.accent, 0.35);
  ctx.fill();
  ctx.save();
  ctx.clip();
  const img = portrait(f.def.portrait);
  const cx = mirror ? W - x - size / 2 - 5 : x + size / 2 + 5;
  if (img) {
    const sc = (size * 1.6) / img.width;
    const dw = img.width * sc, dh = img.height * sc;
    const fy = (f.def.portraitFocus ?? 0.3) * dh;
    ctx.translate(cx, y + size * 0.45);
    if (mirror) ctx.scale(-1, 1);
    ctx.imageSmoothingEnabled = !f.def.pixelPortrait; // retratos 16-bit: píxeles nítidos
    ctx.drawImage(img, -dw / 2, -fy, dw, dh);
    ctx.imageSmoothingEnabled = true;
  } else {
    outlined(ctx, f.def.name[0], cx, y + size / 2 + 4, size * 0.8, f.def.look.colors.accent, 'center');
  }
  ctx.restore();
  para(ctx, x, y, size, size, 10, mirror);
  ctx.lineWidth = 6; ctx.strokeStyle = '#0a0204'; ctx.stroke();
  ctx.lineWidth = 3; ctx.strokeStyle = '#c8101a'; ctx.stroke();
  ctx.restore();
}

// Barra de vida: placa negra con dientes de sierra, alambre de púas encima, vida color sangre
// con rayas, golpe reciente en naranja y sangre que escurre más mientras menos vida queda.
function drawLifeBar(ctx, m, f, left) {
  const mirror = !left;
  const X = v => (mirror ? W - v : v);
  const px = 18, py = 14, ps = 84;
  const x = px + ps + 12, y = 28, w = 466, h = 30, sl = 16;
  const hpMax = f.def.stats.hp;
  const frac = Math.max(0, f.hp / hpMax), shown = Math.max(0, f.hpShown / hpMax);
  ctx.save();
  // placa con dientes de sierra abajo
  ctx.beginPath();
  ctx.moveTo(X(x - 10 + sl + 6), y - 9); ctx.lineTo(X(x + w + sl + 10), y - 9); ctx.lineTo(X(x + w + 10), y + h + 8);
  for (let tx = x + w + 10; tx > x - 10; tx -= 16) { ctx.lineTo(X(tx - 8), y + h + 18); ctx.lineTo(X(tx - 16), y + h + 8); }
  ctx.lineTo(X(x - 10), y + h + 8);
  ctx.closePath();
  ctx.fillStyle = '#0a0204'; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = '#5a0a10'; ctx.stroke();
  // alambre de púas
  ctx.strokeStyle = '#8a8c94'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(X(x + sl), y - 15); ctx.lineTo(X(x + w + sl), y - 15); ctx.stroke();
  for (let bx = x + sl + 10; bx < x + w + sl; bx += 26) {
    ctx.beginPath(); ctx.moveTo(X(bx - 4), y - 20); ctx.lineTo(X(bx + 4), y - 10); ctx.moveTo(X(bx + 4), y - 20); ctx.lineTo(X(bx - 4), y - 10); ctx.stroke();
  }
  // hueco de la barra
  para(ctx, x, y, w, h, sl, mirror);
  ctx.fillStyle = '#1a0204'; ctx.fill();
  ctx.save();
  para(ctx, x, y, w, h, sl, mirror); ctx.clip();
  // la vida se vacía hacia el retrato, como en los arcades
  const fill = (fr, style) => {
    const fw = (w + sl) * fr;
    ctx.fillStyle = style;
    ctx.fillRect(mirror ? W - x - fw : x, y, fw, h);
    return fw;
  };
  fill(shown, '#ff9a1c');                                               // daño reciente
  const pulse = frac < 0.3 ? 0.5 + 0.5 * Math.sin(m.frame * 0.35) : 0;
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, pulse > 0.5 ? '#ff8a7a' : '#ff4a3a'); g.addColorStop(0.45, '#c8101a'); g.addColorStop(1, '#4a0006');
  const fw = fill(frac, g);
  // rayas diagonales que corren
  ctx.strokeStyle = 'rgba(0,0,0,0.28)'; ctx.lineWidth = 5;
  const off = (m.frame * 0.6) % 18;
  for (let sx = -40 + off; sx < W; sx += 18) { ctx.beginPath(); ctx.moveTo(sx, y + h); ctx.lineTo(sx + 20, y); ctx.stroke(); }
  ctx.fillStyle = 'rgba(255,220,200,0.35)'; ctx.fillRect(0, y + 3, W, 3);  // brillo
  ctx.fillStyle = 'rgba(0,0,0,0.6)';                                     // marcas cada 10%
  for (let i = 1; i < 10; i++) { const tx = x + (w + sl) * i / 10; ctx.fillRect(X(tx) - 1, y, 2, h); }
  ctx.restore();
  para(ctx, x, y, w, h, sl, mirror);
  ctx.lineWidth = 3; ctx.strokeStyle = '#c8101a'; ctx.stroke();
  // sangre escurriendo de la barra: más gotas mientras más daño
  const lost = 1 - frac;
  if (lost > 0.04 && fw > 10) {
    const grow = Math.min(1, lost * 1.6) * (0.85 + 0.15 * Math.sin(m.frame * 0.05 + f.side));
    ctx.save();
    ctx.beginPath(); ctx.rect(0, y + h + 6, W, 80); ctx.clip();
    if (mirror) { ctx.translate(W, 0); ctx.scale(-1, 1); }
    drips(ctx, x + 6, Math.min(x + fw, x + w), y + h + 8, 17 + f.side * 31, grow);
    ctx.restore();
  }
  ctx.restore();
  drawPortraitBox(ctx, f, px, py, ps, mirror);

  const nx = mirror ? W - x - 10 : x + 10;
  outlined(ctx, f.def.name + (m.cpuSide === f.side ? ' CPU' : ''), nx, y + h + 34, 16, '#efe6d2', mirror ? 'right' : 'left');
  // rondas ganadas: calaveras
  for (let i = 0; i < ROUNDS_TO_WIN; i++) {
    const cx = X(x + w - 4 - i * 30), cy = y + h + 34, won = i < f.wins;
    ctx.save(); ctx.translate(cx, cy);
    ctx.fillStyle = won ? '#efe6d2' : 'rgba(0,0,0,0.6)'; ctx.strokeStyle = won ? '#0a0204' : '#7a1a20'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, -2, 10, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillRect(-6, 5, 12, 6); ctx.strokeRect(-6, 5, 12, 6);
    if (won) {
      ctx.fillStyle = '#c8101a';
      ctx.beginPath(); ctx.arc(-4, -2, 3, 0, Math.PI * 2); ctx.arc(4, -2, 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#0a0204'; ctx.fillRect(-2, 6, 1.5, 5); ctx.fillRect(1, 6, 1.5, 5);
    }
    ctx.restore();
  }
}

function drawPowerGauge(ctx, m, f, left) {
  const mirror = !left;
  const x = 24, y = m.touch ? 122 : 668, w = 320, h = 18, sl = 10; // en celular va arriba (abajo están los controles)
  const full = f.meter >= METER_MAX;
  const blink = Math.floor(m.frame / 5) % 2;
  ctx.save();
  para(ctx, x - 3, y - 3, w + 6, h + 6, sl, mirror);
  ctx.fillStyle = '#0a0204'; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = '#c8101a'; ctx.stroke();
  para(ctx, x, y, w, h, sl, mirror);
  ctx.fillStyle = '#1a0408'; ctx.fill();
  ctx.save();
  para(ctx, x, y, w, h, sl, mirror); ctx.clip();
  const fw = (w + sl) * Math.min(1, f.meter / METER_MAX);
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  if (full) { g.addColorStop(0, blink ? '#fff3c4' : '#ffd23a'); g.addColorStop(1, blink ? '#ff9a1c' : '#ff3a1e'); }
  else { g.addColorStop(0, '#ffb04a'); g.addColorStop(1, '#a81408'); }
  ctx.fillStyle = g;
  ctx.fillRect(mirror ? W - x - fw : x, y, fw, h);
  ctx.restore();
  ctx.restore();
  const lx = mirror ? W - x - w - 40 : x + w + 40;
  if (full) outlined(ctx, 'MAX', lx, y + h / 2, 20, blink ? '#fff3c4' : '#ff3a1e', 'center');
  outlined(ctx, 'POWER', mirror ? W - x - 4 : x + 4, y - 16, 12, '#ff9a1c', mirror ? 'right' : 'left');
}

function drawTimer(ctx, m) {
  const cx = W / 2, y = 12, w = 96, h = 78;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx - w / 2 + 12, y); ctx.lineTo(cx + w / 2 - 12, y); ctx.lineTo(cx + w / 2, y + h / 2);
  ctx.lineTo(cx + w / 2 - 12, y + h); ctx.lineTo(cx - w / 2 + 12, y + h); ctx.lineTo(cx - w / 2, y + h / 2);
  ctx.closePath();
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, '#2a0408'); g.addColorStop(1, '#080102');
  ctx.fillStyle = g; ctx.fill();
  ctx.lineWidth = 6; ctx.strokeStyle = '#0a0204'; ctx.stroke();
  ctx.lineWidth = 3; ctx.strokeStyle = '#c8101a'; ctx.stroke();
  ctx.restore();
  const secs = Math.ceil(m.timer / 60);
  outlined(ctx, String(secs).padStart(2, '0'), cx + 3, y + h / 2 + 4, 38,
    secs <= 10 && Math.floor(m.frame / 15) % 2 ? '#ff3a2a' : '#efe6d2', 'center');
}

// Corte de súper: banda inclinada con la foto/nombre del peleador y el nombre del golpe
function drawSuperCutIn(ctx, m) {
  const f = m.freezeOwner;
  const p = 1 - m.freeze / 32;
  const left = f.side === 0;
  const slide = Math.min(1, p * 4);
  const out = p > 0.85 ? (p - 0.85) / 0.15 : 0;
  const y0 = 220, bh = 200;
  ctx.save();
  ctx.globalAlpha = 1 - out;
  ctx.beginPath();
  ctx.moveTo(0, y0 + 30); ctx.lineTo(W, y0 - 10); ctx.lineTo(W, y0 + bh - 10); ctx.lineTo(0, y0 + bh + 30);
  ctx.closePath();
  const aura = f.def.look.colors.aura || f.def.look.colors.accent;
  const g = ctx.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, shadeHex(aura, 0.25)); g.addColorStop(0.5, shadeHex(aura, 0.6)); g.addColorStop(1, shadeHex(aura, 0.25));
  ctx.fillStyle = g; ctx.fill();
  ctx.save(); ctx.clip();
  ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.lineWidth = 2;
  for (let i = 0; i < 18; i++) {
    const yy = y0 + ((i * 37 + m.frame * 23) % bh);
    ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(W, yy - 30); ctx.stroke();
  }
  const img = portrait(f.def.portrait);
  const px = left ? -400 + slide * 560 : W + 400 - slide * 560;
  if (img) {
    const sc = (bh * 3) / img.height;
    const dw = img.width * sc, dh = img.height * sc;
    const fy = (f.def.portraitFocus ?? 0.3) * dh;
    ctx.save();
    ctx.translate(px, y0 + bh * 0.4);
    if (!left) ctx.scale(-1, 1);
    ctx.imageSmoothingEnabled = !f.def.pixelPortrait; // retratos 16-bit: píxeles nítidos
    ctx.drawImage(img, -dw / 2, -fy, dw, dh);
    ctx.imageSmoothingEnabled = true;
    ctx.restore();
  } else {
    outlined(ctx, f.def.name, px, y0 + bh / 2, 140, 'rgba(255,255,255,0.3)', 'center');
  }
  ctx.restore();
  ctx.lineWidth = 4; ctx.strokeStyle = '#ffffff'; ctx.stroke();
  const tx = left ? W - 60 - (1 - slide) * 300 : 60 + (1 - slide) * 300;
  outlined(ctx, (f.move && f.move.name) || '', tx, y0 + bh / 2 + 4, 66, gold(ctx, y0 + 60, y0 + 140), left ? 'right' : 'left');
  outlined(ctx, f.def.name, tx, y0 + bh / 2 + 62, 26, '#ffffff', left ? 'right' : 'left');
  ctx.restore();
}

export function drawHUD(ctx, m) {
  if (m.phase === 'vs') { drawVS(ctx, m); return; }
  const [a, b] = m.fighters;
  ctx.save();
  ctx.textBaseline = 'middle';

  for (const f of [a, b]) {
    const left = f.side === 0;
    drawLifeBar(ctx, m, f, left);
    const c = m.combo[f.side];
    if (c.t > 0 && c.count > 1) {
      ctx.globalAlpha = Math.min(1, c.t / 20);
      const x = left ? 40 : W - 40, al = left ? 'left' : 'right';
      outlined(ctx, String(c.count), x, 196, 48, '#ff3a2a', al);
      outlined(ctx, 'golpes', x + (left ? 1 : -1) * (c.count > 9 ? 108 : 60), 194, 40, '#efe6d2', al, '', GOTHIC);
      ctx.globalAlpha = 1;
    }
  }
  drawTimer(ctx, m);
  for (const f of [a, b]) drawPowerGauge(ctx, m, f, f.side === 0);

  // anuncio central
  if (m.announce.t > 0 && !(m.freeze > 0)) {
    const s = Math.min(1, m.announce.age / 8);
    ctx.globalAlpha = Math.min(1, m.announce.t / 10);
    const txt = gothicCase(m.announce.text, m.fighters.map(f => f.def.name));
    const size = Math.round((txt.length > 14 ? 104 : 136) * (1.5 - 0.5 * s));
    ctx.font = size + 'px ' + GOTHIC;
    const tw = Math.min(W - 80, ctx.measureText(txt).width);
    drips(ctx, W / 2 - tw / 2 + 10, W / 2 + tw / 2 - 10, 300 + size * 0.28, hashStr(txt), Math.min(1, m.announce.age / 30) * 1.6, '#8a0610');
    const fill = ctx.createLinearGradient(0, 300 - size / 2, 0, 300 + size / 2);
    fill.addColorStop(0, '#fff3e0'); fill.addColorStop(0.5, m.announce.color === '#ff3d3d' ? '#ff4a3a' : '#efe0c8'); fill.addColorStop(1, '#b3141a');
    ctx.save(); ctx.shadowColor = 'rgba(200,10,20,0.8)'; ctx.shadowBlur = 24;
    outlined(ctx, txt, W / 2, 300, size, fill, 'center', '', GOTHIC);
    ctx.restore();
    if (m.announce.sub) outlined(ctx, m.announce.sub, W / 2, 395, 16, '#efe6d2', 'center');
    ctx.globalAlpha = 1;
  }

  if (m.debug) {
    ctx.font = '14px monospace';
    ctx.textAlign = 'left';
    ctx.fillStyle = '#0f0';
    m.fighters.forEach((f, i) => {
      ctx.fillText(`P${i + 1} ${f.state}${f.moveName ? ':' + f.moveName : ''} f${f.moveFrame} stun${f.stun} inv${f.invuln}`, 20, 120 + i * 18 + 480);
    });
  }

  if (m.paused) {
    const vg = ctx.createRadialGradient(W / 2, 330, 120, W / 2, 330, 760);
    vg.addColorStop(0, 'rgba(20,2,4,0.72)'); vg.addColorStop(1, 'rgba(60,0,6,0.92)');
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, STAGE.height);
    drips(ctx, W / 2 - 150, W / 2 + 150, 330, 99, 1.4, '#8a0610');
    const pg = ctx.createLinearGradient(0, 220, 0, 340);
    pg.addColorStop(0, '#fff3e0'); pg.addColorStop(0.55, '#efe0c8'); pg.addColorStop(1, '#b3141a');
    outlined(ctx, 'Pausa', W / 2, 280, 150, pg, 'center', '', GOTHIC);
    if (!m.touch) { // en celular se usan los botones CONTINUAR / MENU
      outlined(ctx, 'ESC  CONTINUAR', W / 2, 430, 16, '#efe6d2', 'center');
      outlined(ctx, 'M  MENU PRINCIPAL', W / 2, 466, 16, '#efe6d2', 'center');
      outlined(ctx, 'F2  VER HITBOXES', W / 2, 502, 16, '#8a8a8a', 'center');
    }
  }
  ctx.restore();
}
