// Efectos visuales estilo arcade: chispas de impacto en estrella, fuego/energía,
// anillos y proyectiles de fuego. Las partículas viven en coordenadas del mundo
// (y = altura sobre el piso) y se dibujan con mezcla aditiva para que brillen.
import { STAGE, DT } from '../config.js';

const SY = y => STAGE.floor - y;

export function sparkBurst(list, point, color, strength = 'light', core = '#ffffff') {
  const size = { light: 26, medium: 36, heavy: 50, super: 46, block: 28 }[strength] || 30;
  list.push({ kind: 'burst', x: point.x, y: point.y, life: 9, max: 9, color, core, size, rot: Math.random() * Math.PI });
  list.push({ kind: 'ring', x: point.x, y: point.y, life: 11, max: 11, color, size });
  const n = strength === 'light' ? 6 : 12;
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, s = 250 + Math.random() * 500;
    list.push({ kind: 'streak', x: point.x, y: point.y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 10 + Math.random() * 8, max: 18, color });
  }
}

// Sangre: gotas con gravedad que salen hacia donde va el golpe; al tocar el piso quedan manchas.
const BLOOD = ['#8e0c10', '#b3141a', '#d01e1e', '#6a070b'];
export function bloodSplash(list, point, dir, strength = 'light') {
  const n = { light: 7, medium: 12, heavy: 20, super: 24 }[strength] || 8;
  for (let i = 0; i < n; i++) {
    const a = (Math.random() - 0.35) * 1.5, s = 180 + Math.random() * (strength === 'heavy' ? 620 : 420);
    list.push({ kind: 'blood', x: point.x, y: point.y + (Math.random() - 0.5) * 14,
      vx: dir * Math.cos(a) * s, vy: Math.sin(a) * s + 140, life: 70, max: 70,
      size: 1.6 + Math.random() * (strength === 'light' ? 2.2 : 3.4), color: BLOOD[i % BLOOD.length] });
  }
  // nube de rocío en el punto de impacto
  list.push({ kind: 'mist', x: point.x + dir * 10, y: point.y, life: 14, max: 14, size: strength === 'heavy' ? 30 : 20, dir });
}

export function flame(list, x, y, color, spread = 10, up = 120) {
  list.push({
    kind: 'flame', x: x + (Math.random() - 0.5) * spread, y: y + (Math.random() - 0.5) * spread,
    vx: (Math.random() - 0.5) * 60, vy: up * (0.6 + Math.random() * 0.8),
    life: 16 + Math.random() * 12, max: 28, color, size: 7 + Math.random() * 7,
  });
}

export function updateFx(list) {
  for (const p of list) {
    p.life--;
    if (p.kind === 'streak') { p.x += p.vx * DT; p.y += p.vy * DT; p.vx *= 0.85; p.vy *= 0.85; }
    if (p.kind === 'flame') { p.x += p.vx * DT; p.y += p.vy * DT; p.vx *= 0.95; }
    if (p.kind === 'blood') {
      p.vy -= 2400 * DT; p.x += p.vx * DT; p.y += p.vy * DT; p.vx *= 0.985;
      if (p.y <= 0) { p.kind = 'stain'; p.y = 0; p.life = p.max = 420; p.w = p.size * (2 + Math.random() * 2.5); }
    }
  }
  return list.filter(p => p.life > 0);
}

function star(ctx, x, y, spikes, rOut, rIn, rot) {
  ctx.beginPath();
  for (let i = 0; i < spikes * 2; i++) {
    const r = i % 2 ? rIn : rOut * (0.75 + 0.25 * ((i * 7) % 3) / 2);
    const a = rot + (i * Math.PI) / spikes;
    const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
    if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py);
  }
  ctx.closePath();
}

export function drawFx(ctx, list, floor = false) {
  ctx.save();
  for (const p of list) {
    if ((p.kind === 'stain') !== floor) continue; // manchas del piso: se dibujan antes que los peleadores
    const k = p.life / p.max, x = p.x, y = SY(p.y);
    if (p.kind === 'burst') {
      ctx.globalCompositeOperation = 'lighter';
      const s = p.size * (1.2 - k * 0.4);
      ctx.globalAlpha = k;
      ctx.fillStyle = p.color; star(ctx, x, y, 8, s, s * 0.3, p.rot); ctx.fill();
      ctx.fillStyle = p.core || '#ffffff'; star(ctx, x, y, 8, s * 0.55, s * 0.18, p.rot + 0.2); ctx.fill();
    } else if (p.kind === 'ring') {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = k * 0.9;
      ctx.strokeStyle = p.color; ctx.lineWidth = 5 * k + 1;
      ctx.beginPath(); ctx.arc(x, y, p.size * 0.4 + (1 - k) * p.size * 1.3, 0, Math.PI * 2); ctx.stroke();
    } else if (p.kind === 'streak') {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = k;
      ctx.strokeStyle = p.color; ctx.lineWidth = 3; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - p.vx * 0.03, y + p.vy * 0.03); ctx.stroke();
    } else if (p.kind === 'blood') {
      ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      ctx.fillStyle = p.color;
      const sp = Math.hypot(p.vx, p.vy) * 0.012;
      ctx.save(); ctx.translate(x, y); ctx.rotate(Math.atan2(-p.vy, p.vx));
      ctx.beginPath(); ctx.ellipse(0, 0, p.size + sp, p.size * 0.8, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    } else if (p.kind === 'stain') {
      ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = Math.min(1, k * 3) * 0.85;
      ctx.fillStyle = '#5e080b';
      ctx.beginPath(); ctx.ellipse(x, y + 2, p.w, p.size * 0.55, 0, 0, Math.PI * 2); ctx.fill();
    } else if (p.kind === 'mist') {
      ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = k * 0.55;
      ctx.fillStyle = '#b3141a';
      for (let i = 0; i < 7; i++) {
        const r = p.size * (1.4 - k) * (0.4 + (i % 3) * 0.25);
        ctx.beginPath(); ctx.arc(x + p.dir * (i * 6 - 6) * (1.5 - k), y + Math.sin(i * 2.3) * p.size * 0.6, r * 0.5, 0, Math.PI * 2); ctx.fill();
      }
    } else if (p.kind === 'flame') {
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = Math.min(1, k * 1.3);
      const r = p.size * (0.4 + k * 0.8);
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, k > 0.5 ? '#ffffff' : p.color);
      g.addColorStop(0.45, p.color);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    }
  }
  ctx.restore();
}

// Proyectil de energía: núcleo blanco, llamas que parpadean y estela
export function projectileTrail(list, p) {
  const r = p.h / 2, dir = Math.sign(p.vx);
  for (let i = 0; i < (p.def.super ? 4 : 2); i++) flame(list, p.x - dir * r * 0.6, p.y, p.def.color, r, 40);
}

export function drawProjectile(ctx, p) {
  const d = p.def, x = p.x, y = SY(p.y), dir = Math.sign(p.vx);
  const r = (p.h / 2) * (1 + 0.1 * Math.sin(p.frame * 0.9));
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const glow = ctx.createRadialGradient(x, y, 0, x, y, r * 1.8);
  glow.addColorStop(0, d.color); glow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow; ctx.globalAlpha = 0.6;
  ctx.beginPath(); ctx.arc(x, y, r * 1.8, 0, Math.PI * 2); ctx.fill();
  ctx.globalAlpha = 1;
  for (let i = 0; i < 6; i++) {
    const a = p.frame * 0.35 + (i * Math.PI) / 3;
    const lx = x - dir * Math.abs(Math.cos(a)) * r * 0.7, ly = y + Math.sin(a) * r * 0.45;
    const g = ctx.createRadialGradient(lx, ly, 0, lx, ly, r * 0.75);
    g.addColorStop(0, d.color); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(lx, ly, r * 0.75, 0, Math.PI * 2); ctx.fill();
  }
  const core = ctx.createRadialGradient(x + dir * r * 0.2, y, 0, x, y, r * 0.8);
  core.addColorStop(0, '#ffffff'); core.addColorStop(0.4, d.core || '#fff'); core.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = core;
  ctx.beginPath(); ctx.arc(x, y, r * 0.8, 0, Math.PI * 2); ctx.fill();
  if (d.ring) {
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = d.ring; ctx.lineWidth = 5; ctx.globalAlpha = 0.9;
    ctx.beginPath(); ctx.ellipse(x, y, r * 0.55, r * 0.95, 0, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.restore();
}
