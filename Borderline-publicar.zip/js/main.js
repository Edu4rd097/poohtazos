// Punto de entrada: menú, bucle de paso fijo y teclas globales.
import { DT, STAGE } from './config.js';
import { KeyboardInput, VirtualInput, BINDINGS } from './input.js';
import { Match } from './game.js';
import { AI } from './ai.js';
import { CHARACTERS } from './characters/index.js';
import { drawStage, STAGES, preloadStage, stageThumb } from './render/stage.js';
import { preloadPortrait } from './render/hud.js';
import { assignPortraits } from './render/portrait.js';
import { initAudio } from './audio.js';
import { shuffleMusic, pauseMusic, resumeMusic } from './music.js';
import { initTouch, goFullscreen, isTouch } from './touch.js';
import { closeEnd } from './endscreen.js';
import { canInstall, install, installHint } from './install.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const overlay = document.getElementById('overlay');
const app = document.getElementById('app');

// el menú está diseñado a 1280×720: se escala al tamaño real del juego (PC o celular)
// En celular vertical el menú y la pantalla final usan su propio acomodo (columna de 640 de ancho)
// a pantalla completa, para que los botones queden grandes y fáciles de tocar.
const PORTRAIT_W = 640;
const fit = () => {
  const b = document.body.classList;
  const tall = b.contains('touch') && innerHeight > innerWidth && (!b.contains('playing') || b.contains('endscreen'));
  document.documentElement.classList.toggle('tall', tall);
  document.documentElement.style.setProperty('--s', tall ? innerWidth / PORTRAIT_W : app.clientWidth / STAGE.width);
};
new ResizeObserver(fit).observe(app);
window.addEventListener('resize', fit);
new MutationObserver(fit).observe(document.body, { attributes: true, attributeFilter: ['class'] });
fit();
initTouch();

const settings = { mode: 'cpu', p1: 0, p2: 1, level: 'normal', stage: 0 }; // escenario 0 = bodega

// retratos 16-bit generados por código, y precarga de fotos/escenarios
assignPortraits(CHARACTERS);
for (const ch of CHARACTERS) preloadPortrait(ch.portrait);
for (const st of STAGES) preloadStage(st.id);

// Franja de sangre escurriendo (SVG) que usan el logo, las tarjetas y los botones
(function makeDrip() {
  let s = 3; const r = () => (s = (s * 16807) % 2147483647) / 2147483647;
  let drips = '';
  for (let x = 2; x < 118; x += 5 + r() * 9) {
    const w = 2 + r() * 3.5, len = 5 + r() ** 2 * 32;
    drips += `<rect x='${x.toFixed(1)}' y='0' width='${w.toFixed(1)}' height='${len.toFixed(1)}' rx='${(w / 2).toFixed(1)}'/>`
      + `<circle cx='${(x + w / 2).toFixed(1)}' cy='${len.toFixed(1)}' r='${(w * 0.72).toFixed(1)}'/>`;
  }
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='120' height='44'><g fill='#a0060c'>`
    + `<path d='M0 0H120V4Q110 7 100 4T80 5T60 3T40 6T20 4T0 5Z'/>${drips}</g>`
    + `<g fill='#e0383a' opacity='.55'><rect x='0' y='0' width='120' height='1.2'/></g></svg>`;
  document.documentElement.style.setProperty('--drip', `url("data:image/svg+xml,${encodeURIComponent(svg)}")`);
})();

// Logo de RageCore: la imagen trae fondo blanco; se quita el blanco que toca las orillas
// (relleno por inundación) para que quede como calcomanía sobre el menú.
let brandURL = null;
(function makeBrand() {
  const img = new Image();
  img.onload = () => {
    const w = 360, h = Math.round(img.height * w / img.width);
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d'); g.drawImage(img, 0, 0, w, h);
    const d = g.getImageData(0, 0, w, h), p = d.data;
    const white = i => p[i] > 215 && p[i + 1] > 215 && p[i + 2] > 215;
    const seen = new Uint8Array(w * h), stack = [];
    for (let x = 0; x < w; x++) stack.push(x, (h - 1) * w + x);
    for (let y = 0; y < h; y++) stack.push(y * w, y * w + w - 1);
    while (stack.length) {
      const k = stack.pop();
      if (seen[k] || !white(k * 4)) continue;
      seen[k] = 1; p[k * 4 + 3] = 0;
      const x = k % w;
      if (x > 0) stack.push(k - 1); if (x < w - 1) stack.push(k + 1);
      if (k >= w) stack.push(k - w); if (k < w * (h - 1)) stack.push(k + w);
    }
    g.putImageData(d, 0, 0);
    brandURL = c.toDataURL('image/png');
    if (!match) renderMenu();
  };
  img.src = 'assets/ragecore.webp';
})();

// Miniaturas de los escenarios (se generan cuando cargan sus fotos y la letra gótica)
const thumbs = {};
function makeThumbs() {
  let changed = false;
  for (const st of STAGES) {
    const t = stageThumb(st.id);
    if (t && t !== thumbs[st.id]) { thumbs[st.id] = t; changed = true; }
  }
  if (changed && !match) renderMenu();
}
setTimeout(makeThumbs, 200);
setTimeout(makeThumbs, 1500);
document.fonts?.ready.then(() => setTimeout(makeThumbs, 100));

// la letra pixel no trae mayúsculas con acento: se quitan los acentos agudos (la Ñ y la Ü sí existen)
const px = s => String(s).normalize('NFD').replace(/́/g, '').normalize('NFC');

function slot(key, label) {
  const c = CHARACTERS[settings[key]];
  const accent = c.look.colors.menu || c.look.colors.accent; // color de la tarjeta en el menú
  const p = c.profile || {};
  return `
        <div class="slot">
          <span class="label">${label}</span>
          <button data-pick="${key}" data-d="-1">◀</button>
          <div class="card" style="border-color:${accent}">
            <img src="${c.portrait}" alt="">
            <span class="name" style="color:${accent}">${px(c.name)}</span>
            <span class="title">${px((p.apodo || c.title || '').toUpperCase())}</span>
            <span class="stats"><b>EDAD</b> ${p.edad ? p.edad + ' AÑOS' : '?'}<br><b>ALTURA</b> ${p.estatura || '?'}<br><b>PESO</b> ${p.peso || '?'}</span>
          </div>
          <button data-pick="${key}" data-d="1">▶</button>
        </div>`;
}
let match = null;
let lastConfig = null;

// ---------- menú ----------
function renderMenu() {
  overlay.innerHTML = `
    <div class="menu">
      ${canInstall() ? '<button class="install" data-install>⬇ INSTALAR</button>' : ''}
      <div class="logo"><h1>Borderline</h1></div>
      ${brandURL ? `<img class="brand" src="${brandURL}" alt="RageCore Programación">` : ''}
      <p class="sub">PELEAS CALLEJERAS</p>
      <div class="row">
        <button data-mode="cpu" class="${settings.mode === 'cpu' ? 'on' : ''}">1 Jugador vs CPU</button>
        <button data-mode="2p" class="${settings.mode === '2p' ? 'on' : ''}">2 Jugadores</button>
        <button data-mode="demo" class="${settings.mode === 'demo' ? 'on' : ''}">CPU vs CPU</button>
      </div>
      <div class="pick">
        ${slot('p1', settings.mode === 'demo' ? 'CPU' : 'J1')}
        <span class="vs">vs</span>
        ${slot('p2', settings.mode === '2p' ? 'J2' : 'CPU')}
      </div>
      <div class="row stages">
        ${STAGES.map((st, i) => `<button data-stage="${i}" class="${settings.stage === i ? 'on' : ''}">${thumbs[st.id] ? `<img src="${thumbs[st.id]}" alt="">` : '<span class="noimg"></span>'}${px(st.name)}</button>`).join('')}
      </div>
      <div class="row small">
        ${settings.mode !== '2p' ? `<span class="label">CPU</span>
        ${['easy', 'normal', 'hard'].map(l => `<button data-level="${l}" class="${settings.level === l ? 'on' : ''}">${{ easy: 'Facil', normal: 'Normal', hard: 'Dificil' }[l]}</button>`).join('')}` : ''}
      </div>
      <button class="start" data-start>¡PELEAR! <small>(ENTER)</small></button>
      <p class="keys">
        <b>J1</b> WASD · J jab · K patada · L gancho · U poder · I super (barra POWER llena)<br>
        <b>J2</b> flechas · Num1-5 &nbsp;·&nbsp; adelante+J rafaga · adelante+K patada giratoria · agachado+K barrida<br>
        combo: J > K > L > U o I &nbsp;·&nbsp; doble toque = dash · atras = bloquear · Esc pausa
      </p>
    </div>`;
}

overlay.addEventListener('click', e => {
  const t = e.target.closest('button');
  if (!t) return;
  initAudio();
  if (t.dataset.mode) settings.mode = t.dataset.mode;
  if (t.dataset.level) settings.level = t.dataset.level;
  if (t.dataset.stage) settings.stage = Number(t.dataset.stage);
  if (t.dataset.pick) {
    const k = t.dataset.pick;
    settings[k] = (settings[k] + Number(t.dataset.d) + CHARACTERS.length) % CHARACTERS.length;
  }
  if (t.dataset.install !== undefined) { install().then(msg => { if (msg) installHint(msg); renderMenu(); }); return; }
  if (t.dataset.start !== undefined) { goFullscreen(); return startMatch(); }
  renderMenu();
});

function startMatch(config) {
  const cfg = config || {
    defs: [CHARACTERS[settings.p1], CHARACTERS[settings.p2]],
    cpu: settings.mode === 'cpu',
    demo: settings.mode === 'demo',
    level: settings.level,
    stage: STAGES[settings.stage],
    pixel: 3, // siempre 16-bit
  };
  lastConfig = cfg;
  const cpu2 = cfg.cpu || cfg.demo;
  const inputs = [
    cfg.demo ? new VirtualInput() : new KeyboardInput(BINDINGS.p1),
    cpu2 ? new VirtualInput() : new KeyboardInput(BINDINGS.p2),
  ];
  const ai = i => (me, opp, m) => new AI(me, opp, m, inputs[i], cfg.level);
  match = new Match({
    defs: cfg.defs,
    inputs,
    cpuSide: cfg.cpu ? 1 : -1,
    stageId: cfg.stage.id,
    stageName: cfg.stage.name,
    pixel: cfg.pixel,
    touch: isTouch,
    makeAI: [cfg.demo ? ai(0) : null, cpu2 ? ai(1) : null],
  });
  window.__match = match; // para depurar desde la consola
  closeEnd();
  shuffleMusic(); // otra canción al azar en cada pelea y revancha
  overlay.innerHTML = '';
  overlay.hidden = true;
  document.body.classList.add('playing'); // muestra los controles táctiles
  canvas.focus();
}

function toMenu() {
  match = null;
  document.body.classList.remove('playing');
  closeEnd();
  shuffleMusic(); // y otra al regresar al menú
  overlay.hidden = false;
  renderMenu();
}

// ---------- teclas globales ----------
window.addEventListener('keydown', e => {
  if (e.target.closest?.('input, textarea')) return; // escribiendo un comentario
  initAudio();
  if (!match) {
    if (e.code === 'Enter') startMatch();
    return;
  }
  if (e.code === 'F2') { e.preventDefault(); match.debug = !match.debug; }
  if (e.code === 'Escape' && !match.over) {
    match.paused = !match.paused;
    if (match.paused) pauseMusic(); else resumeMusic();
  }
  if (e.code === 'KeyM' && (match.paused || match.over)) toMenu();
  else if (e.code === 'Enter' && match.over) startMatch(lastConfig);
});

// ---------- bucle de paso fijo ----------
let last = performance.now(), acc = 0;
function loop(now) {
  acc += Math.min(0.1, (now - last) / 1000);
  last = now;
  let steps = 0;
  while (acc >= DT && steps < 5) {
    if (match) match.step();
    acc -= DT;
    steps++;
  }
  if (match) match.render(ctx);
  else {
    drawStage(ctx, STAGES[settings.stage].id);
    ctx.fillStyle = 'rgba(8,2,4,0.62)';
    ctx.fillRect(0, 0, STAGE.width, STAGE.height);
  }
  requestAnimationFrame(loop);
}

renderMenu();
window.addEventListener('borderline:instalable', () => { if (!match) renderMenu(); });
shuffleMusic(); // suena en el menú en cuanto el usuario toque algo
requestAnimationFrame(loop);
